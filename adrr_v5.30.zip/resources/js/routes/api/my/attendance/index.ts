import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AttendanceController::punch
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
export const punch = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: punch.url(options),
    method: 'post',
})

punch.definition = {
    methods: ["post"],
    url: '/api/my/attendance/punch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AttendanceController::punch
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
punch.url = (options?: RouteQueryOptions) => {
    return punch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::punch
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
punch.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: punch.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AttendanceController::punch
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
    const punchForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: punch.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::punch
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
        punchForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: punch.url(options),
            method: 'post',
        })
    
    punch.form = punchForm
const attendance = {
    punch: Object.assign(punch, punch),
}

export default attendance