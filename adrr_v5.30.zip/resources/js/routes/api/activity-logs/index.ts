import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:22
 * @route '/api/activity-logs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:22
 * @route '/api/activity-logs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:22
 * @route '/api/activity-logs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:22
 * @route '/api/activity-logs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:22
 * @route '/api/activity-logs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:22
 * @route '/api/activity-logs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:22
 * @route '/api/activity-logs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:76
 * @route '/api/activity-logs/{activityLog}'
 */
export const show = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/{activityLog}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:76
 * @route '/api/activity-logs/{activityLog}'
 */
show.url = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { activityLog: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { activityLog: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    activityLog: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        activityLog: typeof args.activityLog === 'object'
                ? args.activityLog.id
                : args.activityLog,
                }

    return show.definition.url
            .replace('{activityLog}', parsedArgs.activityLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:76
 * @route '/api/activity-logs/{activityLog}'
 */
show.get = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:76
 * @route '/api/activity-logs/{activityLog}'
 */
show.head = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:76
 * @route '/api/activity-logs/{activityLog}'
 */
    const showForm = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:76
 * @route '/api/activity-logs/{activityLog}'
 */
        showForm.get = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:76
 * @route '/api/activity-logs/{activityLog}'
 */
        showForm.head = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ActivityLogController::model
 * @see app/Http/Controllers/ActivityLogController.php:100
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
export const model = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: model.url(args, options),
    method: 'get',
})

model.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/model/{modelType}/{modelId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::model
 * @see app/Http/Controllers/ActivityLogController.php:100
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
model.url = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    modelType: args[0],
                    modelId: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        modelType: args.modelType,
                                modelId: args.modelId,
                }

    return model.definition.url
            .replace('{modelType}', parsedArgs.modelType.toString())
            .replace('{modelId}', parsedArgs.modelId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::model
 * @see app/Http/Controllers/ActivityLogController.php:100
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
model.get = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: model.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::model
 * @see app/Http/Controllers/ActivityLogController.php:100
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
model.head = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: model.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::model
 * @see app/Http/Controllers/ActivityLogController.php:100
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
    const modelForm = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: model.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::model
 * @see app/Http/Controllers/ActivityLogController.php:100
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
        modelForm.get = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: model.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::model
 * @see app/Http/Controllers/ActivityLogController.php:100
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
        modelForm.head = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: model.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    model.form = modelForm
/**
* @see \App\Http\Controllers\ActivityLogController::user
 * @see app/Http/Controllers/ActivityLogController.php:131
 * @route '/api/activity-logs/user/{userId}'
 */
export const user = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user.url(args, options),
    method: 'get',
})

user.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/user/{userId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::user
 * @see app/Http/Controllers/ActivityLogController.php:131
 * @route '/api/activity-logs/user/{userId}'
 */
user.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return user.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::user
 * @see app/Http/Controllers/ActivityLogController.php:131
 * @route '/api/activity-logs/user/{userId}'
 */
user.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::user
 * @see app/Http/Controllers/ActivityLogController.php:131
 * @route '/api/activity-logs/user/{userId}'
 */
user.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: user.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::user
 * @see app/Http/Controllers/ActivityLogController.php:131
 * @route '/api/activity-logs/user/{userId}'
 */
    const userForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: user.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::user
 * @see app/Http/Controllers/ActivityLogController.php:131
 * @route '/api/activity-logs/user/{userId}'
 */
        userForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: user.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::user
 * @see app/Http/Controllers/ActivityLogController.php:131
 * @route '/api/activity-logs/user/{userId}'
 */
        userForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: user.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    user.form = userForm
/**
* @see \App\Http\Controllers\ActivityLogController::statistics
 * @see app/Http/Controllers/ActivityLogController.php:157
 * @route '/api/activity-logs/statistics'
 */
export const statistics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statistics.url(options),
    method: 'get',
})

statistics.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/statistics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::statistics
 * @see app/Http/Controllers/ActivityLogController.php:157
 * @route '/api/activity-logs/statistics'
 */
statistics.url = (options?: RouteQueryOptions) => {
    return statistics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::statistics
 * @see app/Http/Controllers/ActivityLogController.php:157
 * @route '/api/activity-logs/statistics'
 */
statistics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statistics.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::statistics
 * @see app/Http/Controllers/ActivityLogController.php:157
 * @route '/api/activity-logs/statistics'
 */
statistics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: statistics.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::statistics
 * @see app/Http/Controllers/ActivityLogController.php:157
 * @route '/api/activity-logs/statistics'
 */
    const statisticsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: statistics.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::statistics
 * @see app/Http/Controllers/ActivityLogController.php:157
 * @route '/api/activity-logs/statistics'
 */
        statisticsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: statistics.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::statistics
 * @see app/Http/Controllers/ActivityLogController.php:157
 * @route '/api/activity-logs/statistics'
 */
        statisticsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: statistics.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    statistics.form = statisticsForm
/**
* @see \App\Http\Controllers\ActivityLogController::recent
 * @see app/Http/Controllers/ActivityLogController.php:178
 * @route '/api/activity-logs/recent'
 */
export const recent = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recent.url(options),
    method: 'get',
})

recent.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/recent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::recent
 * @see app/Http/Controllers/ActivityLogController.php:178
 * @route '/api/activity-logs/recent'
 */
recent.url = (options?: RouteQueryOptions) => {
    return recent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::recent
 * @see app/Http/Controllers/ActivityLogController.php:178
 * @route '/api/activity-logs/recent'
 */
recent.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recent.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::recent
 * @see app/Http/Controllers/ActivityLogController.php:178
 * @route '/api/activity-logs/recent'
 */
recent.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: recent.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::recent
 * @see app/Http/Controllers/ActivityLogController.php:178
 * @route '/api/activity-logs/recent'
 */
    const recentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: recent.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::recent
 * @see app/Http/Controllers/ActivityLogController.php:178
 * @route '/api/activity-logs/recent'
 */
        recentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: recent.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::recent
 * @see app/Http/Controllers/ActivityLogController.php:178
 * @route '/api/activity-logs/recent'
 */
        recentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: recent.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    recent.form = recentForm
/**
* @see \App\Http\Controllers\ActivityLogController::clearOld
 * @see app/Http/Controllers/ActivityLogController.php:199
 * @route '/api/activity-logs/clear-old'
 */
export const clearOld = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearOld.url(options),
    method: 'delete',
})

clearOld.definition = {
    methods: ["delete"],
    url: '/api/activity-logs/clear-old',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ActivityLogController::clearOld
 * @see app/Http/Controllers/ActivityLogController.php:199
 * @route '/api/activity-logs/clear-old'
 */
clearOld.url = (options?: RouteQueryOptions) => {
    return clearOld.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::clearOld
 * @see app/Http/Controllers/ActivityLogController.php:199
 * @route '/api/activity-logs/clear-old'
 */
clearOld.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearOld.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::clearOld
 * @see app/Http/Controllers/ActivityLogController.php:199
 * @route '/api/activity-logs/clear-old'
 */
    const clearOldForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clearOld.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::clearOld
 * @see app/Http/Controllers/ActivityLogController.php:199
 * @route '/api/activity-logs/clear-old'
 */
        clearOldForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clearOld.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    clearOld.form = clearOldForm
/**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:227
 * @route '/api/activity-logs/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:227
 * @route '/api/activity-logs/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:227
 * @route '/api/activity-logs/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:227
 * @route '/api/activity-logs/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:227
 * @route '/api/activity-logs/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:227
 * @route '/api/activity-logs/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:227
 * @route '/api/activity-logs/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const activityLogs = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
model: Object.assign(model, model),
user: Object.assign(user, user),
statistics: Object.assign(statistics, statistics),
recent: Object.assign(recent, recent),
clearOld: Object.assign(clearOld, clearOld),
export: Object.assign(exportMethod, exportMethod),
}

export default activityLogs