import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\AttendanceController::daily
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
export const daily = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: daily.url(options),
    method: 'get',
})

daily.definition = {
    methods: ["get","head"],
    url: '/api/daily/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::daily
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
daily.url = (options?: RouteQueryOptions) => {
    return daily.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::daily
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
daily.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: daily.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::daily
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
daily.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: daily.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::daily
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
    const dailyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: daily.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::daily
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
        dailyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: daily.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::daily
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
        dailyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: daily.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    daily.form = dailyForm