import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
 * @see routes/web.php:79
 * @route '/c/{client}/logout'
 */
export const page = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: page.url(args, options),
    method: 'get',
})

page.definition = {
    methods: ["get","head"],
    url: '/c/{client}/logout',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:79
 * @route '/c/{client}/logout'
 */
page.url = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'code' in args) {
            args = { client: args.code }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                }

    return page.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
 * @see routes/web.php:79
 * @route '/c/{client}/logout'
 */
page.get = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: page.url(args, options),
    method: 'get',
})
/**
 * @see routes/web.php:79
 * @route '/c/{client}/logout'
 */
page.head = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: page.url(args, options),
    method: 'head',
})

    /**
 * @see routes/web.php:79
 * @route '/c/{client}/logout'
 */
    const pageForm = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: page.url(args, options),
        method: 'get',
    })

            /**
 * @see routes/web.php:79
 * @route '/c/{client}/logout'
 */
        pageForm.get = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: page.url(args, options),
            method: 'get',
        })
            /**
 * @see routes/web.php:79
 * @route '/c/{client}/logout'
 */
        pageForm.head = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: page.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    page.form = pageForm