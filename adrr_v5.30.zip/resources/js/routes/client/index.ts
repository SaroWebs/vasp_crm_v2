import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import tickets from './tickets'
import comments from './comments'
/**
 * @see routes/web.php:87
 * @route '/c/{client}'
 */
export const dashboard = (args: { client: string | number | { code: string | number } } | [client: string | number | { code: string | number } ] | string | number | { code: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(args, options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/c/{client}',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:87
 * @route '/c/{client}'
 */
dashboard.url = (args: { client: string | number | { code: string | number } } | [client: string | number | { code: string | number } ] | string | number | { code: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'code' in args) {
            args = { client: args.code }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                }

    return dashboard.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
 * @see routes/web.php:87
 * @route '/c/{client}'
 */
dashboard.get = (args: { client: string | number | { code: string | number } } | [client: string | number | { code: string | number } ] | string | number | { code: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(args, options),
    method: 'get',
})
/**
 * @see routes/web.php:87
 * @route '/c/{client}'
 */
dashboard.head = (args: { client: string | number | { code: string | number } } | [client: string | number | { code: string | number } ] | string | number | { code: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(args, options),
    method: 'head',
})

    /**
 * @see routes/web.php:87
 * @route '/c/{client}'
 */
    const dashboardForm = (args: { client: string | number | { code: string | number } } | [client: string | number | { code: string | number } ] | string | number | { code: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(args, options),
        method: 'get',
    })

            /**
 * @see routes/web.php:87
 * @route '/c/{client}'
 */
        dashboardForm.get = (args: { client: string | number | { code: string | number } } | [client: string | number | { code: string | number } ] | string | number | { code: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(args, options),
            method: 'get',
        })
            /**
 * @see routes/web.php:87
 * @route '/c/{client}'
 */
        dashboardForm.head = (args: { client: string | number | { code: string | number } } | [client: string | number | { code: string | number } ] | string | number | { code: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
export const logout = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(args, options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/c/{client}/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
logout.url = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'code' in args) {
            args = { client: args.code }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                }

    return logout.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
logout.post = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
    const logoutForm = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
        logoutForm.post = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(args, options),
            method: 'post',
        })
    
    logout.form = logoutForm
const client = {
    logout: Object.assign(logout, logout),
dashboard: Object.assign(dashboard, dashboard),
tickets: Object.assign(tickets, tickets),
comments: Object.assign(comments, comments),
}

export default client