import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FieldWorkRequestController::index
 * @see app/Http/Controllers/FieldWorkRequestController.php:17
 * @route '/api/field-work-requests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/field-work-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FieldWorkRequestController::index
 * @see app/Http/Controllers/FieldWorkRequestController.php:17
 * @route '/api/field-work-requests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkRequestController::index
 * @see app/Http/Controllers/FieldWorkRequestController.php:17
 * @route '/api/field-work-requests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FieldWorkRequestController::index
 * @see app/Http/Controllers/FieldWorkRequestController.php:17
 * @route '/api/field-work-requests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FieldWorkRequestController::index
 * @see app/Http/Controllers/FieldWorkRequestController.php:17
 * @route '/api/field-work-requests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FieldWorkRequestController::index
 * @see app/Http/Controllers/FieldWorkRequestController.php:17
 * @route '/api/field-work-requests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FieldWorkRequestController::index
 * @see app/Http/Controllers/FieldWorkRequestController.php:17
 * @route '/api/field-work-requests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\FieldWorkRequestController::store
 * @see app/Http/Controllers/FieldWorkRequestController.php:49
 * @route '/api/field-work-requests'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/field-work-requests',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FieldWorkRequestController::store
 * @see app/Http/Controllers/FieldWorkRequestController.php:49
 * @route '/api/field-work-requests'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkRequestController::store
 * @see app/Http/Controllers/FieldWorkRequestController.php:49
 * @route '/api/field-work-requests'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FieldWorkRequestController::store
 * @see app/Http/Controllers/FieldWorkRequestController.php:49
 * @route '/api/field-work-requests'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkRequestController::store
 * @see app/Http/Controllers/FieldWorkRequestController.php:49
 * @route '/api/field-work-requests'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\FieldWorkRequestController::show
 * @see app/Http/Controllers/FieldWorkRequestController.php:85
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
export const show = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/field-work-requests/{fieldWorkRequest}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FieldWorkRequestController::show
 * @see app/Http/Controllers/FieldWorkRequestController.php:85
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
show.url = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkRequest: typeof args.fieldWorkRequest === 'object'
                ? args.fieldWorkRequest.id
                : args.fieldWorkRequest,
                }

    return show.definition.url
            .replace('{fieldWorkRequest}', parsedArgs.fieldWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkRequestController::show
 * @see app/Http/Controllers/FieldWorkRequestController.php:85
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
show.get = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FieldWorkRequestController::show
 * @see app/Http/Controllers/FieldWorkRequestController.php:85
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
show.head = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FieldWorkRequestController::show
 * @see app/Http/Controllers/FieldWorkRequestController.php:85
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
    const showForm = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FieldWorkRequestController::show
 * @see app/Http/Controllers/FieldWorkRequestController.php:85
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
        showForm.get = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FieldWorkRequestController::show
 * @see app/Http/Controllers/FieldWorkRequestController.php:85
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
        showForm.head = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\FieldWorkRequestController::update
 * @see app/Http/Controllers/FieldWorkRequestController.php:96
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
export const update = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/field-work-requests/{fieldWorkRequest}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FieldWorkRequestController::update
 * @see app/Http/Controllers/FieldWorkRequestController.php:96
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
update.url = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkRequest: typeof args.fieldWorkRequest === 'object'
                ? args.fieldWorkRequest.id
                : args.fieldWorkRequest,
                }

    return update.definition.url
            .replace('{fieldWorkRequest}', parsedArgs.fieldWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkRequestController::update
 * @see app/Http/Controllers/FieldWorkRequestController.php:96
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
update.put = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\FieldWorkRequestController::update
 * @see app/Http/Controllers/FieldWorkRequestController.php:96
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
    const updateForm = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkRequestController::update
 * @see app/Http/Controllers/FieldWorkRequestController.php:96
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
        updateForm.put = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\FieldWorkRequestController::destroy
 * @see app/Http/Controllers/FieldWorkRequestController.php:123
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
export const destroy = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/field-work-requests/{fieldWorkRequest}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FieldWorkRequestController::destroy
 * @see app/Http/Controllers/FieldWorkRequestController.php:123
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
destroy.url = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkRequest: typeof args.fieldWorkRequest === 'object'
                ? args.fieldWorkRequest.id
                : args.fieldWorkRequest,
                }

    return destroy.definition.url
            .replace('{fieldWorkRequest}', parsedArgs.fieldWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkRequestController::destroy
 * @see app/Http/Controllers/FieldWorkRequestController.php:123
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
destroy.delete = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\FieldWorkRequestController::destroy
 * @see app/Http/Controllers/FieldWorkRequestController.php:123
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
    const destroyForm = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkRequestController::destroy
 * @see app/Http/Controllers/FieldWorkRequestController.php:123
 * @route '/api/field-work-requests/{fieldWorkRequest}'
 */
        destroyForm.delete = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\FieldWorkRequestController::approve
 * @see app/Http/Controllers/FieldWorkRequestController.php:140
 * @route '/api/field-work-requests/{fieldWorkRequest}/approve'
 */
export const approve = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/field-work-requests/{fieldWorkRequest}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FieldWorkRequestController::approve
 * @see app/Http/Controllers/FieldWorkRequestController.php:140
 * @route '/api/field-work-requests/{fieldWorkRequest}/approve'
 */
approve.url = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkRequest: typeof args.fieldWorkRequest === 'object'
                ? args.fieldWorkRequest.id
                : args.fieldWorkRequest,
                }

    return approve.definition.url
            .replace('{fieldWorkRequest}', parsedArgs.fieldWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkRequestController::approve
 * @see app/Http/Controllers/FieldWorkRequestController.php:140
 * @route '/api/field-work-requests/{fieldWorkRequest}/approve'
 */
approve.post = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FieldWorkRequestController::approve
 * @see app/Http/Controllers/FieldWorkRequestController.php:140
 * @route '/api/field-work-requests/{fieldWorkRequest}/approve'
 */
    const approveForm = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkRequestController::approve
 * @see app/Http/Controllers/FieldWorkRequestController.php:140
 * @route '/api/field-work-requests/{fieldWorkRequest}/approve'
 */
        approveForm.post = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\FieldWorkRequestController::reject
 * @see app/Http/Controllers/FieldWorkRequestController.php:182
 * @route '/api/field-work-requests/{fieldWorkRequest}/reject'
 */
export const reject = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/api/field-work-requests/{fieldWorkRequest}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FieldWorkRequestController::reject
 * @see app/Http/Controllers/FieldWorkRequestController.php:182
 * @route '/api/field-work-requests/{fieldWorkRequest}/reject'
 */
reject.url = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkRequest: typeof args.fieldWorkRequest === 'object'
                ? args.fieldWorkRequest.id
                : args.fieldWorkRequest,
                }

    return reject.definition.url
            .replace('{fieldWorkRequest}', parsedArgs.fieldWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkRequestController::reject
 * @see app/Http/Controllers/FieldWorkRequestController.php:182
 * @route '/api/field-work-requests/{fieldWorkRequest}/reject'
 */
reject.post = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FieldWorkRequestController::reject
 * @see app/Http/Controllers/FieldWorkRequestController.php:182
 * @route '/api/field-work-requests/{fieldWorkRequest}/reject'
 */
    const rejectForm = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkRequestController::reject
 * @see app/Http/Controllers/FieldWorkRequestController.php:182
 * @route '/api/field-work-requests/{fieldWorkRequest}/reject'
 */
        rejectForm.post = (args: { fieldWorkRequest: number | { id: number } } | [fieldWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\FieldWorkRequestController::getEmployeeFieldWorkRequests
 * @see app/Http/Controllers/FieldWorkRequestController.php:213
 * @route '/api/employees/{employee}/field-work-requests'
 */
export const getEmployeeFieldWorkRequests = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeFieldWorkRequests.url(args, options),
    method: 'get',
})

getEmployeeFieldWorkRequests.definition = {
    methods: ["get","head"],
    url: '/api/employees/{employee}/field-work-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FieldWorkRequestController::getEmployeeFieldWorkRequests
 * @see app/Http/Controllers/FieldWorkRequestController.php:213
 * @route '/api/employees/{employee}/field-work-requests'
 */
getEmployeeFieldWorkRequests.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return getEmployeeFieldWorkRequests.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkRequestController::getEmployeeFieldWorkRequests
 * @see app/Http/Controllers/FieldWorkRequestController.php:213
 * @route '/api/employees/{employee}/field-work-requests'
 */
getEmployeeFieldWorkRequests.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeFieldWorkRequests.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FieldWorkRequestController::getEmployeeFieldWorkRequests
 * @see app/Http/Controllers/FieldWorkRequestController.php:213
 * @route '/api/employees/{employee}/field-work-requests'
 */
getEmployeeFieldWorkRequests.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeFieldWorkRequests.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FieldWorkRequestController::getEmployeeFieldWorkRequests
 * @see app/Http/Controllers/FieldWorkRequestController.php:213
 * @route '/api/employees/{employee}/field-work-requests'
 */
    const getEmployeeFieldWorkRequestsForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeFieldWorkRequests.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FieldWorkRequestController::getEmployeeFieldWorkRequests
 * @see app/Http/Controllers/FieldWorkRequestController.php:213
 * @route '/api/employees/{employee}/field-work-requests'
 */
        getEmployeeFieldWorkRequestsForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeFieldWorkRequests.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FieldWorkRequestController::getEmployeeFieldWorkRequests
 * @see app/Http/Controllers/FieldWorkRequestController.php:213
 * @route '/api/employees/{employee}/field-work-requests'
 */
        getEmployeeFieldWorkRequestsForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeFieldWorkRequests.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeFieldWorkRequests.form = getEmployeeFieldWorkRequestsForm
const FieldWorkRequestController = { index, store, show, update, destroy, approve, reject, getEmployeeFieldWorkRequests }

export default FieldWorkRequestController