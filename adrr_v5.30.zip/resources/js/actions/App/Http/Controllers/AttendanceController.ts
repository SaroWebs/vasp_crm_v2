import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AttendanceController::uploadPunchData
 * @see app/Http/Controllers/AttendanceController.php:32
 * @route '/api/upload_punch_data'
 */
export const uploadPunchData = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadPunchData.url(options),
    method: 'post',
})

uploadPunchData.definition = {
    methods: ["post"],
    url: '/api/upload_punch_data',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AttendanceController::uploadPunchData
 * @see app/Http/Controllers/AttendanceController.php:32
 * @route '/api/upload_punch_data'
 */
uploadPunchData.url = (options?: RouteQueryOptions) => {
    return uploadPunchData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::uploadPunchData
 * @see app/Http/Controllers/AttendanceController.php:32
 * @route '/api/upload_punch_data'
 */
uploadPunchData.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadPunchData.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AttendanceController::uploadPunchData
 * @see app/Http/Controllers/AttendanceController.php:32
 * @route '/api/upload_punch_data'
 */
    const uploadPunchDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: uploadPunchData.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::uploadPunchData
 * @see app/Http/Controllers/AttendanceController.php:32
 * @route '/api/upload_punch_data'
 */
        uploadPunchDataForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: uploadPunchData.url(options),
            method: 'post',
        })
    
    uploadPunchData.form = uploadPunchDataForm
/**
* @see \App\Http\Controllers\AttendanceController::adminIndex
 * @see app/Http/Controllers/AttendanceController.php:262
 * @route '/admin/attendance'
 */
export const adminIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})

adminIndex.definition = {
    methods: ["get","head"],
    url: '/admin/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::adminIndex
 * @see app/Http/Controllers/AttendanceController.php:262
 * @route '/admin/attendance'
 */
adminIndex.url = (options?: RouteQueryOptions) => {
    return adminIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::adminIndex
 * @see app/Http/Controllers/AttendanceController.php:262
 * @route '/admin/attendance'
 */
adminIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::adminIndex
 * @see app/Http/Controllers/AttendanceController.php:262
 * @route '/admin/attendance'
 */
adminIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::adminIndex
 * @see app/Http/Controllers/AttendanceController.php:262
 * @route '/admin/attendance'
 */
    const adminIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::adminIndex
 * @see app/Http/Controllers/AttendanceController.php:262
 * @route '/admin/attendance'
 */
        adminIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::adminIndex
 * @see app/Http/Controllers/AttendanceController.php:262
 * @route '/admin/attendance'
 */
        adminIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminIndex.form = adminIndexForm
/**
* @see \App\Http\Controllers\AttendanceController::adminSummaryPage
 * @see app/Http/Controllers/AttendanceController.php:278
 * @route '/admin/attendance/summary'
 */
export const adminSummaryPage = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminSummaryPage.url(options),
    method: 'get',
})

adminSummaryPage.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::adminSummaryPage
 * @see app/Http/Controllers/AttendanceController.php:278
 * @route '/admin/attendance/summary'
 */
adminSummaryPage.url = (options?: RouteQueryOptions) => {
    return adminSummaryPage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::adminSummaryPage
 * @see app/Http/Controllers/AttendanceController.php:278
 * @route '/admin/attendance/summary'
 */
adminSummaryPage.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminSummaryPage.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::adminSummaryPage
 * @see app/Http/Controllers/AttendanceController.php:278
 * @route '/admin/attendance/summary'
 */
adminSummaryPage.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminSummaryPage.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::adminSummaryPage
 * @see app/Http/Controllers/AttendanceController.php:278
 * @route '/admin/attendance/summary'
 */
    const adminSummaryPageForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminSummaryPage.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::adminSummaryPage
 * @see app/Http/Controllers/AttendanceController.php:278
 * @route '/admin/attendance/summary'
 */
        adminSummaryPageForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminSummaryPage.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::adminSummaryPage
 * @see app/Http/Controllers/AttendanceController.php:278
 * @route '/admin/attendance/summary'
 */
        adminSummaryPageForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminSummaryPage.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminSummaryPage.form = adminSummaryPageForm
/**
* @see \App\Http\Controllers\AttendanceController::adminGetEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:373
 * @route '/admin/employee-attendance/{employee}'
 */
export const adminGetEmployeeAttendance = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminGetEmployeeAttendance.url(args, options),
    method: 'get',
})

adminGetEmployeeAttendance.definition = {
    methods: ["get","head"],
    url: '/admin/employee-attendance/{employee}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::adminGetEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:373
 * @route '/admin/employee-attendance/{employee}'
 */
adminGetEmployeeAttendance.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return adminGetEmployeeAttendance.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::adminGetEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:373
 * @route '/admin/employee-attendance/{employee}'
 */
adminGetEmployeeAttendance.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminGetEmployeeAttendance.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::adminGetEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:373
 * @route '/admin/employee-attendance/{employee}'
 */
adminGetEmployeeAttendance.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminGetEmployeeAttendance.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::adminGetEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:373
 * @route '/admin/employee-attendance/{employee}'
 */
    const adminGetEmployeeAttendanceForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminGetEmployeeAttendance.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::adminGetEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:373
 * @route '/admin/employee-attendance/{employee}'
 */
        adminGetEmployeeAttendanceForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminGetEmployeeAttendance.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::adminGetEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:373
 * @route '/admin/employee-attendance/{employee}'
 */
        adminGetEmployeeAttendanceForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminGetEmployeeAttendance.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminGetEmployeeAttendance.form = adminGetEmployeeAttendanceForm
/**
* @see \App\Http\Controllers\AttendanceController::adminGetAllAttendanceSummary
 * @see app/Http/Controllers/AttendanceController.php:413
 * @route '/admin/api/attendance/summary'
 */
export const adminGetAllAttendanceSummary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminGetAllAttendanceSummary.url(options),
    method: 'get',
})

adminGetAllAttendanceSummary.definition = {
    methods: ["get","head"],
    url: '/admin/api/attendance/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::adminGetAllAttendanceSummary
 * @see app/Http/Controllers/AttendanceController.php:413
 * @route '/admin/api/attendance/summary'
 */
adminGetAllAttendanceSummary.url = (options?: RouteQueryOptions) => {
    return adminGetAllAttendanceSummary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::adminGetAllAttendanceSummary
 * @see app/Http/Controllers/AttendanceController.php:413
 * @route '/admin/api/attendance/summary'
 */
adminGetAllAttendanceSummary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminGetAllAttendanceSummary.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::adminGetAllAttendanceSummary
 * @see app/Http/Controllers/AttendanceController.php:413
 * @route '/admin/api/attendance/summary'
 */
adminGetAllAttendanceSummary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminGetAllAttendanceSummary.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::adminGetAllAttendanceSummary
 * @see app/Http/Controllers/AttendanceController.php:413
 * @route '/admin/api/attendance/summary'
 */
    const adminGetAllAttendanceSummaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminGetAllAttendanceSummary.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::adminGetAllAttendanceSummary
 * @see app/Http/Controllers/AttendanceController.php:413
 * @route '/admin/api/attendance/summary'
 */
        adminGetAllAttendanceSummaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminGetAllAttendanceSummary.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::adminGetAllAttendanceSummary
 * @see app/Http/Controllers/AttendanceController.php:413
 * @route '/admin/api/attendance/summary'
 */
        adminGetAllAttendanceSummaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminGetAllAttendanceSummary.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminGetAllAttendanceSummary.form = adminGetAllAttendanceSummaryForm
/**
* @see \App\Http\Controllers\AttendanceController::getAttendanceByDate
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/date'
 */
export const getAttendanceByDate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAttendanceByDate.url(options),
    method: 'get',
})

getAttendanceByDate.definition = {
    methods: ["get","head"],
    url: '/admin/api/attendance/date',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::getAttendanceByDate
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/date'
 */
getAttendanceByDate.url = (options?: RouteQueryOptions) => {
    return getAttendanceByDate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::getAttendanceByDate
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/date'
 */
getAttendanceByDate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAttendanceByDate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::getAttendanceByDate
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/date'
 */
getAttendanceByDate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAttendanceByDate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::getAttendanceByDate
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/date'
 */
    const getAttendanceByDateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getAttendanceByDate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::getAttendanceByDate
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/date'
 */
        getAttendanceByDateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAttendanceByDate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::getAttendanceByDate
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/date'
 */
        getAttendanceByDateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAttendanceByDate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getAttendanceByDate.form = getAttendanceByDateForm
/**
* @see \App\Http\Controllers\AttendanceController::adminOverrideAttendance
 * @see app/Http/Controllers/AttendanceController.php:459
 * @route '/admin/api/attendance/{employee}/override'
 */
export const adminOverrideAttendance = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminOverrideAttendance.url(args, options),
    method: 'post',
})

adminOverrideAttendance.definition = {
    methods: ["post"],
    url: '/admin/api/attendance/{employee}/override',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AttendanceController::adminOverrideAttendance
 * @see app/Http/Controllers/AttendanceController.php:459
 * @route '/admin/api/attendance/{employee}/override'
 */
adminOverrideAttendance.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return adminOverrideAttendance.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::adminOverrideAttendance
 * @see app/Http/Controllers/AttendanceController.php:459
 * @route '/admin/api/attendance/{employee}/override'
 */
adminOverrideAttendance.post = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminOverrideAttendance.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AttendanceController::adminOverrideAttendance
 * @see app/Http/Controllers/AttendanceController.php:459
 * @route '/admin/api/attendance/{employee}/override'
 */
    const adminOverrideAttendanceForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminOverrideAttendance.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::adminOverrideAttendance
 * @see app/Http/Controllers/AttendanceController.php:459
 * @route '/admin/api/attendance/{employee}/override'
 */
        adminOverrideAttendanceForm.post = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminOverrideAttendance.url(args, options),
            method: 'post',
        })
    
    adminOverrideAttendance.form = adminOverrideAttendanceForm
/**
* @see \App\Http\Controllers\AttendanceController::adminDeleteAttendance
 * @see app/Http/Controllers/AttendanceController.php:496
 * @route '/admin/api/attendance/{attendance}'
 */
export const adminDeleteAttendance = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: adminDeleteAttendance.url(args, options),
    method: 'delete',
})

adminDeleteAttendance.definition = {
    methods: ["delete"],
    url: '/admin/api/attendance/{attendance}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AttendanceController::adminDeleteAttendance
 * @see app/Http/Controllers/AttendanceController.php:496
 * @route '/admin/api/attendance/{attendance}'
 */
adminDeleteAttendance.url = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attendance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { attendance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    attendance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attendance: typeof args.attendance === 'object'
                ? args.attendance.id
                : args.attendance,
                }

    return adminDeleteAttendance.definition.url
            .replace('{attendance}', parsedArgs.attendance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::adminDeleteAttendance
 * @see app/Http/Controllers/AttendanceController.php:496
 * @route '/admin/api/attendance/{attendance}'
 */
adminDeleteAttendance.delete = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: adminDeleteAttendance.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AttendanceController::adminDeleteAttendance
 * @see app/Http/Controllers/AttendanceController.php:496
 * @route '/admin/api/attendance/{attendance}'
 */
    const adminDeleteAttendanceForm = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminDeleteAttendance.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::adminDeleteAttendance
 * @see app/Http/Controllers/AttendanceController.php:496
 * @route '/admin/api/attendance/{attendance}'
 */
        adminDeleteAttendanceForm.delete = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminDeleteAttendance.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    adminDeleteAttendance.form = adminDeleteAttendanceForm
/**
* @see \App\Http\Controllers\AttendanceController::myAttendancePage
 * @see app/Http/Controllers/AttendanceController.php:254
 * @route '/my/attendance'
 */
export const myAttendancePage = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myAttendancePage.url(options),
    method: 'get',
})

myAttendancePage.definition = {
    methods: ["get","head"],
    url: '/my/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::myAttendancePage
 * @see app/Http/Controllers/AttendanceController.php:254
 * @route '/my/attendance'
 */
myAttendancePage.url = (options?: RouteQueryOptions) => {
    return myAttendancePage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::myAttendancePage
 * @see app/Http/Controllers/AttendanceController.php:254
 * @route '/my/attendance'
 */
myAttendancePage.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myAttendancePage.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::myAttendancePage
 * @see app/Http/Controllers/AttendanceController.php:254
 * @route '/my/attendance'
 */
myAttendancePage.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myAttendancePage.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::myAttendancePage
 * @see app/Http/Controllers/AttendanceController.php:254
 * @route '/my/attendance'
 */
    const myAttendancePageForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: myAttendancePage.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::myAttendancePage
 * @see app/Http/Controllers/AttendanceController.php:254
 * @route '/my/attendance'
 */
        myAttendancePageForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myAttendancePage.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::myAttendancePage
 * @see app/Http/Controllers/AttendanceController.php:254
 * @route '/my/attendance'
 */
        myAttendancePageForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myAttendancePage.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    myAttendancePage.form = myAttendancePageForm
/**
* @see \App\Http\Controllers\AttendanceController::getEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:197
 * @route '/api/my/attendance'
 */
export const getEmployeeAttendance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeAttendance.url(options),
    method: 'get',
})

getEmployeeAttendance.definition = {
    methods: ["get","head"],
    url: '/api/my/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::getEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:197
 * @route '/api/my/attendance'
 */
getEmployeeAttendance.url = (options?: RouteQueryOptions) => {
    return getEmployeeAttendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::getEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:197
 * @route '/api/my/attendance'
 */
getEmployeeAttendance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeAttendance.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::getEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:197
 * @route '/api/my/attendance'
 */
getEmployeeAttendance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeAttendance.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::getEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:197
 * @route '/api/my/attendance'
 */
    const getEmployeeAttendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeAttendance.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::getEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:197
 * @route '/api/my/attendance'
 */
        getEmployeeAttendanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeAttendance.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::getEmployeeAttendance
 * @see app/Http/Controllers/AttendanceController.php:197
 * @route '/api/my/attendance'
 */
        getEmployeeAttendanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeAttendance.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeAttendance.form = getEmployeeAttendanceForm
/**
* @see \App\Http\Controllers\AttendanceController::punchEntry
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
export const punchEntry = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: punchEntry.url(options),
    method: 'post',
})

punchEntry.definition = {
    methods: ["post"],
    url: '/api/my/attendance/punch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AttendanceController::punchEntry
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
punchEntry.url = (options?: RouteQueryOptions) => {
    return punchEntry.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::punchEntry
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
punchEntry.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: punchEntry.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AttendanceController::punchEntry
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
    const punchEntryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: punchEntry.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::punchEntry
 * @see app/Http/Controllers/AttendanceController.php:127
 * @route '/api/my/attendance/punch'
 */
        punchEntryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: punchEntry.url(options),
            method: 'post',
        })
    
    punchEntry.form = punchEntryForm
/**
* @see \App\Http\Controllers\AttendanceController::getDailyDetails
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
export const getDailyDetails = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDailyDetails.url(options),
    method: 'get',
})

getDailyDetails.definition = {
    methods: ["get","head"],
    url: '/api/daily/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::getDailyDetails
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
getDailyDetails.url = (options?: RouteQueryOptions) => {
    return getDailyDetails.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::getDailyDetails
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
getDailyDetails.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDailyDetails.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::getDailyDetails
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
getDailyDetails.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDailyDetails.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::getDailyDetails
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
    const getDailyDetailsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getDailyDetails.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::getDailyDetails
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
        getDailyDetailsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getDailyDetails.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::getDailyDetails
 * @see app/Http/Controllers/AttendanceController.php:99
 * @route '/api/daily/attendance'
 */
        getDailyDetailsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getDailyDetails.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getDailyDetails.form = getDailyDetailsForm
/**
* @see \App\Http\Controllers\AttendanceController::getAttendance
 * @see app/Http/Controllers/AttendanceController.php:287
 * @route '/api/attendance/{employeeId}'
 */
export const getAttendance = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAttendance.url(args, options),
    method: 'get',
})

getAttendance.definition = {
    methods: ["get","head"],
    url: '/api/attendance/{employeeId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::getAttendance
 * @see app/Http/Controllers/AttendanceController.php:287
 * @route '/api/attendance/{employeeId}'
 */
getAttendance.url = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employeeId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    employeeId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employeeId: args.employeeId,
                }

    return getAttendance.definition.url
            .replace('{employeeId}', parsedArgs.employeeId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::getAttendance
 * @see app/Http/Controllers/AttendanceController.php:287
 * @route '/api/attendance/{employeeId}'
 */
getAttendance.get = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAttendance.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::getAttendance
 * @see app/Http/Controllers/AttendanceController.php:287
 * @route '/api/attendance/{employeeId}'
 */
getAttendance.head = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAttendance.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::getAttendance
 * @see app/Http/Controllers/AttendanceController.php:287
 * @route '/api/attendance/{employeeId}'
 */
    const getAttendanceForm = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getAttendance.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::getAttendance
 * @see app/Http/Controllers/AttendanceController.php:287
 * @route '/api/attendance/{employeeId}'
 */
        getAttendanceForm.get = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAttendance.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::getAttendance
 * @see app/Http/Controllers/AttendanceController.php:287
 * @route '/api/attendance/{employeeId}'
 */
        getAttendanceForm.head = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAttendance.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getAttendance.form = getAttendanceForm
const AttendanceController = { uploadPunchData, adminIndex, adminSummaryPage, adminGetEmployeeAttendance, adminGetAllAttendanceSummary, getAttendanceByDate, adminOverrideAttendance, adminDeleteAttendance, myAttendancePage, getEmployeeAttendance, punchEntry, getDailyDetails, getAttendance }

export default AttendanceController