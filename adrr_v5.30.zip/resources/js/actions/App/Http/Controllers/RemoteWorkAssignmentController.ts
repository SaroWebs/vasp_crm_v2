import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::index
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:17
 * @route '/api/remote-work-assignments'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/remote-work-assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::index
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:17
 * @route '/api/remote-work-assignments'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::index
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:17
 * @route '/api/remote-work-assignments'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::index
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:17
 * @route '/api/remote-work-assignments'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::index
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:17
 * @route '/api/remote-work-assignments'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::index
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:17
 * @route '/api/remote-work-assignments'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::index
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:17
 * @route '/api/remote-work-assignments'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::getEmployeeRemoteWorkAssignments
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:96
 * @route '/api/employees/{employee}/remote-work-assignments'
 */
export const getEmployeeRemoteWorkAssignments = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeRemoteWorkAssignments.url(args, options),
    method: 'get',
})

getEmployeeRemoteWorkAssignments.definition = {
    methods: ["get","head"],
    url: '/api/employees/{employee}/remote-work-assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::getEmployeeRemoteWorkAssignments
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:96
 * @route '/api/employees/{employee}/remote-work-assignments'
 */
getEmployeeRemoteWorkAssignments.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return getEmployeeRemoteWorkAssignments.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::getEmployeeRemoteWorkAssignments
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:96
 * @route '/api/employees/{employee}/remote-work-assignments'
 */
getEmployeeRemoteWorkAssignments.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeRemoteWorkAssignments.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::getEmployeeRemoteWorkAssignments
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:96
 * @route '/api/employees/{employee}/remote-work-assignments'
 */
getEmployeeRemoteWorkAssignments.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeRemoteWorkAssignments.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::getEmployeeRemoteWorkAssignments
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:96
 * @route '/api/employees/{employee}/remote-work-assignments'
 */
    const getEmployeeRemoteWorkAssignmentsForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeRemoteWorkAssignments.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::getEmployeeRemoteWorkAssignments
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:96
 * @route '/api/employees/{employee}/remote-work-assignments'
 */
        getEmployeeRemoteWorkAssignmentsForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeRemoteWorkAssignments.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::getEmployeeRemoteWorkAssignments
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:96
 * @route '/api/employees/{employee}/remote-work-assignments'
 */
        getEmployeeRemoteWorkAssignmentsForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeRemoteWorkAssignments.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeRemoteWorkAssignments.form = getEmployeeRemoteWorkAssignmentsForm
/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:44
 * @route '/admin/remote-work-assignments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/remote-work-assignments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:44
 * @route '/admin/remote-work-assignments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:44
 * @route '/admin/remote-work-assignments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:44
 * @route '/admin/remote-work-assignments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:44
 * @route '/admin/remote-work-assignments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:85
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
export const destroy = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/remote-work-assignments/{remoteWorkAssignment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:85
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
destroy.url = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { remoteWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { remoteWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    remoteWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        remoteWorkAssignment: typeof args.remoteWorkAssignment === 'object'
                ? args.remoteWorkAssignment.id
                : args.remoteWorkAssignment,
                }

    return destroy.definition.url
            .replace('{remoteWorkAssignment}', parsedArgs.remoteWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:85
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
destroy.delete = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:85
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
    const destroyForm = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:85
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
        destroyForm.delete = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const RemoteWorkAssignmentController = { index, getEmployeeRemoteWorkAssignments, store, destroy }

export default RemoteWorkAssignmentController