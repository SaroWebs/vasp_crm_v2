import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FieldWorkController::index
 * @see app/Http/Controllers/FieldWorkController.php:15
 * @route '/api/field-work-assignments'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/field-work-assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FieldWorkController::index
 * @see app/Http/Controllers/FieldWorkController.php:15
 * @route '/api/field-work-assignments'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::index
 * @see app/Http/Controllers/FieldWorkController.php:15
 * @route '/api/field-work-assignments'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FieldWorkController::index
 * @see app/Http/Controllers/FieldWorkController.php:15
 * @route '/api/field-work-assignments'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::index
 * @see app/Http/Controllers/FieldWorkController.php:15
 * @route '/api/field-work-assignments'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::index
 * @see app/Http/Controllers/FieldWorkController.php:15
 * @route '/api/field-work-assignments'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FieldWorkController::index
 * @see app/Http/Controllers/FieldWorkController.php:15
 * @route '/api/field-work-assignments'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\FieldWorkController::show
 * @see app/Http/Controllers/FieldWorkController.php:88
 * @route '/api/field-work-assignments/{fieldWorkAssignment}'
 */
export const show = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/field-work-assignments/{fieldWorkAssignment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FieldWorkController::show
 * @see app/Http/Controllers/FieldWorkController.php:88
 * @route '/api/field-work-assignments/{fieldWorkAssignment}'
 */
show.url = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkAssignment: typeof args.fieldWorkAssignment === 'object'
                ? args.fieldWorkAssignment.id
                : args.fieldWorkAssignment,
                }

    return show.definition.url
            .replace('{fieldWorkAssignment}', parsedArgs.fieldWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::show
 * @see app/Http/Controllers/FieldWorkController.php:88
 * @route '/api/field-work-assignments/{fieldWorkAssignment}'
 */
show.get = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FieldWorkController::show
 * @see app/Http/Controllers/FieldWorkController.php:88
 * @route '/api/field-work-assignments/{fieldWorkAssignment}'
 */
show.head = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::show
 * @see app/Http/Controllers/FieldWorkController.php:88
 * @route '/api/field-work-assignments/{fieldWorkAssignment}'
 */
    const showForm = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::show
 * @see app/Http/Controllers/FieldWorkController.php:88
 * @route '/api/field-work-assignments/{fieldWorkAssignment}'
 */
        showForm.get = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FieldWorkController::show
 * @see app/Http/Controllers/FieldWorkController.php:88
 * @route '/api/field-work-assignments/{fieldWorkAssignment}'
 */
        showForm.head = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\FieldWorkController::getEmployeeFieldWorkAssignments
 * @see app/Http/Controllers/FieldWorkController.php:132
 * @route '/api/employees/{employee}/field-work-assignments'
 */
export const getEmployeeFieldWorkAssignments = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeFieldWorkAssignments.url(args, options),
    method: 'get',
})

getEmployeeFieldWorkAssignments.definition = {
    methods: ["get","head"],
    url: '/api/employees/{employee}/field-work-assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FieldWorkController::getEmployeeFieldWorkAssignments
 * @see app/Http/Controllers/FieldWorkController.php:132
 * @route '/api/employees/{employee}/field-work-assignments'
 */
getEmployeeFieldWorkAssignments.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return getEmployeeFieldWorkAssignments.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::getEmployeeFieldWorkAssignments
 * @see app/Http/Controllers/FieldWorkController.php:132
 * @route '/api/employees/{employee}/field-work-assignments'
 */
getEmployeeFieldWorkAssignments.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeFieldWorkAssignments.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FieldWorkController::getEmployeeFieldWorkAssignments
 * @see app/Http/Controllers/FieldWorkController.php:132
 * @route '/api/employees/{employee}/field-work-assignments'
 */
getEmployeeFieldWorkAssignments.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeFieldWorkAssignments.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::getEmployeeFieldWorkAssignments
 * @see app/Http/Controllers/FieldWorkController.php:132
 * @route '/api/employees/{employee}/field-work-assignments'
 */
    const getEmployeeFieldWorkAssignmentsForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeFieldWorkAssignments.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::getEmployeeFieldWorkAssignments
 * @see app/Http/Controllers/FieldWorkController.php:132
 * @route '/api/employees/{employee}/field-work-assignments'
 */
        getEmployeeFieldWorkAssignmentsForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeFieldWorkAssignments.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FieldWorkController::getEmployeeFieldWorkAssignments
 * @see app/Http/Controllers/FieldWorkController.php:132
 * @route '/api/employees/{employee}/field-work-assignments'
 */
        getEmployeeFieldWorkAssignmentsForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeFieldWorkAssignments.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeFieldWorkAssignments.form = getEmployeeFieldWorkAssignmentsForm
/**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:52
 * @route '/admin/field-work-assignments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/field-work-assignments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:52
 * @route '/admin/field-work-assignments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:52
 * @route '/admin/field-work-assignments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:52
 * @route '/admin/field-work-assignments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:52
 * @route '/admin/field-work-assignments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:99
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
export const update = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/field-work-assignments/{fieldWorkAssignment}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:99
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
update.url = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkAssignment: typeof args.fieldWorkAssignment === 'object'
                ? args.fieldWorkAssignment.id
                : args.fieldWorkAssignment,
                }

    return update.definition.url
            .replace('{fieldWorkAssignment}', parsedArgs.fieldWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:99
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
update.put = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:99
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
    const updateForm = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:99
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
        updateForm.put = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:121
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
export const destroy = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/field-work-assignments/{fieldWorkAssignment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:121
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
destroy.url = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkAssignment: typeof args.fieldWorkAssignment === 'object'
                ? args.fieldWorkAssignment.id
                : args.fieldWorkAssignment,
                }

    return destroy.definition.url
            .replace('{fieldWorkAssignment}', parsedArgs.fieldWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:121
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
destroy.delete = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:121
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
    const destroyForm = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:121
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
        destroyForm.delete = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:159
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
export const approve = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/field-work-assignments/{fieldWorkAssignment}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:159
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
approve.url = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkAssignment: typeof args.fieldWorkAssignment === 'object'
                ? args.fieldWorkAssignment.id
                : args.fieldWorkAssignment,
                }

    return approve.definition.url
            .replace('{fieldWorkAssignment}', parsedArgs.fieldWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:159
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
approve.post = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:159
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
    const approveForm = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:159
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
        approveForm.post = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:176
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
export const reject = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/admin/field-work-assignments/{fieldWorkAssignment}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:176
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
reject.url = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkAssignment: typeof args.fieldWorkAssignment === 'object'
                ? args.fieldWorkAssignment.id
                : args.fieldWorkAssignment,
                }

    return reject.definition.url
            .replace('{fieldWorkAssignment}', parsedArgs.fieldWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:176
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
reject.post = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:176
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
    const rejectForm = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:176
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
        rejectForm.post = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
const FieldWorkController = { index, show, getEmployeeFieldWorkAssignments, store, update, destroy, approve, reject }

export default FieldWorkController