import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:10
 * @route '/admin/sales-leads'
 */
export const adminIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})

adminIndex.definition = {
    methods: ["get","head"],
    url: '/admin/sales-leads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:10
 * @route '/admin/sales-leads'
 */
adminIndex.url = (options?: RouteQueryOptions) => {
    return adminIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:10
 * @route '/admin/sales-leads'
 */
adminIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:10
 * @route '/admin/sales-leads'
 */
adminIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:10
 * @route '/admin/sales-leads'
 */
    const adminIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:10
 * @route '/admin/sales-leads'
 */
        adminIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:10
 * @route '/admin/sales-leads'
 */
        adminIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminIndex.form = adminIndexForm
/**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:15
 * @route '/my/sales-leads'
 */
export const myIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myIndex.url(options),
    method: 'get',
})

myIndex.definition = {
    methods: ["get","head"],
    url: '/my/sales-leads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:15
 * @route '/my/sales-leads'
 */
myIndex.url = (options?: RouteQueryOptions) => {
    return myIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:15
 * @route '/my/sales-leads'
 */
myIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:15
 * @route '/my/sales-leads'
 */
myIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:15
 * @route '/my/sales-leads'
 */
    const myIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: myIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:15
 * @route '/my/sales-leads'
 */
        myIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:15
 * @route '/my/sales-leads'
 */
        myIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    myIndex.form = myIndexForm
const SalesLeadController = { adminIndex, myIndex }

export default SalesLeadController