import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ShiftController::index
 * @see app/Http/Controllers/ShiftController.php:21
 * @route '/admin/shifts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/shifts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShiftController::index
 * @see app/Http/Controllers/ShiftController.php:21
 * @route '/admin/shifts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::index
 * @see app/Http/Controllers/ShiftController.php:21
 * @route '/admin/shifts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShiftController::index
 * @see app/Http/Controllers/ShiftController.php:21
 * @route '/admin/shifts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShiftController::index
 * @see app/Http/Controllers/ShiftController.php:21
 * @route '/admin/shifts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShiftController::index
 * @see app/Http/Controllers/ShiftController.php:21
 * @route '/admin/shifts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShiftController::index
 * @see app/Http/Controllers/ShiftController.php:21
 * @route '/admin/shifts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ShiftController::shifts
 * @see app/Http/Controllers/ShiftController.php:26
 * @route '/admin/api/shifts'
 */
export const shifts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: shifts.url(options),
    method: 'get',
})

shifts.definition = {
    methods: ["get","head"],
    url: '/admin/api/shifts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShiftController::shifts
 * @see app/Http/Controllers/ShiftController.php:26
 * @route '/admin/api/shifts'
 */
shifts.url = (options?: RouteQueryOptions) => {
    return shifts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::shifts
 * @see app/Http/Controllers/ShiftController.php:26
 * @route '/admin/api/shifts'
 */
shifts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: shifts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShiftController::shifts
 * @see app/Http/Controllers/ShiftController.php:26
 * @route '/admin/api/shifts'
 */
shifts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: shifts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShiftController::shifts
 * @see app/Http/Controllers/ShiftController.php:26
 * @route '/admin/api/shifts'
 */
    const shiftsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: shifts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShiftController::shifts
 * @see app/Http/Controllers/ShiftController.php:26
 * @route '/admin/api/shifts'
 */
        shiftsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: shifts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShiftController::shifts
 * @see app/Http/Controllers/ShiftController.php:26
 * @route '/admin/api/shifts'
 */
        shiftsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: shifts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    shifts.form = shiftsForm
/**
* @see \App\Http\Controllers\ShiftController::storeShift
 * @see app/Http/Controllers/ShiftController.php:39
 * @route '/admin/api/shifts'
 */
export const storeShift = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeShift.url(options),
    method: 'post',
})

storeShift.definition = {
    methods: ["post"],
    url: '/admin/api/shifts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ShiftController::storeShift
 * @see app/Http/Controllers/ShiftController.php:39
 * @route '/admin/api/shifts'
 */
storeShift.url = (options?: RouteQueryOptions) => {
    return storeShift.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::storeShift
 * @see app/Http/Controllers/ShiftController.php:39
 * @route '/admin/api/shifts'
 */
storeShift.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeShift.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ShiftController::storeShift
 * @see app/Http/Controllers/ShiftController.php:39
 * @route '/admin/api/shifts'
 */
    const storeShiftForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeShift.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShiftController::storeShift
 * @see app/Http/Controllers/ShiftController.php:39
 * @route '/admin/api/shifts'
 */
        storeShiftForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeShift.url(options),
            method: 'post',
        })
    
    storeShift.form = storeShiftForm
/**
* @see \App\Http\Controllers\ShiftController::updateShift
 * @see app/Http/Controllers/ShiftController.php:56
 * @route '/admin/api/shifts/{shift}'
 */
export const updateShift = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateShift.url(args, options),
    method: 'patch',
})

updateShift.definition = {
    methods: ["patch"],
    url: '/admin/api/shifts/{shift}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ShiftController::updateShift
 * @see app/Http/Controllers/ShiftController.php:56
 * @route '/admin/api/shifts/{shift}'
 */
updateShift.url = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shift: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { shift: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    shift: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shift: typeof args.shift === 'object'
                ? args.shift.id
                : args.shift,
                }

    return updateShift.definition.url
            .replace('{shift}', parsedArgs.shift.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::updateShift
 * @see app/Http/Controllers/ShiftController.php:56
 * @route '/admin/api/shifts/{shift}'
 */
updateShift.patch = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateShift.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ShiftController::updateShift
 * @see app/Http/Controllers/ShiftController.php:56
 * @route '/admin/api/shifts/{shift}'
 */
    const updateShiftForm = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateShift.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShiftController::updateShift
 * @see app/Http/Controllers/ShiftController.php:56
 * @route '/admin/api/shifts/{shift}'
 */
        updateShiftForm.patch = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateShift.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateShift.form = updateShiftForm
/**
* @see \App\Http\Controllers\ShiftController::destroyShift
 * @see app/Http/Controllers/ShiftController.php:73
 * @route '/admin/api/shifts/{shift}'
 */
export const destroyShift = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyShift.url(args, options),
    method: 'delete',
})

destroyShift.definition = {
    methods: ["delete"],
    url: '/admin/api/shifts/{shift}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ShiftController::destroyShift
 * @see app/Http/Controllers/ShiftController.php:73
 * @route '/admin/api/shifts/{shift}'
 */
destroyShift.url = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shift: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { shift: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    shift: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shift: typeof args.shift === 'object'
                ? args.shift.id
                : args.shift,
                }

    return destroyShift.definition.url
            .replace('{shift}', parsedArgs.shift.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::destroyShift
 * @see app/Http/Controllers/ShiftController.php:73
 * @route '/admin/api/shifts/{shift}'
 */
destroyShift.delete = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyShift.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ShiftController::destroyShift
 * @see app/Http/Controllers/ShiftController.php:73
 * @route '/admin/api/shifts/{shift}'
 */
    const destroyShiftForm = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyShift.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShiftController::destroyShift
 * @see app/Http/Controllers/ShiftController.php:73
 * @route '/admin/api/shifts/{shift}'
 */
        destroyShiftForm.delete = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyShift.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyShift.form = destroyShiftForm
/**
* @see \App\Http\Controllers\ShiftController::assignments
 * @see app/Http/Controllers/ShiftController.php:83
 * @route '/admin/api/shift-assignments'
 */
export const assignments = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assignments.url(options),
    method: 'get',
})

assignments.definition = {
    methods: ["get","head"],
    url: '/admin/api/shift-assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShiftController::assignments
 * @see app/Http/Controllers/ShiftController.php:83
 * @route '/admin/api/shift-assignments'
 */
assignments.url = (options?: RouteQueryOptions) => {
    return assignments.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::assignments
 * @see app/Http/Controllers/ShiftController.php:83
 * @route '/admin/api/shift-assignments'
 */
assignments.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assignments.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShiftController::assignments
 * @see app/Http/Controllers/ShiftController.php:83
 * @route '/admin/api/shift-assignments'
 */
assignments.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: assignments.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShiftController::assignments
 * @see app/Http/Controllers/ShiftController.php:83
 * @route '/admin/api/shift-assignments'
 */
    const assignmentsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: assignments.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShiftController::assignments
 * @see app/Http/Controllers/ShiftController.php:83
 * @route '/admin/api/shift-assignments'
 */
        assignmentsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: assignments.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShiftController::assignments
 * @see app/Http/Controllers/ShiftController.php:83
 * @route '/admin/api/shift-assignments'
 */
        assignmentsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: assignments.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    assignments.form = assignmentsForm
/**
* @see \App\Http\Controllers\ShiftController::employeeAssignments
 * @see app/Http/Controllers/ShiftController.php:184
 * @route '/admin/api/employees/{employee}/shift-assignments'
 */
export const employeeAssignments = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employeeAssignments.url(args, options),
    method: 'get',
})

employeeAssignments.definition = {
    methods: ["get","head"],
    url: '/admin/api/employees/{employee}/shift-assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShiftController::employeeAssignments
 * @see app/Http/Controllers/ShiftController.php:184
 * @route '/admin/api/employees/{employee}/shift-assignments'
 */
employeeAssignments.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return employeeAssignments.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::employeeAssignments
 * @see app/Http/Controllers/ShiftController.php:184
 * @route '/admin/api/employees/{employee}/shift-assignments'
 */
employeeAssignments.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employeeAssignments.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShiftController::employeeAssignments
 * @see app/Http/Controllers/ShiftController.php:184
 * @route '/admin/api/employees/{employee}/shift-assignments'
 */
employeeAssignments.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: employeeAssignments.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShiftController::employeeAssignments
 * @see app/Http/Controllers/ShiftController.php:184
 * @route '/admin/api/employees/{employee}/shift-assignments'
 */
    const employeeAssignmentsForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: employeeAssignments.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShiftController::employeeAssignments
 * @see app/Http/Controllers/ShiftController.php:184
 * @route '/admin/api/employees/{employee}/shift-assignments'
 */
        employeeAssignmentsForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employeeAssignments.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShiftController::employeeAssignments
 * @see app/Http/Controllers/ShiftController.php:184
 * @route '/admin/api/employees/{employee}/shift-assignments'
 */
        employeeAssignmentsForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employeeAssignments.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    employeeAssignments.form = employeeAssignmentsForm
/**
* @see \App\Http\Controllers\ShiftController::storeAssignment
 * @see app/Http/Controllers/ShiftController.php:96
 * @route '/admin/api/shift-assignments'
 */
export const storeAssignment = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAssignment.url(options),
    method: 'post',
})

storeAssignment.definition = {
    methods: ["post"],
    url: '/admin/api/shift-assignments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ShiftController::storeAssignment
 * @see app/Http/Controllers/ShiftController.php:96
 * @route '/admin/api/shift-assignments'
 */
storeAssignment.url = (options?: RouteQueryOptions) => {
    return storeAssignment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::storeAssignment
 * @see app/Http/Controllers/ShiftController.php:96
 * @route '/admin/api/shift-assignments'
 */
storeAssignment.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAssignment.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ShiftController::storeAssignment
 * @see app/Http/Controllers/ShiftController.php:96
 * @route '/admin/api/shift-assignments'
 */
    const storeAssignmentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAssignment.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShiftController::storeAssignment
 * @see app/Http/Controllers/ShiftController.php:96
 * @route '/admin/api/shift-assignments'
 */
        storeAssignmentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAssignment.url(options),
            method: 'post',
        })
    
    storeAssignment.form = storeAssignmentForm
/**
* @see \App\Http\Controllers\ShiftController::updateAssignment
 * @see app/Http/Controllers/ShiftController.php:140
 * @route '/admin/api/shift-assignments/{assignment}'
 */
export const updateAssignment = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateAssignment.url(args, options),
    method: 'patch',
})

updateAssignment.definition = {
    methods: ["patch"],
    url: '/admin/api/shift-assignments/{assignment}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ShiftController::updateAssignment
 * @see app/Http/Controllers/ShiftController.php:140
 * @route '/admin/api/shift-assignments/{assignment}'
 */
updateAssignment.url = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { assignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    assignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        assignment: typeof args.assignment === 'object'
                ? args.assignment.id
                : args.assignment,
                }

    return updateAssignment.definition.url
            .replace('{assignment}', parsedArgs.assignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::updateAssignment
 * @see app/Http/Controllers/ShiftController.php:140
 * @route '/admin/api/shift-assignments/{assignment}'
 */
updateAssignment.patch = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateAssignment.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ShiftController::updateAssignment
 * @see app/Http/Controllers/ShiftController.php:140
 * @route '/admin/api/shift-assignments/{assignment}'
 */
    const updateAssignmentForm = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateAssignment.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShiftController::updateAssignment
 * @see app/Http/Controllers/ShiftController.php:140
 * @route '/admin/api/shift-assignments/{assignment}'
 */
        updateAssignmentForm.patch = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateAssignment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateAssignment.form = updateAssignmentForm
/**
* @see \App\Http\Controllers\ShiftController::destroyAssignment
 * @see app/Http/Controllers/ShiftController.php:157
 * @route '/admin/api/shift-assignments/{assignment}'
 */
export const destroyAssignment = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAssignment.url(args, options),
    method: 'delete',
})

destroyAssignment.definition = {
    methods: ["delete"],
    url: '/admin/api/shift-assignments/{assignment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ShiftController::destroyAssignment
 * @see app/Http/Controllers/ShiftController.php:157
 * @route '/admin/api/shift-assignments/{assignment}'
 */
destroyAssignment.url = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { assignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    assignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        assignment: typeof args.assignment === 'object'
                ? args.assignment.id
                : args.assignment,
                }

    return destroyAssignment.definition.url
            .replace('{assignment}', parsedArgs.assignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::destroyAssignment
 * @see app/Http/Controllers/ShiftController.php:157
 * @route '/admin/api/shift-assignments/{assignment}'
 */
destroyAssignment.delete = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAssignment.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ShiftController::destroyAssignment
 * @see app/Http/Controllers/ShiftController.php:157
 * @route '/admin/api/shift-assignments/{assignment}'
 */
    const destroyAssignmentForm = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyAssignment.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShiftController::destroyAssignment
 * @see app/Http/Controllers/ShiftController.php:157
 * @route '/admin/api/shift-assignments/{assignment}'
 */
        destroyAssignmentForm.delete = (args: { assignment: number | { id: number } } | [assignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyAssignment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyAssignment.form = destroyAssignmentForm
/**
* @see \App\Http\Controllers\ShiftController::employees
 * @see app/Http/Controllers/ShiftController.php:167
 * @route '/admin/api/shifts/employees'
 */
export const employees = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employees.url(options),
    method: 'get',
})

employees.definition = {
    methods: ["get","head"],
    url: '/admin/api/shifts/employees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShiftController::employees
 * @see app/Http/Controllers/ShiftController.php:167
 * @route '/admin/api/shifts/employees'
 */
employees.url = (options?: RouteQueryOptions) => {
    return employees.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::employees
 * @see app/Http/Controllers/ShiftController.php:167
 * @route '/admin/api/shifts/employees'
 */
employees.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employees.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShiftController::employees
 * @see app/Http/Controllers/ShiftController.php:167
 * @route '/admin/api/shifts/employees'
 */
employees.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: employees.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShiftController::employees
 * @see app/Http/Controllers/ShiftController.php:167
 * @route '/admin/api/shifts/employees'
 */
    const employeesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: employees.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShiftController::employees
 * @see app/Http/Controllers/ShiftController.php:167
 * @route '/admin/api/shifts/employees'
 */
        employeesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employees.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShiftController::employees
 * @see app/Http/Controllers/ShiftController.php:167
 * @route '/admin/api/shifts/employees'
 */
        employeesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employees.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    employees.form = employeesForm
/**
* @see \App\Http\Controllers\ShiftController::changeShift
 * @see app/Http/Controllers/ShiftController.php:201
 * @route '/api/employees/{employee}/change-shift'
 */
export const changeShift = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changeShift.url(args, options),
    method: 'post',
})

changeShift.definition = {
    methods: ["post"],
    url: '/api/employees/{employee}/change-shift',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ShiftController::changeShift
 * @see app/Http/Controllers/ShiftController.php:201
 * @route '/api/employees/{employee}/change-shift'
 */
changeShift.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return changeShift.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftController::changeShift
 * @see app/Http/Controllers/ShiftController.php:201
 * @route '/api/employees/{employee}/change-shift'
 */
changeShift.post = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changeShift.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ShiftController::changeShift
 * @see app/Http/Controllers/ShiftController.php:201
 * @route '/api/employees/{employee}/change-shift'
 */
    const changeShiftForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: changeShift.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShiftController::changeShift
 * @see app/Http/Controllers/ShiftController.php:201
 * @route '/api/employees/{employee}/change-shift'
 */
        changeShiftForm.post = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: changeShift.url(args, options),
            method: 'post',
        })
    
    changeShift.form = changeShiftForm
const ShiftController = { index, shifts, storeShift, updateShift, destroyShift, assignments, employeeAssignments, storeAssignment, updateAssignment, destroyAssignment, employees, changeShift }

export default ShiftController