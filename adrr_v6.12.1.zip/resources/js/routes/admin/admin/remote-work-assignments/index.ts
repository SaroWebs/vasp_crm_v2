import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:49
 * @route '/admin/remote-work-assignments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/remote-work-assignments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:49
 * @route '/admin/remote-work-assignments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:49
 * @route '/admin/remote-work-assignments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:49
 * @route '/admin/remote-work-assignments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::store
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:49
 * @route '/admin/remote-work-assignments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::update
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:94
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
export const update = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/remote-work-assignments/{remoteWorkAssignment}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::update
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:94
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
update.url = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { remoteWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { remoteWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    remoteWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        remoteWorkAssignment: typeof args.remoteWorkAssignment === 'object'
                ? args.remoteWorkAssignment.id
                : args.remoteWorkAssignment,
                }

    return update.definition.url
            .replace('{remoteWorkAssignment}', parsedArgs.remoteWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::update
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:94
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
update.put = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::update
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:94
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
    const updateForm = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::update
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:94
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
        updateForm.put = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:151
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
export const destroy = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/remote-work-assignments/{remoteWorkAssignment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:151
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
destroy.url = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { remoteWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { remoteWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    remoteWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        remoteWorkAssignment: typeof args.remoteWorkAssignment === 'object'
                ? args.remoteWorkAssignment.id
                : args.remoteWorkAssignment,
                }

    return destroy.definition.url
            .replace('{remoteWorkAssignment}', parsedArgs.remoteWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:151
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
destroy.delete = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:151
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
    const destroyForm = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkAssignmentController::destroy
 * @see app/Http/Controllers/RemoteWorkAssignmentController.php:151
 * @route '/admin/remote-work-assignments/{remoteWorkAssignment}'
 */
        destroyForm.delete = (args: { remoteWorkAssignment: number | { id: number } } | [remoteWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const remoteWorkAssignments = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default remoteWorkAssignments