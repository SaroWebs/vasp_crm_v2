import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:56
 * @route '/admin/field-work-assignments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/field-work-assignments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:56
 * @route '/admin/field-work-assignments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:56
 * @route '/admin/field-work-assignments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:56
 * @route '/admin/field-work-assignments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::store
 * @see app/Http/Controllers/FieldWorkController.php:56
 * @route '/admin/field-work-assignments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:102
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
export const update = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/field-work-assignments/{fieldWorkAssignment}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:102
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
update.url = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkAssignment: typeof args.fieldWorkAssignment === 'object'
                ? args.fieldWorkAssignment.id
                : args.fieldWorkAssignment,
                }

    return update.definition.url
            .replace('{fieldWorkAssignment}', parsedArgs.fieldWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:102
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
update.put = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:102
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
    const updateForm = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::update
 * @see app/Http/Controllers/FieldWorkController.php:102
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
        updateForm.put = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:136
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
export const destroy = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/field-work-assignments/{fieldWorkAssignment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:136
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
destroy.url = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkAssignment: typeof args.fieldWorkAssignment === 'object'
                ? args.fieldWorkAssignment.id
                : args.fieldWorkAssignment,
                }

    return destroy.definition.url
            .replace('{fieldWorkAssignment}', parsedArgs.fieldWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:136
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
destroy.delete = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:136
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
    const destroyForm = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::destroy
 * @see app/Http/Controllers/FieldWorkController.php:136
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}'
 */
        destroyForm.delete = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:181
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
export const approve = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/field-work-assignments/{fieldWorkAssignment}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:181
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
approve.url = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkAssignment: typeof args.fieldWorkAssignment === 'object'
                ? args.fieldWorkAssignment.id
                : args.fieldWorkAssignment,
                }

    return approve.definition.url
            .replace('{fieldWorkAssignment}', parsedArgs.fieldWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:181
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
approve.post = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:181
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
    const approveForm = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::approve
 * @see app/Http/Controllers/FieldWorkController.php:181
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/approve'
 */
        approveForm.post = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:205
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
export const reject = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/admin/field-work-assignments/{fieldWorkAssignment}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:205
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
reject.url = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fieldWorkAssignment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fieldWorkAssignment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fieldWorkAssignment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fieldWorkAssignment: typeof args.fieldWorkAssignment === 'object'
                ? args.fieldWorkAssignment.id
                : args.fieldWorkAssignment,
                }

    return reject.definition.url
            .replace('{fieldWorkAssignment}', parsedArgs.fieldWorkAssignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:205
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
reject.post = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:205
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
    const rejectForm = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FieldWorkController::reject
 * @see app/Http/Controllers/FieldWorkController.php:205
 * @route '/admin/field-work-assignments/{fieldWorkAssignment}/reject'
 */
        rejectForm.post = (args: { fieldWorkAssignment: number | { id: number } } | [fieldWorkAssignment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
const fieldWorkAssignments = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
approve: Object.assign(approve, approve),
reject: Object.assign(reject, reject),
}

export default fieldWorkAssignments