import remoteWorkAssignments from './remote-work-assignments'
import fieldWorkAssignments from './field-work-assignments'
const admin = {
    remoteWorkAssignments: Object.assign(remoteWorkAssignments, remoteWorkAssignments),
fieldWorkAssignments: Object.assign(fieldWorkAssignments, fieldWorkAssignments),
}

export default admin