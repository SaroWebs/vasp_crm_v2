import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import loginDf2c2a from './login'
import password from './password'
import salesLeads from './sales-leads'
import api from './api'
import logout179e67 from './logout'
import clients from './clients'
import projects from './projects'
import products from './products'
import tickets from './tickets'
import comments from './comments'
import ticket from './ticket'
import tasks from './tasks'
import departments from './departments'
import notifications from './notifications'
import menu from './menu'
import rolesPermissions from './roles-permissions'
import roles from './roles'
import permissions from './permissions'
import users from './users'
import employees from './employees'
import visitors from './visitors'
import employee from './employee'
import attendance from './attendance'
import shifts from './shifts'
import workloadMatrix from './workload-matrix'
import reports from './reports'
import admin from './admin'
import leaveTypes from './leave-types'
import holidays from './holidays'
/**
* @see \App\Http\Controllers\AdminAuthController::login
 * @see app/Http/Controllers/AdminAuthController.php:13
 * @route '/admin/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/admin/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminAuthController::login
 * @see app/Http/Controllers/AdminAuthController.php:13
 * @route '/admin/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAuthController::login
 * @see app/Http/Controllers/AdminAuthController.php:13
 * @route '/admin/login'
 */
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminAuthController::login
 * @see app/Http/Controllers/AdminAuthController.php:13
 * @route '/admin/login'
 */
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminAuthController::login
 * @see app/Http/Controllers/AdminAuthController.php:13
 * @route '/admin/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: login.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminAuthController::login
 * @see app/Http/Controllers/AdminAuthController.php:13
 * @route '/admin/login'
 */
        loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminAuthController::login
 * @see app/Http/Controllers/AdminAuthController.php:13
 * @route '/admin/login'
 */
        loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\AdminDashboardController::dashboard
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::dashboard
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::dashboard
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::dashboard
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::dashboard
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::dashboard
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::dashboard
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\AdminAuthController::logout
 * @see app/Http/Controllers/AdminAuthController.php:58
 * @route '/admin/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/admin/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminAuthController::logout
 * @see app/Http/Controllers/AdminAuthController.php:58
 * @route '/admin/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAuthController::logout
 * @see app/Http/Controllers/AdminAuthController.php:58
 * @route '/admin/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminAuthController::logout
 * @see app/Http/Controllers/AdminAuthController.php:58
 * @route '/admin/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminAuthController::logout
 * @see app/Http/Controllers/AdminAuthController.php:58
 * @route '/admin/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
const adminNamespace = {
    login: Object.assign(login, loginDf2c2a),
password: Object.assign(password, password),
dashboard: Object.assign(dashboard, dashboard),
salesLeads: Object.assign(salesLeads, salesLeads),
api: Object.assign(api, api),
logout: Object.assign(logout, logout179e67),
clients: Object.assign(clients, clients),
projects: Object.assign(projects, projects),
products: Object.assign(products, products),
tickets: Object.assign(tickets, tickets),
comments: Object.assign(comments, comments),
ticket: Object.assign(ticket, ticket),
tasks: Object.assign(tasks, tasks),
departments: Object.assign(departments, departments),
notifications: Object.assign(notifications, notifications),
menu: Object.assign(menu, menu),
rolesPermissions: Object.assign(rolesPermissions, rolesPermissions),
roles: Object.assign(roles, roles),
permissions: Object.assign(permissions, permissions),
users: Object.assign(users, users),
employees: Object.assign(employees, employees),
visitors: Object.assign(visitors, visitors),
employee: Object.assign(employee, employee),
attendance: Object.assign(attendance, attendance),
shifts: Object.assign(shifts, shifts),
workloadMatrix: Object.assign(workloadMatrix, workloadMatrix),
reports: Object.assign(reports, reports),
admin: Object.assign(admin, admin),
leaveTypes: Object.assign(leaveTypes, leaveTypes),
holidays: Object.assign(holidays, holidays),
}

export default adminNamespace