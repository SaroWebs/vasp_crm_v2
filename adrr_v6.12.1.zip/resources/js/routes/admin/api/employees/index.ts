import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\EmployeeController::list
 * @see app/Http/Controllers/EmployeeController.php:85
 * @route '/admin/api/employees'
 */
export const list = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: list.url(options),
    method: 'get',
})

list.definition = {
    methods: ["get","head"],
    url: '/admin/api/employees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmployeeController::list
 * @see app/Http/Controllers/EmployeeController.php:85
 * @route '/admin/api/employees'
 */
list.url = (options?: RouteQueryOptions) => {
    return list.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeController::list
 * @see app/Http/Controllers/EmployeeController.php:85
 * @route '/admin/api/employees'
 */
list.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: list.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmployeeController::list
 * @see app/Http/Controllers/EmployeeController.php:85
 * @route '/admin/api/employees'
 */
list.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: list.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmployeeController::list
 * @see app/Http/Controllers/EmployeeController.php:85
 * @route '/admin/api/employees'
 */
    const listForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: list.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmployeeController::list
 * @see app/Http/Controllers/EmployeeController.php:85
 * @route '/admin/api/employees'
 */
        listForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: list.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmployeeController::list
 * @see app/Http/Controllers/EmployeeController.php:85
 * @route '/admin/api/employees'
 */
        listForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: list.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    list.form = listForm
const employees = {
    list: Object.assign(list, list),
}

export default employees