import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
import consolidated9a5e12 from './consolidated'
/**
* @see \App\Http\Controllers\ReportController::employees
 * @see app/Http/Controllers/ReportController.php:584
 * @route '/admin/api/reports/employees'
 */
export const employees = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employees.url(options),
    method: 'get',
})

employees.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/employees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::employees
 * @see app/Http/Controllers/ReportController.php:584
 * @route '/admin/api/reports/employees'
 */
employees.url = (options?: RouteQueryOptions) => {
    return employees.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::employees
 * @see app/Http/Controllers/ReportController.php:584
 * @route '/admin/api/reports/employees'
 */
employees.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employees.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::employees
 * @see app/Http/Controllers/ReportController.php:584
 * @route '/admin/api/reports/employees'
 */
employees.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: employees.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::employees
 * @see app/Http/Controllers/ReportController.php:584
 * @route '/admin/api/reports/employees'
 */
    const employeesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: employees.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::employees
 * @see app/Http/Controllers/ReportController.php:584
 * @route '/admin/api/reports/employees'
 */
        employeesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employees.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::employees
 * @see app/Http/Controllers/ReportController.php:584
 * @route '/admin/api/reports/employees'
 */
        employeesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employees.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    employees.form = employeesForm
/**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:80
 * @route '/admin/api/reports'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/api/reports',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:80
 * @route '/admin/api/reports'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:80
 * @route '/admin/api/reports'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:80
 * @route '/admin/api/reports'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:80
 * @route '/admin/api/reports'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ReportController::daily
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
export const daily = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: daily.url(args, options),
    method: 'get',
})

daily.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/daily/{userId}/{date}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::daily
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
daily.url = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                    date: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                                date: args.date,
                }

    return daily.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace('{date}', parsedArgs.date.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::daily
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
daily.get = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: daily.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::daily
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
daily.head = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: daily.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::daily
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
    const dailyForm = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: daily.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::daily
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
        dailyForm.get = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: daily.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::daily
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
        dailyForm.head = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: daily.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    daily.form = dailyForm
/**
* @see \App\Http\Controllers\ReportController::connectTask
 * @see app/Http/Controllers/ReportController.php:125
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
export const connectTask = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: connectTask.url(args, options),
    method: 'post',
})

connectTask.definition = {
    methods: ["post"],
    url: '/admin/api/reports/{reportId}/tasks/{taskId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReportController::connectTask
 * @see app/Http/Controllers/ReportController.php:125
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
connectTask.url = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                    taskId: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                                taskId: args.taskId,
                }

    return connectTask.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace('{taskId}', parsedArgs.taskId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::connectTask
 * @see app/Http/Controllers/ReportController.php:125
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
connectTask.post = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: connectTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReportController::connectTask
 * @see app/Http/Controllers/ReportController.php:125
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
    const connectTaskForm = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: connectTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::connectTask
 * @see app/Http/Controllers/ReportController.php:125
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
        connectTaskForm.post = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: connectTask.url(args, options),
            method: 'post',
        })
    
    connectTask.form = connectTaskForm
/**
* @see \App\Http\Controllers\ReportController::disconnectTask
 * @see app/Http/Controllers/ReportController.php:134
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
export const disconnectTask = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disconnectTask.url(args, options),
    method: 'delete',
})

disconnectTask.definition = {
    methods: ["delete"],
    url: '/admin/api/reports/{reportId}/tasks/{taskId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ReportController::disconnectTask
 * @see app/Http/Controllers/ReportController.php:134
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
disconnectTask.url = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                    taskId: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                                taskId: args.taskId,
                }

    return disconnectTask.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace('{taskId}', parsedArgs.taskId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::disconnectTask
 * @see app/Http/Controllers/ReportController.php:134
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
disconnectTask.delete = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disconnectTask.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ReportController::disconnectTask
 * @see app/Http/Controllers/ReportController.php:134
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
    const disconnectTaskForm = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: disconnectTask.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::disconnectTask
 * @see app/Http/Controllers/ReportController.php:134
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
        disconnectTaskForm.delete = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: disconnectTask.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    disconnectTask.form = disconnectTaskForm
/**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/admin/api/reports/{reportId}/attachments'
 */
export const addAttachment = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addAttachment.url(args, options),
    method: 'post',
})

addAttachment.definition = {
    methods: ["post"],
    url: '/admin/api/reports/{reportId}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/admin/api/reports/{reportId}/attachments'
 */
addAttachment.url = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reportId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                }

    return addAttachment.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/admin/api/reports/{reportId}/attachments'
 */
addAttachment.post = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addAttachment.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/admin/api/reports/{reportId}/attachments'
 */
    const addAttachmentForm = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addAttachment.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:171
 * @route '/admin/api/reports/{reportId}/attachments'
 */
        addAttachmentForm.post = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addAttachment.url(args, options),
            method: 'post',
        })
    
    addAttachment.form = addAttachmentForm
/**
* @see \App\Http\Controllers\ReportController::employee
 * @see app/Http/Controllers/ReportController.php:189
 * @route '/admin/api/reports/employee/{userId}'
 */
export const employee = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employee.url(args, options),
    method: 'get',
})

employee.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/employee/{userId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::employee
 * @see app/Http/Controllers/ReportController.php:189
 * @route '/admin/api/reports/employee/{userId}'
 */
employee.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return employee.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::employee
 * @see app/Http/Controllers/ReportController.php:189
 * @route '/admin/api/reports/employee/{userId}'
 */
employee.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employee.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::employee
 * @see app/Http/Controllers/ReportController.php:189
 * @route '/admin/api/reports/employee/{userId}'
 */
employee.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: employee.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::employee
 * @see app/Http/Controllers/ReportController.php:189
 * @route '/admin/api/reports/employee/{userId}'
 */
    const employeeForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: employee.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::employee
 * @see app/Http/Controllers/ReportController.php:189
 * @route '/admin/api/reports/employee/{userId}'
 */
        employeeForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employee.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::employee
 * @see app/Http/Controllers/ReportController.php:189
 * @route '/admin/api/reports/employee/{userId}'
 */
        employeeForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employee.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    employee.form = employeeForm
/**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:216
 * @route '/admin/api/reports/all'
 */
export const all = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(options),
    method: 'get',
})

all.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/all',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:216
 * @route '/admin/api/reports/all'
 */
all.url = (options?: RouteQueryOptions) => {
    return all.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:216
 * @route '/admin/api/reports/all'
 */
all.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:216
 * @route '/admin/api/reports/all'
 */
all.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: all.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:216
 * @route '/admin/api/reports/all'
 */
    const allForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: all.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:216
 * @route '/admin/api/reports/all'
 */
        allForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: all.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:216
 * @route '/admin/api/reports/all'
 */
        allForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: all.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    all.form = allForm
/**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:490
 * @route '/admin/api/reports/{reportId}'
 */
export const update = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/api/reports/{reportId}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:490
 * @route '/admin/api/reports/{reportId}'
 */
update.url = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reportId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                }

    return update.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:490
 * @route '/admin/api/reports/{reportId}'
 */
update.patch = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:490
 * @route '/admin/api/reports/{reportId}'
 */
    const updateForm = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:490
 * @route '/admin/api/reports/{reportId}'
 */
        updateForm.patch = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:547
 * @route '/admin/api/reports/{reportId}'
 */
export const destroy = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/api/reports/{reportId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:547
 * @route '/admin/api/reports/{reportId}'
 */
destroy.url = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reportId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                }

    return destroy.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:547
 * @route '/admin/api/reports/{reportId}'
 */
destroy.delete = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:547
 * @route '/admin/api/reports/{reportId}'
 */
    const destroyForm = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:547
 * @route '/admin/api/reports/{reportId}'
 */
        destroyForm.delete = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:528
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
export const deleteAttachment = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAttachment.url(args, options),
    method: 'delete',
})

deleteAttachment.definition = {
    methods: ["delete"],
    url: '/admin/api/reports/{reportId}/attachments/{attachmentId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:528
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
deleteAttachment.url = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                    attachmentId: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                                attachmentId: args.attachmentId,
                }

    return deleteAttachment.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace('{attachmentId}', parsedArgs.attachmentId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:528
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
deleteAttachment.delete = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAttachment.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:528
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
    const deleteAttachmentForm = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteAttachment.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:528
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
        deleteAttachmentForm.delete = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteAttachment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteAttachment.form = deleteAttachmentForm
/**
* @see \App\Http\Controllers\ReportController::consolidated
 * @see app/Http/Controllers/ReportController.php:604
 * @route '/admin/api/reports/consolidated'
 */
export const consolidated = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: consolidated.url(options),
    method: 'get',
})

consolidated.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/consolidated',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::consolidated
 * @see app/Http/Controllers/ReportController.php:604
 * @route '/admin/api/reports/consolidated'
 */
consolidated.url = (options?: RouteQueryOptions) => {
    return consolidated.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::consolidated
 * @see app/Http/Controllers/ReportController.php:604
 * @route '/admin/api/reports/consolidated'
 */
consolidated.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: consolidated.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::consolidated
 * @see app/Http/Controllers/ReportController.php:604
 * @route '/admin/api/reports/consolidated'
 */
consolidated.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: consolidated.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::consolidated
 * @see app/Http/Controllers/ReportController.php:604
 * @route '/admin/api/reports/consolidated'
 */
    const consolidatedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: consolidated.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::consolidated
 * @see app/Http/Controllers/ReportController.php:604
 * @route '/admin/api/reports/consolidated'
 */
        consolidatedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: consolidated.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::consolidated
 * @see app/Http/Controllers/ReportController.php:604
 * @route '/admin/api/reports/consolidated'
 */
        consolidatedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: consolidated.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    consolidated.form = consolidatedForm
const reports = {
    employees: Object.assign(employees, employees),
store: Object.assign(store, store),
daily: Object.assign(daily, daily),
connectTask: Object.assign(connectTask, connectTask),
disconnectTask: Object.assign(disconnectTask, disconnectTask),
addAttachment: Object.assign(addAttachment, addAttachment),
employee: Object.assign(employee, employee),
all: Object.assign(all, all),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
deleteAttachment: Object.assign(deleteAttachment, deleteAttachment),
consolidated: Object.assign(consolidated, consolidated9a5e12),
}

export default reports