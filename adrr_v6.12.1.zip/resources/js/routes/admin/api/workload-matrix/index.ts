import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
export const tasks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tasks.url(options),
    method: 'get',
})

tasks.definition = {
    methods: ["get","head"],
    url: '/admin/api/workload-matrix/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
tasks.url = (options?: RouteQueryOptions) => {
    return tasks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
tasks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tasks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
tasks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tasks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
    const tasksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: tasks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
        tasksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tasks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
        tasksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tasks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    tasks.form = tasksForm
/**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/admin/api/workload-matrix/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const workloadMatrix = {
    tasks: Object.assign(tasks, tasks),
export: Object.assign(exportMethod, exportMethod),
}

export default workloadMatrix