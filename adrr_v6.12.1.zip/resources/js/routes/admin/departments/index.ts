import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/departments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/departments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/departments/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\DepartmentController::data
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
export const data = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})

data.definition = {
    methods: ["get","head"],
    url: '/admin/departments/data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::data
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
data.url = (options?: RouteQueryOptions) => {
    return data.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::data
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
data.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::data
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
data.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::data
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
    const dataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: data.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::data
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
        dataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::data
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
        dataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    data.form = dataForm
/**
* @see \App\Http\Controllers\DepartmentController::availableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
export const availableUsers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableUsers.url(options),
    method: 'get',
})

availableUsers.definition = {
    methods: ["get","head"],
    url: '/admin/departments/available-users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::availableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
availableUsers.url = (options?: RouteQueryOptions) => {
    return availableUsers.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::availableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
availableUsers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableUsers.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::availableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
availableUsers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availableUsers.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::availableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
    const availableUsersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: availableUsers.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::availableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
        availableUsersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availableUsers.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::availableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
        availableUsersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availableUsers.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    availableUsers.form = availableUsersForm
/**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
export const assignUser = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignUser.url(args, options),
    method: 'post',
})

assignUser.definition = {
    methods: ["post"],
    url: '/admin/departments/{department}/assign-user',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
assignUser.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return assignUser.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
assignUser.post = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignUser.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
    const assignUserForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assignUser.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
        assignUserForm.post = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assignUser.url(args, options),
            method: 'post',
        })
    
    assignUser.form = assignUserForm
/**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
export const removeUser = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeUser.url(args, options),
    method: 'delete',
})

removeUser.definition = {
    methods: ["delete"],
    url: '/admin/departments/{department}/remove-user/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
removeUser.url = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return removeUser.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
removeUser.delete = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeUser.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
    const removeUserForm = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: removeUser.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
        removeUserForm.delete = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: removeUser.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    removeUser.form = removeUserForm
/**
* @see \App\Http\Controllers\DepartmentController::statistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
export const statistics = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statistics.url(args, options),
    method: 'get',
})

statistics.definition = {
    methods: ["get","head"],
    url: '/admin/departments/{department}/statistics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::statistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
statistics.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return statistics.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::statistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
statistics.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statistics.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::statistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
statistics.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: statistics.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::statistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
    const statisticsForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: statistics.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::statistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
        statisticsForm.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: statistics.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::statistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
        statisticsForm.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: statistics.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    statistics.form = statisticsForm
/**
* @see \App\Http\Controllers\DepartmentController::bulkAssign
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
export const bulkAssign = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAssign.url(args, options),
    method: 'post',
})

bulkAssign.definition = {
    methods: ["post"],
    url: '/admin/departments/{department}/bulk-assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DepartmentController::bulkAssign
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
bulkAssign.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return bulkAssign.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::bulkAssign
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
bulkAssign.post = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAssign.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DepartmentController::bulkAssign
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
    const bulkAssignForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkAssign.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::bulkAssign
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
        bulkAssignForm.post = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkAssign.url(args, options),
            method: 'post',
        })
    
    bulkAssign.form = bulkAssignForm
/**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
export const show = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/departments/{department}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
show.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return show.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
show.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
show.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
    const showForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
        showForm.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
        showForm.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
export const edit = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/departments/{department}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
edit.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return edit.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
edit.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
edit.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
    const editForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
        editForm.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
        editForm.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
export const update = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/departments/{department}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
update.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return update.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
update.patch = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
    const updateForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
        updateForm.patch = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
export const destroy = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/departments/{department}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
destroy.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return destroy.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
destroy.delete = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
    const destroyForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
        destroyForm.delete = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const departments = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
create: Object.assign(create, create),
data: Object.assign(data, data),
availableUsers: Object.assign(availableUsers, availableUsers),
assignUser: Object.assign(assignUser, assignUser),
removeUser: Object.assign(removeUser, removeUser),
statistics: Object.assign(statistics, statistics),
bulkAssign: Object.assign(bulkAssign, bulkAssign),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default departments