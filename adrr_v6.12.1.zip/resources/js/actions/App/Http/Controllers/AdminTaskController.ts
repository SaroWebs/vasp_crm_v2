import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminTaskController::exportTasks
 * @see app/Http/Controllers/AdminTaskController.php:1472
 * @route '/admin/tasks/export'
 */
export const exportTasks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportTasks.url(options),
    method: 'get',
})

exportTasks.definition = {
    methods: ["get","head"],
    url: '/admin/tasks/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTaskController::exportTasks
 * @see app/Http/Controllers/AdminTaskController.php:1472
 * @route '/admin/tasks/export'
 */
exportTasks.url = (options?: RouteQueryOptions) => {
    return exportTasks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::exportTasks
 * @see app/Http/Controllers/AdminTaskController.php:1472
 * @route '/admin/tasks/export'
 */
exportTasks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportTasks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTaskController::exportTasks
 * @see app/Http/Controllers/AdminTaskController.php:1472
 * @route '/admin/tasks/export'
 */
exportTasks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportTasks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::exportTasks
 * @see app/Http/Controllers/AdminTaskController.php:1472
 * @route '/admin/tasks/export'
 */
    const exportTasksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportTasks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::exportTasks
 * @see app/Http/Controllers/AdminTaskController.php:1472
 * @route '/admin/tasks/export'
 */
        exportTasksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportTasks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTaskController::exportTasks
 * @see app/Http/Controllers/AdminTaskController.php:1472
 * @route '/admin/tasks/export'
 */
        exportTasksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportTasks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportTasks.form = exportTasksForm
/**
* @see \App\Http\Controllers\AdminTaskController::index
 * @see app/Http/Controllers/AdminTaskController.php:47
 * @route '/admin/tasks'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTaskController::index
 * @see app/Http/Controllers/AdminTaskController.php:47
 * @route '/admin/tasks'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::index
 * @see app/Http/Controllers/AdminTaskController.php:47
 * @route '/admin/tasks'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTaskController::index
 * @see app/Http/Controllers/AdminTaskController.php:47
 * @route '/admin/tasks'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::index
 * @see app/Http/Controllers/AdminTaskController.php:47
 * @route '/admin/tasks'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::index
 * @see app/Http/Controllers/AdminTaskController.php:47
 * @route '/admin/tasks'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTaskController::index
 * @see app/Http/Controllers/AdminTaskController.php:47
 * @route '/admin/tasks'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminTaskController::getData
 * @see app/Http/Controllers/AdminTaskController.php:69
 * @route '/admin/data/tasks'
 */
export const getData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getData.url(options),
    method: 'get',
})

getData.definition = {
    methods: ["get","head"],
    url: '/admin/data/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTaskController::getData
 * @see app/Http/Controllers/AdminTaskController.php:69
 * @route '/admin/data/tasks'
 */
getData.url = (options?: RouteQueryOptions) => {
    return getData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::getData
 * @see app/Http/Controllers/AdminTaskController.php:69
 * @route '/admin/data/tasks'
 */
getData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getData.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTaskController::getData
 * @see app/Http/Controllers/AdminTaskController.php:69
 * @route '/admin/data/tasks'
 */
getData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getData.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::getData
 * @see app/Http/Controllers/AdminTaskController.php:69
 * @route '/admin/data/tasks'
 */
    const getDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getData.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::getData
 * @see app/Http/Controllers/AdminTaskController.php:69
 * @route '/admin/data/tasks'
 */
        getDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getData.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTaskController::getData
 * @see app/Http/Controllers/AdminTaskController.php:69
 * @route '/admin/data/tasks'
 */
        getDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getData.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getData.form = getDataForm
/**
* @see \App\Http\Controllers\AdminTaskController::store
 * @see app/Http/Controllers/AdminTaskController.php:445
 * @route '/admin/tasks'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/tasks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTaskController::store
 * @see app/Http/Controllers/AdminTaskController.php:445
 * @route '/admin/tasks'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::store
 * @see app/Http/Controllers/AdminTaskController.php:445
 * @route '/admin/tasks'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::store
 * @see app/Http/Controllers/AdminTaskController.php:445
 * @route '/admin/tasks'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::store
 * @see app/Http/Controllers/AdminTaskController.php:445
 * @route '/admin/tasks'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminTaskController::create
 * @see app/Http/Controllers/AdminTaskController.php:393
 * @route '/admin/tasks/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/tasks/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTaskController::create
 * @see app/Http/Controllers/AdminTaskController.php:393
 * @route '/admin/tasks/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::create
 * @see app/Http/Controllers/AdminTaskController.php:393
 * @route '/admin/tasks/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTaskController::create
 * @see app/Http/Controllers/AdminTaskController.php:393
 * @route '/admin/tasks/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::create
 * @see app/Http/Controllers/AdminTaskController.php:393
 * @route '/admin/tasks/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::create
 * @see app/Http/Controllers/AdminTaskController.php:393
 * @route '/admin/tasks/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTaskController::create
 * @see app/Http/Controllers/AdminTaskController.php:393
 * @route '/admin/tasks/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AdminTaskController::show
 * @see app/Http/Controllers/AdminTaskController.php:302
 * @route '/admin/tasks/{task}'
 */
export const show = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/tasks/{task}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTaskController::show
 * @see app/Http/Controllers/AdminTaskController.php:302
 * @route '/admin/tasks/{task}'
 */
show.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return show.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::show
 * @see app/Http/Controllers/AdminTaskController.php:302
 * @route '/admin/tasks/{task}'
 */
show.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTaskController::show
 * @see app/Http/Controllers/AdminTaskController.php:302
 * @route '/admin/tasks/{task}'
 */
show.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::show
 * @see app/Http/Controllers/AdminTaskController.php:302
 * @route '/admin/tasks/{task}'
 */
    const showForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::show
 * @see app/Http/Controllers/AdminTaskController.php:302
 * @route '/admin/tasks/{task}'
 */
        showForm.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTaskController::show
 * @see app/Http/Controllers/AdminTaskController.php:302
 * @route '/admin/tasks/{task}'
 */
        showForm.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AdminTaskController::edit
 * @see app/Http/Controllers/AdminTaskController.php:701
 * @route '/admin/tasks/{task}/edit'
 */
export const edit = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/tasks/{task}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTaskController::edit
 * @see app/Http/Controllers/AdminTaskController.php:701
 * @route '/admin/tasks/{task}/edit'
 */
edit.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return edit.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::edit
 * @see app/Http/Controllers/AdminTaskController.php:701
 * @route '/admin/tasks/{task}/edit'
 */
edit.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTaskController::edit
 * @see app/Http/Controllers/AdminTaskController.php:701
 * @route '/admin/tasks/{task}/edit'
 */
edit.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::edit
 * @see app/Http/Controllers/AdminTaskController.php:701
 * @route '/admin/tasks/{task}/edit'
 */
    const editForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::edit
 * @see app/Http/Controllers/AdminTaskController.php:701
 * @route '/admin/tasks/{task}/edit'
 */
        editForm.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTaskController::edit
 * @see app/Http/Controllers/AdminTaskController.php:701
 * @route '/admin/tasks/{task}/edit'
 */
        editForm.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AdminTaskController::update
 * @see app/Http/Controllers/AdminTaskController.php:752
 * @route '/admin/tasks/{task}'
 */
export const update = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/tasks/{task}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AdminTaskController::update
 * @see app/Http/Controllers/AdminTaskController.php:752
 * @route '/admin/tasks/{task}'
 */
update.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return update.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::update
 * @see app/Http/Controllers/AdminTaskController.php:752
 * @route '/admin/tasks/{task}'
 */
update.patch = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::update
 * @see app/Http/Controllers/AdminTaskController.php:752
 * @route '/admin/tasks/{task}'
 */
    const updateForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::update
 * @see app/Http/Controllers/AdminTaskController.php:752
 * @route '/admin/tasks/{task}'
 */
        updateForm.patch = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AdminTaskController::destroy
 * @see app/Http/Controllers/AdminTaskController.php:948
 * @route '/admin/tasks/{task}'
 */
export const destroy = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/tasks/{task}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminTaskController::destroy
 * @see app/Http/Controllers/AdminTaskController.php:948
 * @route '/admin/tasks/{task}'
 */
destroy.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return destroy.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::destroy
 * @see app/Http/Controllers/AdminTaskController.php:948
 * @route '/admin/tasks/{task}'
 */
destroy.delete = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::destroy
 * @see app/Http/Controllers/AdminTaskController.php:948
 * @route '/admin/tasks/{task}'
 */
    const destroyForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::destroy
 * @see app/Http/Controllers/AdminTaskController.php:948
 * @route '/admin/tasks/{task}'
 */
        destroyForm.delete = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\AdminTaskController::updateStatus
 * @see app/Http/Controllers/AdminTaskController.php:1053
 * @route '/admin/tasks/{task}/status'
 */
export const updateStatus = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/admin/tasks/{task}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AdminTaskController::updateStatus
 * @see app/Http/Controllers/AdminTaskController.php:1053
 * @route '/admin/tasks/{task}/status'
 */
updateStatus.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return updateStatus.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::updateStatus
 * @see app/Http/Controllers/AdminTaskController.php:1053
 * @route '/admin/tasks/{task}/status'
 */
updateStatus.patch = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::updateStatus
 * @see app/Http/Controllers/AdminTaskController.php:1053
 * @route '/admin/tasks/{task}/status'
 */
    const updateStatusForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::updateStatus
 * @see app/Http/Controllers/AdminTaskController.php:1053
 * @route '/admin/tasks/{task}/status'
 */
        updateStatusForm.patch = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\AdminTaskController::getTaskHistory
 * @see app/Http/Controllers/AdminTaskController.php:1118
 * @route '/admin/tasks/{task}/history'
 */
export const getTaskHistory = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTaskHistory.url(args, options),
    method: 'get',
})

getTaskHistory.definition = {
    methods: ["get","head"],
    url: '/admin/tasks/{task}/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTaskController::getTaskHistory
 * @see app/Http/Controllers/AdminTaskController.php:1118
 * @route '/admin/tasks/{task}/history'
 */
getTaskHistory.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return getTaskHistory.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::getTaskHistory
 * @see app/Http/Controllers/AdminTaskController.php:1118
 * @route '/admin/tasks/{task}/history'
 */
getTaskHistory.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTaskHistory.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTaskController::getTaskHistory
 * @see app/Http/Controllers/AdminTaskController.php:1118
 * @route '/admin/tasks/{task}/history'
 */
getTaskHistory.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTaskHistory.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::getTaskHistory
 * @see app/Http/Controllers/AdminTaskController.php:1118
 * @route '/admin/tasks/{task}/history'
 */
    const getTaskHistoryForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTaskHistory.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::getTaskHistory
 * @see app/Http/Controllers/AdminTaskController.php:1118
 * @route '/admin/tasks/{task}/history'
 */
        getTaskHistoryForm.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTaskHistory.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTaskController::getTaskHistory
 * @see app/Http/Controllers/AdminTaskController.php:1118
 * @route '/admin/tasks/{task}/history'
 */
        getTaskHistoryForm.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTaskHistory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTaskHistory.form = getTaskHistoryForm
/**
* @see \App\Http\Controllers\AdminTaskController::restore
 * @see app/Http/Controllers/AdminTaskController.php:986
 * @route '/admin/tasks/{task}/restore'
 */
export const restore = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/tasks/{task}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTaskController::restore
 * @see app/Http/Controllers/AdminTaskController.php:986
 * @route '/admin/tasks/{task}/restore'
 */
restore.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return restore.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::restore
 * @see app/Http/Controllers/AdminTaskController.php:986
 * @route '/admin/tasks/{task}/restore'
 */
restore.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::restore
 * @see app/Http/Controllers/AdminTaskController.php:986
 * @route '/admin/tasks/{task}/restore'
 */
    const restoreForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::restore
 * @see app/Http/Controllers/AdminTaskController.php:986
 * @route '/admin/tasks/{task}/restore'
 */
        restoreForm.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\AdminTaskController::forceDelete
 * @see app/Http/Controllers/AdminTaskController.php:1015
 * @route '/admin/tasks/{task}/force-delete'
 */
export const forceDelete = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: forceDelete.url(args, options),
    method: 'delete',
})

forceDelete.definition = {
    methods: ["delete"],
    url: '/admin/tasks/{task}/force-delete',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminTaskController::forceDelete
 * @see app/Http/Controllers/AdminTaskController.php:1015
 * @route '/admin/tasks/{task}/force-delete'
 */
forceDelete.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return forceDelete.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::forceDelete
 * @see app/Http/Controllers/AdminTaskController.php:1015
 * @route '/admin/tasks/{task}/force-delete'
 */
forceDelete.delete = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: forceDelete.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::forceDelete
 * @see app/Http/Controllers/AdminTaskController.php:1015
 * @route '/admin/tasks/{task}/force-delete'
 */
    const forceDeleteForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceDelete.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::forceDelete
 * @see app/Http/Controllers/AdminTaskController.php:1015
 * @route '/admin/tasks/{task}/force-delete'
 */
        forceDeleteForm.delete = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceDelete.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    forceDelete.form = forceDeleteForm
/**
* @see \App\Http\Controllers\AdminTaskController::updateDates
 * @see app/Http/Controllers/AdminTaskController.php:903
 * @route '/admin/tasks/{task}/dates'
 */
export const updateDates = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDates.url(args, options),
    method: 'patch',
})

updateDates.definition = {
    methods: ["patch"],
    url: '/admin/tasks/{task}/dates',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AdminTaskController::updateDates
 * @see app/Http/Controllers/AdminTaskController.php:903
 * @route '/admin/tasks/{task}/dates'
 */
updateDates.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return updateDates.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::updateDates
 * @see app/Http/Controllers/AdminTaskController.php:903
 * @route '/admin/tasks/{task}/dates'
 */
updateDates.patch = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDates.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::updateDates
 * @see app/Http/Controllers/AdminTaskController.php:903
 * @route '/admin/tasks/{task}/dates'
 */
    const updateDatesForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDates.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::updateDates
 * @see app/Http/Controllers/AdminTaskController.php:903
 * @route '/admin/tasks/{task}/dates'
 */
        updateDatesForm.patch = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDates.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDates.form = updateDatesForm
/**
* @see \App\Http\Controllers\AdminTaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/AdminTaskController.php:367
 * @route '/admin/tasks/sla-policies/{taskTypeId}'
 */
export const getSlaPoliciesByTaskType = (args: { taskTypeId: string | number } | [taskTypeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSlaPoliciesByTaskType.url(args, options),
    method: 'get',
})

getSlaPoliciesByTaskType.definition = {
    methods: ["get","head"],
    url: '/admin/tasks/sla-policies/{taskTypeId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/AdminTaskController.php:367
 * @route '/admin/tasks/sla-policies/{taskTypeId}'
 */
getSlaPoliciesByTaskType.url = (args: { taskTypeId: string | number } | [taskTypeId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskTypeId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    taskTypeId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskTypeId: args.taskTypeId,
                }

    return getSlaPoliciesByTaskType.definition.url
            .replace('{taskTypeId}', parsedArgs.taskTypeId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/AdminTaskController.php:367
 * @route '/admin/tasks/sla-policies/{taskTypeId}'
 */
getSlaPoliciesByTaskType.get = (args: { taskTypeId: string | number } | [taskTypeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSlaPoliciesByTaskType.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/AdminTaskController.php:367
 * @route '/admin/tasks/sla-policies/{taskTypeId}'
 */
getSlaPoliciesByTaskType.head = (args: { taskTypeId: string | number } | [taskTypeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getSlaPoliciesByTaskType.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/AdminTaskController.php:367
 * @route '/admin/tasks/sla-policies/{taskTypeId}'
 */
    const getSlaPoliciesByTaskTypeForm = (args: { taskTypeId: string | number } | [taskTypeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getSlaPoliciesByTaskType.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/AdminTaskController.php:367
 * @route '/admin/tasks/sla-policies/{taskTypeId}'
 */
        getSlaPoliciesByTaskTypeForm.get = (args: { taskTypeId: string | number } | [taskTypeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getSlaPoliciesByTaskType.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/AdminTaskController.php:367
 * @route '/admin/tasks/sla-policies/{taskTypeId}'
 */
        getSlaPoliciesByTaskTypeForm.head = (args: { taskTypeId: string | number } | [taskTypeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getSlaPoliciesByTaskType.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getSlaPoliciesByTaskType.form = getSlaPoliciesByTaskTypeForm
const AdminTaskController = { exportTasks, index, getData, store, create, show, edit, update, destroy, updateStatus, getTaskHistory, restore, forceDelete, updateDates, getSlaPoliciesByTaskType }

export default AdminTaskController