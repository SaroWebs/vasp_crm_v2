import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProjectController::add
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
export const add = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

add.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/team',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectController::add
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
add.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return add.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::add
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
add.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectController::add
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
    const addForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: add.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::add
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
        addForm.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: add.url(args, options),
            method: 'post',
        })
    
    add.form = addForm
/**
* @see \App\Http\Controllers\ProjectController::remove
 * @see app/Http/Controllers/ProjectController.php:439
 * @route '/admin/projects/{project}/team/{user}'
 */
export const remove = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

remove.definition = {
    methods: ["delete"],
    url: '/admin/projects/{project}/team/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProjectController::remove
 * @see app/Http/Controllers/ProjectController.php:439
 * @route '/admin/projects/{project}/team/{user}'
 */
remove.url = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                user: args.user,
                }

    return remove.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::remove
 * @see app/Http/Controllers/ProjectController.php:439
 * @route '/admin/projects/{project}/team/{user}'
 */
remove.delete = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ProjectController::remove
 * @see app/Http/Controllers/ProjectController.php:439
 * @route '/admin/projects/{project}/team/{user}'
 */
    const removeForm = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: remove.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::remove
 * @see app/Http/Controllers/ProjectController.php:439
 * @route '/admin/projects/{project}/team/{user}'
 */
        removeForm.delete = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: remove.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    remove.form = removeForm
/**
* @see \App\Http\Controllers\ProjectController::updateRole
 * @see app/Http/Controllers/ProjectController.php:457
 * @route '/admin/projects/{project}/team/{user}'
 */
export const updateRole = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateRole.url(args, options),
    method: 'patch',
})

updateRole.definition = {
    methods: ["patch"],
    url: '/admin/projects/{project}/team/{user}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ProjectController::updateRole
 * @see app/Http/Controllers/ProjectController.php:457
 * @route '/admin/projects/{project}/team/{user}'
 */
updateRole.url = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                user: args.user,
                }

    return updateRole.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::updateRole
 * @see app/Http/Controllers/ProjectController.php:457
 * @route '/admin/projects/{project}/team/{user}'
 */
updateRole.patch = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateRole.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProjectController::updateRole
 * @see app/Http/Controllers/ProjectController.php:457
 * @route '/admin/projects/{project}/team/{user}'
 */
    const updateRoleForm = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateRole.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::updateRole
 * @see app/Http/Controllers/ProjectController.php:457
 * @route '/admin/projects/{project}/team/{user}'
 */
        updateRoleForm.patch = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateRole.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateRole.form = updateRoleForm
const team = {
    add: Object.assign(add, add),
remove: Object.assign(remove, remove),
updateRole: Object.assign(updateRole, updateRole),
}

export default team