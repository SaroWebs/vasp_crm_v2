import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\OrganizationUserController::index
 * @see app/Http/Controllers/OrganizationUserController.php:17
 * @route '/admin/clients/{client}/organization-users/manage'
 */
export const index = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/clients/{client}/organization-users/manage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OrganizationUserController::index
 * @see app/Http/Controllers/OrganizationUserController.php:17
 * @route '/admin/clients/{client}/organization-users/manage'
 */
index.url = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: args.client,
                }

    return index.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrganizationUserController::index
 * @see app/Http/Controllers/OrganizationUserController.php:17
 * @route '/admin/clients/{client}/organization-users/manage'
 */
index.get = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OrganizationUserController::index
 * @see app/Http/Controllers/OrganizationUserController.php:17
 * @route '/admin/clients/{client}/organization-users/manage'
 */
index.head = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OrganizationUserController::index
 * @see app/Http/Controllers/OrganizationUserController.php:17
 * @route '/admin/clients/{client}/organization-users/manage'
 */
    const indexForm = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OrganizationUserController::index
 * @see app/Http/Controllers/OrganizationUserController.php:17
 * @route '/admin/clients/{client}/organization-users/manage'
 */
        indexForm.get = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OrganizationUserController::index
 * @see app/Http/Controllers/OrganizationUserController.php:17
 * @route '/admin/clients/{client}/organization-users/manage'
 */
        indexForm.head = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\OrganizationUserController::store
 * @see app/Http/Controllers/OrganizationUserController.php:47
 * @route '/admin/clients/{client}/organization-users'
 */
export const store = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/clients/{client}/organization-users',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OrganizationUserController::store
 * @see app/Http/Controllers/OrganizationUserController.php:47
 * @route '/admin/clients/{client}/organization-users'
 */
store.url = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrganizationUserController::store
 * @see app/Http/Controllers/OrganizationUserController.php:47
 * @route '/admin/clients/{client}/organization-users'
 */
store.post = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\OrganizationUserController::store
 * @see app/Http/Controllers/OrganizationUserController.php:47
 * @route '/admin/clients/{client}/organization-users'
 */
    const storeForm = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OrganizationUserController::store
 * @see app/Http/Controllers/OrganizationUserController.php:47
 * @route '/admin/clients/{client}/organization-users'
 */
        storeForm.post = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\OrganizationUserController::update
 * @see app/Http/Controllers/OrganizationUserController.php:78
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
export const update = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/clients/{client}/organization-users/{organizationUser}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\OrganizationUserController::update
 * @see app/Http/Controllers/OrganizationUserController.php:78
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
update.url = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    organizationUser: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: args.client,
                                organizationUser: args.organizationUser,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{organizationUser}', parsedArgs.organizationUser.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrganizationUserController::update
 * @see app/Http/Controllers/OrganizationUserController.php:78
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
update.patch = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\OrganizationUserController::update
 * @see app/Http/Controllers/OrganizationUserController.php:78
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
    const updateForm = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OrganizationUserController::update
 * @see app/Http/Controllers/OrganizationUserController.php:78
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
        updateForm.patch = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\OrganizationUserController::destroy
 * @see app/Http/Controllers/OrganizationUserController.php:113
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
export const destroy = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/clients/{client}/organization-users/{organizationUser}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\OrganizationUserController::destroy
 * @see app/Http/Controllers/OrganizationUserController.php:113
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
destroy.url = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    organizationUser: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: args.client,
                                organizationUser: args.organizationUser,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{organizationUser}', parsedArgs.organizationUser.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrganizationUserController::destroy
 * @see app/Http/Controllers/OrganizationUserController.php:113
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
destroy.delete = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\OrganizationUserController::destroy
 * @see app/Http/Controllers/OrganizationUserController.php:113
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
    const destroyForm = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OrganizationUserController::destroy
 * @see app/Http/Controllers/OrganizationUserController.php:113
 * @route '/admin/clients/{client}/organization-users/{organizationUser}'
 */
        destroyForm.delete = (args: { client: string | number, organizationUser: string | number } | [client: string | number, organizationUser: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const organizationUsers = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default organizationUsers