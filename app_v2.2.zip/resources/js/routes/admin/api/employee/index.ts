import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
import progressFb9fab from './progress'
/**
* @see \App\Http\Controllers\EmployeeProgressController::progress
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
export const progress = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: progress.url(options),
    method: 'get',
})

progress.definition = {
    methods: ["get","head"],
    url: '/admin/api/employee-progress',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmployeeProgressController::progress
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
progress.url = (options?: RouteQueryOptions) => {
    return progress.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeProgressController::progress
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
progress.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: progress.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmployeeProgressController::progress
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
progress.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: progress.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmployeeProgressController::progress
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
    const progressForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: progress.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmployeeProgressController::progress
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
        progressForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: progress.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmployeeProgressController::progress
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
        progressForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: progress.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    progress.form = progressForm
const employee = {
    progress: Object.assign(progress, progressFb9fab),
}

export default employee