import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\EmployeeProgressController::stats
 * @see app/Http/Controllers/EmployeeProgressController.php:216
 * @route '/admin/api/employee-progress/stats'
 */
export const stats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})

stats.definition = {
    methods: ["get","head"],
    url: '/admin/api/employee-progress/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmployeeProgressController::stats
 * @see app/Http/Controllers/EmployeeProgressController.php:216
 * @route '/admin/api/employee-progress/stats'
 */
stats.url = (options?: RouteQueryOptions) => {
    return stats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeProgressController::stats
 * @see app/Http/Controllers/EmployeeProgressController.php:216
 * @route '/admin/api/employee-progress/stats'
 */
stats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmployeeProgressController::stats
 * @see app/Http/Controllers/EmployeeProgressController.php:216
 * @route '/admin/api/employee-progress/stats'
 */
stats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmployeeProgressController::stats
 * @see app/Http/Controllers/EmployeeProgressController.php:216
 * @route '/admin/api/employee-progress/stats'
 */
    const statsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmployeeProgressController::stats
 * @see app/Http/Controllers/EmployeeProgressController.php:216
 * @route '/admin/api/employee-progress/stats'
 */
        statsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmployeeProgressController::stats
 * @see app/Http/Controllers/EmployeeProgressController.php:216
 * @route '/admin/api/employee-progress/stats'
 */
        statsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stats.form = statsForm
const progress = {
    stats: Object.assign(stats, stats),
}

export default progress