import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
export const all = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(args, options),
    method: 'get',
})

all.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/daily/{date}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
all.url = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { date: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    date: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        date: args.date,
                }

    return all.definition.url
            .replace('{date}', parsedArgs.date.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
all.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
all.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: all.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
    const allForm = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: all.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
        allForm.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: all.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::all
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
        allForm.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: all.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    all.form = allForm