import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import employee from './employee'
import workloadMatrix9df00a from './workload-matrix'
import reports from './reports'
/**
* @see \App\Http\Controllers\WorkloadMatrixController::workloadMatrix
 * @see app/Http/Controllers/WorkloadMatrixController.php:61
 * @route '/admin/api/workload-matrix'
 */
export const workloadMatrix = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workloadMatrix.url(options),
    method: 'get',
})

workloadMatrix.definition = {
    methods: ["get","head"],
    url: '/admin/api/workload-matrix',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WorkloadMatrixController::workloadMatrix
 * @see app/Http/Controllers/WorkloadMatrixController.php:61
 * @route '/admin/api/workload-matrix'
 */
workloadMatrix.url = (options?: RouteQueryOptions) => {
    return workloadMatrix.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WorkloadMatrixController::workloadMatrix
 * @see app/Http/Controllers/WorkloadMatrixController.php:61
 * @route '/admin/api/workload-matrix'
 */
workloadMatrix.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workloadMatrix.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WorkloadMatrixController::workloadMatrix
 * @see app/Http/Controllers/WorkloadMatrixController.php:61
 * @route '/admin/api/workload-matrix'
 */
workloadMatrix.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workloadMatrix.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WorkloadMatrixController::workloadMatrix
 * @see app/Http/Controllers/WorkloadMatrixController.php:61
 * @route '/admin/api/workload-matrix'
 */
    const workloadMatrixForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: workloadMatrix.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WorkloadMatrixController::workloadMatrix
 * @see app/Http/Controllers/WorkloadMatrixController.php:61
 * @route '/admin/api/workload-matrix'
 */
        workloadMatrixForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: workloadMatrix.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WorkloadMatrixController::workloadMatrix
 * @see app/Http/Controllers/WorkloadMatrixController.php:61
 * @route '/admin/api/workload-matrix'
 */
        workloadMatrixForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: workloadMatrix.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    workloadMatrix.form = workloadMatrixForm
const api = {
    employee: Object.assign(employee, employee),
workloadMatrix: Object.assign(workloadMatrix, workloadMatrix9df00a),
reports: Object.assign(reports, reports),
}

export default api