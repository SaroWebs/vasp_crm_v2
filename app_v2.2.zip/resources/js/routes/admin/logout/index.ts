import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminAuthController::get
 * @see app/Http/Controllers/AdminAuthController.php:45
 * @route '/admin/logout'
 */
export const get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: get.url(options),
    method: 'get',
})

get.definition = {
    methods: ["get","head"],
    url: '/admin/logout',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminAuthController::get
 * @see app/Http/Controllers/AdminAuthController.php:45
 * @route '/admin/logout'
 */
get.url = (options?: RouteQueryOptions) => {
    return get.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAuthController::get
 * @see app/Http/Controllers/AdminAuthController.php:45
 * @route '/admin/logout'
 */
get.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: get.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminAuthController::get
 * @see app/Http/Controllers/AdminAuthController.php:45
 * @route '/admin/logout'
 */
get.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: get.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminAuthController::get
 * @see app/Http/Controllers/AdminAuthController.php:45
 * @route '/admin/logout'
 */
    const getForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: get.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminAuthController::get
 * @see app/Http/Controllers/AdminAuthController.php:45
 * @route '/admin/logout'
 */
        getForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: get.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminAuthController::get
 * @see app/Http/Controllers/AdminAuthController.php:45
 * @route '/admin/logout'
 */
        getForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: get.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    get.form = getForm
const logout = {
    get: Object.assign(get, get),
}

export default logout