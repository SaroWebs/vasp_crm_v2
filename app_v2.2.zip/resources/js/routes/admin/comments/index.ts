import attachments from './attachments'
const comments = {
    attachments: Object.assign(attachments, attachments),
}

export default comments