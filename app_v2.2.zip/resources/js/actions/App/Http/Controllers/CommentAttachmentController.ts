import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CommentAttachmentController::destroy
 * @see app/Http/Controllers/CommentAttachmentController.php:17
 * @route '/admin/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
export const destroy = (args: { ticket: string | number, comment: string | number, attachment: number | { id: number } } | [ticket: string | number, comment: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/tickets/{ticket}/comments/{comment}/attachments/{attachment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CommentAttachmentController::destroy
 * @see app/Http/Controllers/CommentAttachmentController.php:17
 * @route '/admin/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
destroy.url = (args: { ticket: string | number, comment: string | number, attachment: number | { id: number } } | [ticket: string | number, comment: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    comment: args[1],
                    attachment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                                comment: args.comment,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return destroy.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CommentAttachmentController::destroy
 * @see app/Http/Controllers/CommentAttachmentController.php:17
 * @route '/admin/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
destroy.delete = (args: { ticket: string | number, comment: string | number, attachment: number | { id: number } } | [ticket: string | number, comment: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CommentAttachmentController::destroy
 * @see app/Http/Controllers/CommentAttachmentController.php:17
 * @route '/admin/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
    const destroyForm = (args: { ticket: string | number, comment: string | number, attachment: number | { id: number } } | [ticket: string | number, comment: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CommentAttachmentController::destroy
 * @see app/Http/Controllers/CommentAttachmentController.php:17
 * @route '/admin/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
        destroyForm.delete = (args: { ticket: string | number, comment: string | number, attachment: number | { id: number } } | [ticket: string | number, comment: string | number, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const CommentAttachmentController = { destroy }

export default CommentAttachmentController