import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
export const index = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/comments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
index.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return index.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
index.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
index.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
    const indexForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
        indexForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
        indexForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
export const store = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/tickets/{ticket}/comments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
store.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return store.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
store.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
    const storeForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
        storeForm.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
export const update = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/tickets/{ticket}/comments/{comment}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
update.url = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return update.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
update.patch = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
    const updateForm = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
        updateForm.patch = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
export const destroy = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/tickets/{ticket}/comments/{comment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
destroy.url = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return destroy.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
destroy.delete = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
    const destroyForm = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
        destroyForm.delete = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\TicketCommentController::getDeletedComments
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
export const getDeletedComments = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDeletedComments.url(args, options),
    method: 'get',
})

getDeletedComments.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/comments/deleted',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketCommentController::getDeletedComments
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
getDeletedComments.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return getDeletedComments.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::getDeletedComments
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
getDeletedComments.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDeletedComments.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketCommentController::getDeletedComments
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
getDeletedComments.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDeletedComments.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::getDeletedComments
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
    const getDeletedCommentsForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getDeletedComments.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::getDeletedComments
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
        getDeletedCommentsForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getDeletedComments.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketCommentController::getDeletedComments
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
        getDeletedCommentsForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getDeletedComments.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getDeletedComments.form = getDeletedCommentsForm
/**
* @see \App\Http\Controllers\TicketCommentController::restoreComment
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
export const restoreComment = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restoreComment.url(args, options),
    method: 'patch',
})

restoreComment.definition = {
    methods: ["patch"],
    url: '/admin/tickets/{ticket}/comments/{comment}/restore',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TicketCommentController::restoreComment
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
restoreComment.url = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return restoreComment.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::restoreComment
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
restoreComment.patch = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restoreComment.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::restoreComment
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
    const restoreCommentForm = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restoreComment.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::restoreComment
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
        restoreCommentForm.patch = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restoreComment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    restoreComment.form = restoreCommentForm
/**
* @see \App\Http\Controllers\TicketCommentController::forceDeleteComment
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
export const forceDeleteComment = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: forceDeleteComment.url(args, options),
    method: 'delete',
})

forceDeleteComment.definition = {
    methods: ["delete"],
    url: '/admin/tickets/{ticket}/comments/{comment}/force-delete',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TicketCommentController::forceDeleteComment
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
forceDeleteComment.url = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return forceDeleteComment.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::forceDeleteComment
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
forceDeleteComment.delete = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: forceDeleteComment.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::forceDeleteComment
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
    const forceDeleteCommentForm = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceDeleteComment.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::forceDeleteComment
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
        forceDeleteCommentForm.delete = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceDeleteComment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    forceDeleteComment.form = forceDeleteCommentForm
const TicketCommentController = { index, store, update, destroy, getDeletedComments, restoreComment, forceDeleteComment }

export default TicketCommentController