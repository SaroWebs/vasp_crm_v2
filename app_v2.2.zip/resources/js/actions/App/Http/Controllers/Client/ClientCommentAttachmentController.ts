import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Client\ClientCommentAttachmentController::destroy
 * @see app/Http/Controllers/Client/ClientCommentAttachmentController.php:17
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
export const destroy = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/c/{client}/tickets/{ticket}/comments/{comment}/attachments/{attachment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Client\ClientCommentAttachmentController::destroy
 * @see app/Http/Controllers/Client/ClientCommentAttachmentController.php:17
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
destroy.url = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    ticket: args[1],
                    comment: args[2],
                    attachment: args[3],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                                ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientCommentAttachmentController::destroy
 * @see app/Http/Controllers/Client/ClientCommentAttachmentController.php:17
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
destroy.delete = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Client\ClientCommentAttachmentController::destroy
 * @see app/Http/Controllers/Client/ClientCommentAttachmentController.php:17
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
    const destroyForm = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Client\ClientCommentAttachmentController::destroy
 * @see app/Http/Controllers/Client/ClientCommentAttachmentController.php:17
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}/attachments/{attachment}'
 */
        destroyForm.delete = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ClientCommentAttachmentController = { destroy }

export default ClientCommentAttachmentController