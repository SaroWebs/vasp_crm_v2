import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Client\ClientTicketController::index
 * @see app/Http/Controllers/Client/ClientTicketController.php:19
 * @route '/c/{client}/tickets'
 */
export const index = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/c/{client}/tickets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketController::index
 * @see app/Http/Controllers/Client/ClientTicketController.php:19
 * @route '/c/{client}/tickets'
 */
index.url = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'code' in args) {
            args = { client: args.code }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                }

    return index.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketController::index
 * @see app/Http/Controllers/Client/ClientTicketController.php:19
 * @route '/c/{client}/tickets'
 */
index.get = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Client\ClientTicketController::index
 * @see app/Http/Controllers/Client/ClientTicketController.php:19
 * @route '/c/{client}/tickets'
 */
index.head = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketController::index
 * @see app/Http/Controllers/Client/ClientTicketController.php:19
 * @route '/c/{client}/tickets'
 */
    const indexForm = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketController::index
 * @see app/Http/Controllers/Client/ClientTicketController.php:19
 * @route '/c/{client}/tickets'
 */
        indexForm.get = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Client\ClientTicketController::index
 * @see app/Http/Controllers/Client/ClientTicketController.php:19
 * @route '/c/{client}/tickets'
 */
        indexForm.head = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Client\ClientTicketController::create
 * @see app/Http/Controllers/Client/ClientTicketController.php:47
 * @route '/c/{client}/tickets/create'
 */
export const create = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/c/{client}/tickets/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketController::create
 * @see app/Http/Controllers/Client/ClientTicketController.php:47
 * @route '/c/{client}/tickets/create'
 */
create.url = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'code' in args) {
            args = { client: args.code }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                }

    return create.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketController::create
 * @see app/Http/Controllers/Client/ClientTicketController.php:47
 * @route '/c/{client}/tickets/create'
 */
create.get = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Client\ClientTicketController::create
 * @see app/Http/Controllers/Client/ClientTicketController.php:47
 * @route '/c/{client}/tickets/create'
 */
create.head = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketController::create
 * @see app/Http/Controllers/Client/ClientTicketController.php:47
 * @route '/c/{client}/tickets/create'
 */
    const createForm = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketController::create
 * @see app/Http/Controllers/Client/ClientTicketController.php:47
 * @route '/c/{client}/tickets/create'
 */
        createForm.get = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Client\ClientTicketController::create
 * @see app/Http/Controllers/Client/ClientTicketController.php:47
 * @route '/c/{client}/tickets/create'
 */
        createForm.head = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Client\ClientTicketController::store
 * @see app/Http/Controllers/Client/ClientTicketController.php:54
 * @route '/c/{client}/tickets'
 */
export const store = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/c/{client}/tickets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketController::store
 * @see app/Http/Controllers/Client/ClientTicketController.php:54
 * @route '/c/{client}/tickets'
 */
store.url = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'code' in args) {
            args = { client: args.code }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketController::store
 * @see app/Http/Controllers/Client/ClientTicketController.php:54
 * @route '/c/{client}/tickets'
 */
store.post = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketController::store
 * @see app/Http/Controllers/Client/ClientTicketController.php:54
 * @route '/c/{client}/tickets'
 */
    const storeForm = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketController::store
 * @see app/Http/Controllers/Client/ClientTicketController.php:54
 * @route '/c/{client}/tickets'
 */
        storeForm.post = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Client\ClientTicketController::show
 * @see app/Http/Controllers/Client/ClientTicketController.php:75
 * @route '/c/{client}/tickets/{ticket}'
 */
export const show = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/c/{client}/tickets/{ticket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketController::show
 * @see app/Http/Controllers/Client/ClientTicketController.php:75
 * @route '/c/{client}/tickets/{ticket}'
 */
show.url = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    ticket: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                                ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return show.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketController::show
 * @see app/Http/Controllers/Client/ClientTicketController.php:75
 * @route '/c/{client}/tickets/{ticket}'
 */
show.get = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Client\ClientTicketController::show
 * @see app/Http/Controllers/Client/ClientTicketController.php:75
 * @route '/c/{client}/tickets/{ticket}'
 */
show.head = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketController::show
 * @see app/Http/Controllers/Client/ClientTicketController.php:75
 * @route '/c/{client}/tickets/{ticket}'
 */
    const showForm = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketController::show
 * @see app/Http/Controllers/Client/ClientTicketController.php:75
 * @route '/c/{client}/tickets/{ticket}'
 */
        showForm.get = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Client\ClientTicketController::show
 * @see app/Http/Controllers/Client/ClientTicketController.php:75
 * @route '/c/{client}/tickets/{ticket}'
 */
        showForm.head = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Client\ClientTicketController::edit
 * @see app/Http/Controllers/Client/ClientTicketController.php:96
 * @route '/c/{client}/tickets/{ticket}/edit'
 */
export const edit = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/c/{client}/tickets/{ticket}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketController::edit
 * @see app/Http/Controllers/Client/ClientTicketController.php:96
 * @route '/c/{client}/tickets/{ticket}/edit'
 */
edit.url = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    ticket: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                                ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return edit.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketController::edit
 * @see app/Http/Controllers/Client/ClientTicketController.php:96
 * @route '/c/{client}/tickets/{ticket}/edit'
 */
edit.get = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Client\ClientTicketController::edit
 * @see app/Http/Controllers/Client/ClientTicketController.php:96
 * @route '/c/{client}/tickets/{ticket}/edit'
 */
edit.head = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketController::edit
 * @see app/Http/Controllers/Client/ClientTicketController.php:96
 * @route '/c/{client}/tickets/{ticket}/edit'
 */
    const editForm = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketController::edit
 * @see app/Http/Controllers/Client/ClientTicketController.php:96
 * @route '/c/{client}/tickets/{ticket}/edit'
 */
        editForm.get = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Client\ClientTicketController::edit
 * @see app/Http/Controllers/Client/ClientTicketController.php:96
 * @route '/c/{client}/tickets/{ticket}/edit'
 */
        editForm.head = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Client\ClientTicketController::update
 * @see app/Http/Controllers/Client/ClientTicketController.php:118
 * @route '/c/{client}/tickets/{ticket}'
 */
export const update = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/c/{client}/tickets/{ticket}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketController::update
 * @see app/Http/Controllers/Client/ClientTicketController.php:118
 * @route '/c/{client}/tickets/{ticket}'
 */
update.url = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    ticket: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                                ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketController::update
 * @see app/Http/Controllers/Client/ClientTicketController.php:118
 * @route '/c/{client}/tickets/{ticket}'
 */
update.patch = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketController::update
 * @see app/Http/Controllers/Client/ClientTicketController.php:118
 * @route '/c/{client}/tickets/{ticket}'
 */
    const updateForm = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketController::update
 * @see app/Http/Controllers/Client/ClientTicketController.php:118
 * @route '/c/{client}/tickets/{ticket}'
 */
        updateForm.patch = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Client\ClientTicketController::destroy
 * @see app/Http/Controllers/Client/ClientTicketController.php:129
 * @route '/c/{client}/tickets/{ticket}'
 */
export const destroy = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/c/{client}/tickets/{ticket}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketController::destroy
 * @see app/Http/Controllers/Client/ClientTicketController.php:129
 * @route '/c/{client}/tickets/{ticket}'
 */
destroy.url = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    ticket: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                                ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketController::destroy
 * @see app/Http/Controllers/Client/ClientTicketController.php:129
 * @route '/c/{client}/tickets/{ticket}'
 */
destroy.delete = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketController::destroy
 * @see app/Http/Controllers/Client/ClientTicketController.php:129
 * @route '/c/{client}/tickets/{ticket}'
 */
    const destroyForm = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketController::destroy
 * @see app/Http/Controllers/Client/ClientTicketController.php:129
 * @route '/c/{client}/tickets/{ticket}'
 */
        destroyForm.delete = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ClientTicketController = { index, create, store, show, edit, update, destroy }

export default ClientTicketController