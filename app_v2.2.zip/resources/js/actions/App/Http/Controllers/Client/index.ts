import ClientPortalAuthController from './ClientPortalAuthController'
import ClientTicketController from './ClientTicketController'
import ClientTicketCommentController from './ClientTicketCommentController'
import ClientCommentAttachmentController from './ClientCommentAttachmentController'
const Client = {
    ClientPortalAuthController: Object.assign(ClientPortalAuthController, ClientPortalAuthController),
ClientTicketController: Object.assign(ClientTicketController, ClientTicketController),
ClientTicketCommentController: Object.assign(ClientTicketCommentController, ClientTicketCommentController),
ClientCommentAttachmentController: Object.assign(ClientCommentAttachmentController, ClientCommentAttachmentController),
}

export default Client