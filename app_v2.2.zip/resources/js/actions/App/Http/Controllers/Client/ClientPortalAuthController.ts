import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
export const logout = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(args, options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/c/{client}/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
logout.url = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'code' in args) {
            args = { client: args.code }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                }

    return logout.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
logout.post = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
    const logoutForm = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Client\ClientPortalAuthController::logout
 * @see app/Http/Controllers/Client/ClientPortalAuthController.php:13
 * @route '/c/{client}/logout'
 */
        logoutForm.post = (args: { client: string | { code: string } } | [client: string | { code: string } ] | string | { code: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(args, options),
            method: 'post',
        })
    
    logout.form = logoutForm
const ClientPortalAuthController = { logout }

export default ClientPortalAuthController