import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/data/tasks/{task}/forwardings'
 */
const index9b62f360c0d4bf59c5a679d9702cee7e = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index9b62f360c0d4bf59c5a679d9702cee7e.url(args, options),
    method: 'get',
})

index9b62f360c0d4bf59c5a679d9702cee7e.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/forwardings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/data/tasks/{task}/forwardings'
 */
index9b62f360c0d4bf59c5a679d9702cee7e.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return index9b62f360c0d4bf59c5a679d9702cee7e.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/data/tasks/{task}/forwardings'
 */
index9b62f360c0d4bf59c5a679d9702cee7e.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index9b62f360c0d4bf59c5a679d9702cee7e.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/data/tasks/{task}/forwardings'
 */
index9b62f360c0d4bf59c5a679d9702cee7e.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index9b62f360c0d4bf59c5a679d9702cee7e.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/data/tasks/{task}/forwardings'
 */
    const index9b62f360c0d4bf59c5a679d9702cee7eForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index9b62f360c0d4bf59c5a679d9702cee7e.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/data/tasks/{task}/forwardings'
 */
        index9b62f360c0d4bf59c5a679d9702cee7eForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index9b62f360c0d4bf59c5a679d9702cee7e.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/data/tasks/{task}/forwardings'
 */
        index9b62f360c0d4bf59c5a679d9702cee7eForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index9b62f360c0d4bf59c5a679d9702cee7e.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index9b62f360c0d4bf59c5a679d9702cee7e.form = index9b62f360c0d4bf59c5a679d9702cee7eForm
    /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/tasks/{task}/forwarding'
 */
const index6159c528663fd719bd481d90b8d0210a = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index6159c528663fd719bd481d90b8d0210a.url(args, options),
    method: 'get',
})

index6159c528663fd719bd481d90b8d0210a.definition = {
    methods: ["get","head"],
    url: '/tasks/{task}/forwarding',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/tasks/{task}/forwarding'
 */
index6159c528663fd719bd481d90b8d0210a.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return index6159c528663fd719bd481d90b8d0210a.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/tasks/{task}/forwarding'
 */
index6159c528663fd719bd481d90b8d0210a.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index6159c528663fd719bd481d90b8d0210a.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/tasks/{task}/forwarding'
 */
index6159c528663fd719bd481d90b8d0210a.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index6159c528663fd719bd481d90b8d0210a.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/tasks/{task}/forwarding'
 */
    const index6159c528663fd719bd481d90b8d0210aForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index6159c528663fd719bd481d90b8d0210a.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/tasks/{task}/forwarding'
 */
        index6159c528663fd719bd481d90b8d0210aForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index6159c528663fd719bd481d90b8d0210a.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:27
 * @route '/tasks/{task}/forwarding'
 */
        index6159c528663fd719bd481d90b8d0210aForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index6159c528663fd719bd481d90b8d0210a.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index6159c528663fd719bd481d90b8d0210a.form = index6159c528663fd719bd481d90b8d0210aForm

export const index = {
    '/data/tasks/{task}/forwardings': index9b62f360c0d4bf59c5a679d9702cee7e,
    '/tasks/{task}/forwarding': index6159c528663fd719bd481d90b8d0210a,
}

/**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/data/tasks/{task}/forwardings'
 */
const store9b62f360c0d4bf59c5a679d9702cee7e = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store9b62f360c0d4bf59c5a679d9702cee7e.url(args, options),
    method: 'post',
})

store9b62f360c0d4bf59c5a679d9702cee7e.definition = {
    methods: ["post"],
    url: '/data/tasks/{task}/forwardings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/data/tasks/{task}/forwardings'
 */
store9b62f360c0d4bf59c5a679d9702cee7e.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return store9b62f360c0d4bf59c5a679d9702cee7e.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/data/tasks/{task}/forwardings'
 */
store9b62f360c0d4bf59c5a679d9702cee7e.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store9b62f360c0d4bf59c5a679d9702cee7e.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/data/tasks/{task}/forwardings'
 */
    const store9b62f360c0d4bf59c5a679d9702cee7eForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store9b62f360c0d4bf59c5a679d9702cee7e.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/data/tasks/{task}/forwardings'
 */
        store9b62f360c0d4bf59c5a679d9702cee7eForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store9b62f360c0d4bf59c5a679d9702cee7e.url(args, options),
            method: 'post',
        })
    
    store9b62f360c0d4bf59c5a679d9702cee7e.form = store9b62f360c0d4bf59c5a679d9702cee7eForm
    /**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/tasks/{task}/forward'
 */
const storef01c4e94f029389fce7b392b898092a9 = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storef01c4e94f029389fce7b392b898092a9.url(args, options),
    method: 'post',
})

storef01c4e94f029389fce7b392b898092a9.definition = {
    methods: ["post"],
    url: '/tasks/{task}/forward',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/tasks/{task}/forward'
 */
storef01c4e94f029389fce7b392b898092a9.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return storef01c4e94f029389fce7b392b898092a9.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/tasks/{task}/forward'
 */
storef01c4e94f029389fce7b392b898092a9.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storef01c4e94f029389fce7b392b898092a9.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/tasks/{task}/forward'
 */
    const storef01c4e94f029389fce7b392b898092a9Form = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storef01c4e94f029389fce7b392b898092a9.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:46
 * @route '/tasks/{task}/forward'
 */
        storef01c4e94f029389fce7b392b898092a9Form.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storef01c4e94f029389fce7b392b898092a9.url(args, options),
            method: 'post',
        })
    
    storef01c4e94f029389fce7b392b898092a9.form = storef01c4e94f029389fce7b392b898092a9Form

export const store = {
    '/data/tasks/{task}/forwardings': store9b62f360c0d4bf59c5a679d9702cee7e,
    '/tasks/{task}/forward': storef01c4e94f029389fce7b392b898092a9,
}

/**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:124
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
export const accept = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: accept.url(args, options),
    method: 'patch',
})

accept.definition = {
    methods: ["patch"],
    url: '/task-forwarding/{taskForwarding}/accept',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:124
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
accept.url = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskForwarding: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { taskForwarding: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    taskForwarding: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskForwarding: typeof args.taskForwarding === 'object'
                ? args.taskForwarding.id
                : args.taskForwarding,
                }

    return accept.definition.url
            .replace('{taskForwarding}', parsedArgs.taskForwarding.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:124
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
accept.patch = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: accept.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:124
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
    const acceptForm = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: accept.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:124
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
        acceptForm.patch = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: accept.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    accept.form = acceptForm
/**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:182
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
export const reject = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

reject.definition = {
    methods: ["patch"],
    url: '/task-forwarding/{taskForwarding}/reject',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:182
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
reject.url = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskForwarding: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { taskForwarding: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    taskForwarding: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskForwarding: typeof args.taskForwarding === 'object'
                ? args.taskForwarding.id
                : args.taskForwarding,
                }

    return reject.definition.url
            .replace('{taskForwarding}', parsedArgs.taskForwarding.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:182
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
reject.patch = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:182
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
    const rejectForm = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:182
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
        rejectForm.patch = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reject.form = rejectForm
const TaskForwardingController = { index, store, accept, reject }

export default TaskForwardingController