import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientSsoController::consume
 * @see app/Http/Controllers/ClientSsoController.php:20
 * @route '/s/{code}'
 */
export const consume = (args: { code: string | number } | [code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: consume.url(args, options),
    method: 'get',
})

consume.definition = {
    methods: ["get","head"],
    url: '/s/{code}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientSsoController::consume
 * @see app/Http/Controllers/ClientSsoController.php:20
 * @route '/s/{code}'
 */
consume.url = (args: { code: string | number } | [code: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { code: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    code: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        code: args.code,
                }

    return consume.definition.url
            .replace('{code}', parsedArgs.code.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientSsoController::consume
 * @see app/Http/Controllers/ClientSsoController.php:20
 * @route '/s/{code}'
 */
consume.get = (args: { code: string | number } | [code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: consume.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientSsoController::consume
 * @see app/Http/Controllers/ClientSsoController.php:20
 * @route '/s/{code}'
 */
consume.head = (args: { code: string | number } | [code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: consume.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientSsoController::consume
 * @see app/Http/Controllers/ClientSsoController.php:20
 * @route '/s/{code}'
 */
    const consumeForm = (args: { code: string | number } | [code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: consume.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientSsoController::consume
 * @see app/Http/Controllers/ClientSsoController.php:20
 * @route '/s/{code}'
 */
        consumeForm.get = (args: { code: string | number } | [code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: consume.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientSsoController::consume
 * @see app/Http/Controllers/ClientSsoController.php:20
 * @route '/s/{code}'
 */
        consumeForm.head = (args: { code: string | number } | [code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: consume.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    consume.form = consumeForm
const ClientSsoController = { consume }

export default ClientSsoController