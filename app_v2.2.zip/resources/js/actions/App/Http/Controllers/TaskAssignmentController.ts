import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/admin/tasks/{task}/available-users'
 */
const getAvailableUsersb71c727be61327c46f4217f74f9fd676 = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableUsersb71c727be61327c46f4217f74f9fd676.url(args, options),
    method: 'get',
})

getAvailableUsersb71c727be61327c46f4217f74f9fd676.definition = {
    methods: ["get","head"],
    url: '/admin/tasks/{task}/available-users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/admin/tasks/{task}/available-users'
 */
getAvailableUsersb71c727be61327c46f4217f74f9fd676.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return getAvailableUsersb71c727be61327c46f4217f74f9fd676.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/admin/tasks/{task}/available-users'
 */
getAvailableUsersb71c727be61327c46f4217f74f9fd676.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableUsersb71c727be61327c46f4217f74f9fd676.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/admin/tasks/{task}/available-users'
 */
getAvailableUsersb71c727be61327c46f4217f74f9fd676.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAvailableUsersb71c727be61327c46f4217f74f9fd676.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/admin/tasks/{task}/available-users'
 */
    const getAvailableUsersb71c727be61327c46f4217f74f9fd676Form = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getAvailableUsersb71c727be61327c46f4217f74f9fd676.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/admin/tasks/{task}/available-users'
 */
        getAvailableUsersb71c727be61327c46f4217f74f9fd676Form.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAvailableUsersb71c727be61327c46f4217f74f9fd676.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/admin/tasks/{task}/available-users'
 */
        getAvailableUsersb71c727be61327c46f4217f74f9fd676Form.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAvailableUsersb71c727be61327c46f4217f74f9fd676.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getAvailableUsersb71c727be61327c46f4217f74f9fd676.form = getAvailableUsersb71c727be61327c46f4217f74f9fd676Form
    /**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/api/tasks/{task}/available-users'
 */
const getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4 = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.url(args, options),
    method: 'get',
})

getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.definition = {
    methods: ["get","head"],
    url: '/api/tasks/{task}/available-users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/api/tasks/{task}/available-users'
 */
getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/api/tasks/{task}/available-users'
 */
getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/api/tasks/{task}/available-users'
 */
getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/api/tasks/{task}/available-users'
 */
    const getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4Form = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/api/tasks/{task}/available-users'
 */
        getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4Form.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskAssignmentController::getAvailableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:504
 * @route '/api/tasks/{task}/available-users'
 */
        getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4Form.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4.form = getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4Form

export const getAvailableUsers = {
    '/admin/tasks/{task}/available-users': getAvailableUsersb71c727be61327c46f4217f74f9fd676,
    '/api/tasks/{task}/available-users': getAvailableUsers77e3c98cfb678ffe4d4c443dc609f4f4,
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/admin/tasks/{task}/assign'
 */
const assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1 = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1.url(args, options),
    method: 'post',
})

assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1.definition = {
    methods: ["post"],
    url: '/admin/tasks/{task}/assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/admin/tasks/{task}/assign'
 */
assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/admin/tasks/{task}/assign'
 */
assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/admin/tasks/{task}/assign'
 */
    const assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1Form = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/admin/tasks/{task}/assign'
 */
        assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1Form.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1.url(args, options),
            method: 'post',
        })
    
    assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1.form = assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1Form
    /**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/api/tasks/{task}/assign'
 */
const assignUserToTask6521a9793a0b34abcfe02e90ead996cb = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignUserToTask6521a9793a0b34abcfe02e90ead996cb.url(args, options),
    method: 'post',
})

assignUserToTask6521a9793a0b34abcfe02e90ead996cb.definition = {
    methods: ["post"],
    url: '/api/tasks/{task}/assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/api/tasks/{task}/assign'
 */
assignUserToTask6521a9793a0b34abcfe02e90ead996cb.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return assignUserToTask6521a9793a0b34abcfe02e90ead996cb.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/api/tasks/{task}/assign'
 */
assignUserToTask6521a9793a0b34abcfe02e90ead996cb.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignUserToTask6521a9793a0b34abcfe02e90ead996cb.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/api/tasks/{task}/assign'
 */
    const assignUserToTask6521a9793a0b34abcfe02e90ead996cbForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assignUserToTask6521a9793a0b34abcfe02e90ead996cb.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::assignUserToTask
 * @see app/Http/Controllers/TaskAssignmentController.php:240
 * @route '/api/tasks/{task}/assign'
 */
        assignUserToTask6521a9793a0b34abcfe02e90ead996cbForm.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assignUserToTask6521a9793a0b34abcfe02e90ead996cb.url(args, options),
            method: 'post',
        })
    
    assignUserToTask6521a9793a0b34abcfe02e90ead996cb.form = assignUserToTask6521a9793a0b34abcfe02e90ead996cbForm

export const assignUserToTask = {
    '/admin/tasks/{task}/assign': assignUserToTask067a2b29e7a4e2479716d1addcc1b1a1,
    '/api/tasks/{task}/assign': assignUserToTask6521a9793a0b34abcfe02e90ead996cb,
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::index
 * @see app/Http/Controllers/TaskAssignmentController.php:26
 * @route '/api/task-assignments'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/task-assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::index
 * @see app/Http/Controllers/TaskAssignmentController.php:26
 * @route '/api/task-assignments'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::index
 * @see app/Http/Controllers/TaskAssignmentController.php:26
 * @route '/api/task-assignments'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskAssignmentController::index
 * @see app/Http/Controllers/TaskAssignmentController.php:26
 * @route '/api/task-assignments'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::index
 * @see app/Http/Controllers/TaskAssignmentController.php:26
 * @route '/api/task-assignments'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::index
 * @see app/Http/Controllers/TaskAssignmentController.php:26
 * @route '/api/task-assignments'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskAssignmentController::index
 * @see app/Http/Controllers/TaskAssignmentController.php:26
 * @route '/api/task-assignments'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TaskAssignmentController::unassignUserFromTask
 * @see app/Http/Controllers/TaskAssignmentController.php:305
 * @route '/api/tasks/{task}/unassign'
 */
export const unassignUserFromTask = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unassignUserFromTask.url(args, options),
    method: 'post',
})

unassignUserFromTask.definition = {
    methods: ["post"],
    url: '/api/tasks/{task}/unassign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::unassignUserFromTask
 * @see app/Http/Controllers/TaskAssignmentController.php:305
 * @route '/api/tasks/{task}/unassign'
 */
unassignUserFromTask.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return unassignUserFromTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::unassignUserFromTask
 * @see app/Http/Controllers/TaskAssignmentController.php:305
 * @route '/api/tasks/{task}/unassign'
 */
unassignUserFromTask.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unassignUserFromTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::unassignUserFromTask
 * @see app/Http/Controllers/TaskAssignmentController.php:305
 * @route '/api/tasks/{task}/unassign'
 */
    const unassignUserFromTaskForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unassignUserFromTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::unassignUserFromTask
 * @see app/Http/Controllers/TaskAssignmentController.php:305
 * @route '/api/tasks/{task}/unassign'
 */
        unassignUserFromTaskForm.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unassignUserFromTask.url(args, options),
            method: 'post',
        })
    
    unassignUserFromTask.form = unassignUserFromTaskForm
/**
* @see \App\Http\Controllers\TaskAssignmentController::getTaskAssignments
 * @see app/Http/Controllers/TaskAssignmentController.php:213
 * @route '/api/tasks/{task}/assignments'
 */
export const getTaskAssignments = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTaskAssignments.url(args, options),
    method: 'get',
})

getTaskAssignments.definition = {
    methods: ["get","head"],
    url: '/api/tasks/{task}/assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::getTaskAssignments
 * @see app/Http/Controllers/TaskAssignmentController.php:213
 * @route '/api/tasks/{task}/assignments'
 */
getTaskAssignments.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return getTaskAssignments.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::getTaskAssignments
 * @see app/Http/Controllers/TaskAssignmentController.php:213
 * @route '/api/tasks/{task}/assignments'
 */
getTaskAssignments.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTaskAssignments.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskAssignmentController::getTaskAssignments
 * @see app/Http/Controllers/TaskAssignmentController.php:213
 * @route '/api/tasks/{task}/assignments'
 */
getTaskAssignments.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTaskAssignments.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::getTaskAssignments
 * @see app/Http/Controllers/TaskAssignmentController.php:213
 * @route '/api/tasks/{task}/assignments'
 */
    const getTaskAssignmentsForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTaskAssignments.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::getTaskAssignments
 * @see app/Http/Controllers/TaskAssignmentController.php:213
 * @route '/api/tasks/{task}/assignments'
 */
        getTaskAssignmentsForm.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTaskAssignments.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskAssignmentController::getTaskAssignments
 * @see app/Http/Controllers/TaskAssignmentController.php:213
 * @route '/api/tasks/{task}/assignments'
 */
        getTaskAssignmentsForm.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTaskAssignments.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTaskAssignments.form = getTaskAssignmentsForm
const TaskAssignmentController = { getAvailableUsers, assignUserToTask, index, unassignUserFromTask, getTaskAssignments }

export default TaskAssignmentController