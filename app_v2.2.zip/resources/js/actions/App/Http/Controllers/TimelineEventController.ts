import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/timeline-events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/timeline-events',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
export const storeReport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeReport.url(options),
    method: 'post',
})

storeReport.definition = {
    methods: ["post"],
    url: '/timeline-events/store-report',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
storeReport.url = (options?: RouteQueryOptions) => {
    return storeReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
storeReport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeReport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
    const storeReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeReport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
        storeReportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeReport.url(options),
            method: 'post',
        })
    
    storeReport.form = storeReportForm
/**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
export const show = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/timeline-events/{timelineEvent}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
show.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return show.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
show.get = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
show.head = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
    const showForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
        showForm.get = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
        showForm.head = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
export const update = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/timeline-events/{timelineEvent}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
update.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return update.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
update.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
    const updateForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
        updateForm.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
export const destroy = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/timeline-events/{timelineEvent}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
destroy.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return destroy.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
destroy.delete = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
    const destroyForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
        destroyForm.delete = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\TimelineEventController::storeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
export const storeMilestone = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMilestone.url(options),
    method: 'post',
})

storeMilestone.definition = {
    methods: ["post"],
    url: '/timeline-events/milestones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimelineEventController::storeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
storeMilestone.url = (options?: RouteQueryOptions) => {
    return storeMilestone.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::storeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
storeMilestone.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMilestone.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::storeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
    const storeMilestoneForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeMilestone.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::storeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
        storeMilestoneForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeMilestone.url(options),
            method: 'post',
        })
    
    storeMilestone.form = storeMilestoneForm
/**
* @see \App\Http\Controllers\TimelineEventController::updateMilestone
 * @see app/Http/Controllers/TimelineEventController.php:219
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
export const updateMilestone = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateMilestone.url(args, options),
    method: 'patch',
})

updateMilestone.definition = {
    methods: ["patch"],
    url: '/timeline-events/{timelineEvent}/milestone',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TimelineEventController::updateMilestone
 * @see app/Http/Controllers/TimelineEventController.php:219
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
updateMilestone.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return updateMilestone.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::updateMilestone
 * @see app/Http/Controllers/TimelineEventController.php:219
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
updateMilestone.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateMilestone.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::updateMilestone
 * @see app/Http/Controllers/TimelineEventController.php:219
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
    const updateMilestoneForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateMilestone.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::updateMilestone
 * @see app/Http/Controllers/TimelineEventController.php:219
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
        updateMilestoneForm.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateMilestone.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateMilestone.form = updateMilestoneForm
/**
* @see \App\Http\Controllers\TimelineEventController::completeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:273
 * @route '/timeline-events/{timelineEvent}/complete'
 */
export const completeMilestone = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: completeMilestone.url(args, options),
    method: 'patch',
})

completeMilestone.definition = {
    methods: ["patch"],
    url: '/timeline-events/{timelineEvent}/complete',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TimelineEventController::completeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:273
 * @route '/timeline-events/{timelineEvent}/complete'
 */
completeMilestone.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return completeMilestone.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::completeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:273
 * @route '/timeline-events/{timelineEvent}/complete'
 */
completeMilestone.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: completeMilestone.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::completeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:273
 * @route '/timeline-events/{timelineEvent}/complete'
 */
    const completeMilestoneForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: completeMilestone.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::completeMilestone
 * @see app/Http/Controllers/TimelineEventController.php:273
 * @route '/timeline-events/{timelineEvent}/complete'
 */
        completeMilestoneForm.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: completeMilestone.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    completeMilestone.form = completeMilestoneForm
/**
* @see \App\Http\Controllers\TimelineEventController::getMilestonesForTask
 * @see app/Http/Controllers/TimelineEventController.php:300
 * @route '/tasks/{task}/milestones'
 */
export const getMilestonesForTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMilestonesForTask.url(args, options),
    method: 'get',
})

getMilestonesForTask.definition = {
    methods: ["get","head"],
    url: '/tasks/{task}/milestones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineEventController::getMilestonesForTask
 * @see app/Http/Controllers/TimelineEventController.php:300
 * @route '/tasks/{task}/milestones'
 */
getMilestonesForTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return getMilestonesForTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::getMilestonesForTask
 * @see app/Http/Controllers/TimelineEventController.php:300
 * @route '/tasks/{task}/milestones'
 */
getMilestonesForTask.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMilestonesForTask.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineEventController::getMilestonesForTask
 * @see app/Http/Controllers/TimelineEventController.php:300
 * @route '/tasks/{task}/milestones'
 */
getMilestonesForTask.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getMilestonesForTask.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::getMilestonesForTask
 * @see app/Http/Controllers/TimelineEventController.php:300
 * @route '/tasks/{task}/milestones'
 */
    const getMilestonesForTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getMilestonesForTask.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::getMilestonesForTask
 * @see app/Http/Controllers/TimelineEventController.php:300
 * @route '/tasks/{task}/milestones'
 */
        getMilestonesForTaskForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getMilestonesForTask.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineEventController::getMilestonesForTask
 * @see app/Http/Controllers/TimelineEventController.php:300
 * @route '/tasks/{task}/milestones'
 */
        getMilestonesForTaskForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getMilestonesForTask.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getMilestonesForTask.form = getMilestonesForTaskForm
/**
* @see \App\Http\Controllers\TimelineEventController::getMilestoneSummary
 * @see app/Http/Controllers/TimelineEventController.php:314
 * @route '/api/milestones/summary'
 */
export const getMilestoneSummary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMilestoneSummary.url(options),
    method: 'get',
})

getMilestoneSummary.definition = {
    methods: ["get","head"],
    url: '/api/milestones/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineEventController::getMilestoneSummary
 * @see app/Http/Controllers/TimelineEventController.php:314
 * @route '/api/milestones/summary'
 */
getMilestoneSummary.url = (options?: RouteQueryOptions) => {
    return getMilestoneSummary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::getMilestoneSummary
 * @see app/Http/Controllers/TimelineEventController.php:314
 * @route '/api/milestones/summary'
 */
getMilestoneSummary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMilestoneSummary.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineEventController::getMilestoneSummary
 * @see app/Http/Controllers/TimelineEventController.php:314
 * @route '/api/milestones/summary'
 */
getMilestoneSummary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getMilestoneSummary.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::getMilestoneSummary
 * @see app/Http/Controllers/TimelineEventController.php:314
 * @route '/api/milestones/summary'
 */
    const getMilestoneSummaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getMilestoneSummary.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::getMilestoneSummary
 * @see app/Http/Controllers/TimelineEventController.php:314
 * @route '/api/milestones/summary'
 */
        getMilestoneSummaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getMilestoneSummary.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineEventController::getMilestoneSummary
 * @see app/Http/Controllers/TimelineEventController.php:314
 * @route '/api/milestones/summary'
 */
        getMilestoneSummaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getMilestoneSummary.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getMilestoneSummary.form = getMilestoneSummaryForm
const TimelineEventController = { index, store, storeReport, show, update, destroy, storeMilestone, updateMilestone, completeMilestone, getMilestonesForTask, getMilestoneSummary }

export default TimelineEventController