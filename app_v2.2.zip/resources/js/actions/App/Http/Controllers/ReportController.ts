import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:232
 * @route '/admin/reports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:232
 * @route '/admin/reports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:232
 * @route '/admin/reports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:232
 * @route '/admin/reports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:232
 * @route '/admin/reports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:232
 * @route '/admin/reports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:232
 * @route '/admin/reports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ReportController::edit
 * @see app/Http/Controllers/ReportController.php:289
 * @route '/admin/reports/{report}/edit'
 */
export const edit = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/reports/{report}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::edit
 * @see app/Http/Controllers/ReportController.php:289
 * @route '/admin/reports/{report}/edit'
 */
edit.url = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { report: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    report: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        report: args.report,
                }

    return edit.definition.url
            .replace('{report}', parsedArgs.report.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::edit
 * @see app/Http/Controllers/ReportController.php:289
 * @route '/admin/reports/{report}/edit'
 */
edit.get = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::edit
 * @see app/Http/Controllers/ReportController.php:289
 * @route '/admin/reports/{report}/edit'
 */
edit.head = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::edit
 * @see app/Http/Controllers/ReportController.php:289
 * @route '/admin/reports/{report}/edit'
 */
    const editForm = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::edit
 * @see app/Http/Controllers/ReportController.php:289
 * @route '/admin/reports/{report}/edit'
 */
        editForm.get = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::edit
 * @see app/Http/Controllers/ReportController.php:289
 * @route '/admin/reports/{report}/edit'
 */
        editForm.head = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\ReportController::show
 * @see app/Http/Controllers/ReportController.php:244
 * @route '/admin/reports/{report}'
 */
export const show = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/reports/{report}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::show
 * @see app/Http/Controllers/ReportController.php:244
 * @route '/admin/reports/{report}'
 */
show.url = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { report: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    report: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        report: args.report,
                }

    return show.definition.url
            .replace('{report}', parsedArgs.report.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::show
 * @see app/Http/Controllers/ReportController.php:244
 * @route '/admin/reports/{report}'
 */
show.get = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::show
 * @see app/Http/Controllers/ReportController.php:244
 * @route '/admin/reports/{report}'
 */
show.head = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::show
 * @see app/Http/Controllers/ReportController.php:244
 * @route '/admin/reports/{report}'
 */
    const showForm = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::show
 * @see app/Http/Controllers/ReportController.php:244
 * @route '/admin/reports/{report}'
 */
        showForm.get = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::show
 * @see app/Http/Controllers/ReportController.php:244
 * @route '/admin/reports/{report}'
 */
        showForm.head = (args: { report: string | number } | [report: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ReportController::getEmployees
 * @see app/Http/Controllers/ReportController.php:509
 * @route '/admin/api/reports/employees'
 */
export const getEmployees = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployees.url(options),
    method: 'get',
})

getEmployees.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/employees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::getEmployees
 * @see app/Http/Controllers/ReportController.php:509
 * @route '/admin/api/reports/employees'
 */
getEmployees.url = (options?: RouteQueryOptions) => {
    return getEmployees.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::getEmployees
 * @see app/Http/Controllers/ReportController.php:509
 * @route '/admin/api/reports/employees'
 */
getEmployees.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployees.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::getEmployees
 * @see app/Http/Controllers/ReportController.php:509
 * @route '/admin/api/reports/employees'
 */
getEmployees.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployees.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::getEmployees
 * @see app/Http/Controllers/ReportController.php:509
 * @route '/admin/api/reports/employees'
 */
    const getEmployeesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployees.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::getEmployees
 * @see app/Http/Controllers/ReportController.php:509
 * @route '/admin/api/reports/employees'
 */
        getEmployeesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployees.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::getEmployees
 * @see app/Http/Controllers/ReportController.php:509
 * @route '/admin/api/reports/employees'
 */
        getEmployeesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployees.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployees.form = getEmployeesForm
/**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:64
 * @route '/admin/api/reports'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/api/reports',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:64
 * @route '/admin/api/reports'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:64
 * @route '/admin/api/reports'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:64
 * @route '/admin/api/reports'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::store
 * @see app/Http/Controllers/ReportController.php:64
 * @route '/admin/api/reports'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ReportController::getDailyReportAll
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
export const getDailyReportAll = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDailyReportAll.url(args, options),
    method: 'get',
})

getDailyReportAll.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/daily/{date}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::getDailyReportAll
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
getDailyReportAll.url = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { date: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    date: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        date: args.date,
                }

    return getDailyReportAll.definition.url
            .replace('{date}', parsedArgs.date.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::getDailyReportAll
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
getDailyReportAll.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDailyReportAll.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::getDailyReportAll
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
getDailyReportAll.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDailyReportAll.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::getDailyReportAll
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
    const getDailyReportAllForm = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getDailyReportAll.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::getDailyReportAll
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
        getDailyReportAllForm.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getDailyReportAll.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::getDailyReportAll
 * @see app/Http/Controllers/ReportController.php:19
 * @route '/admin/api/reports/daily/{date}'
 */
        getDailyReportAllForm.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getDailyReportAll.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getDailyReportAll.form = getDailyReportAllForm
/**
* @see \App\Http\Controllers\ReportController::getDailyReport
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
export const getDailyReport = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDailyReport.url(args, options),
    method: 'get',
})

getDailyReport.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/daily/{userId}/{date}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::getDailyReport
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
getDailyReport.url = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                    date: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                                date: args.date,
                }

    return getDailyReport.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace('{date}', parsedArgs.date.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::getDailyReport
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
getDailyReport.get = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDailyReport.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::getDailyReport
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
getDailyReport.head = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDailyReport.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::getDailyReport
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
    const getDailyReportForm = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getDailyReport.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::getDailyReport
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
        getDailyReportForm.get = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getDailyReport.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::getDailyReport
 * @see app/Http/Controllers/ReportController.php:0
 * @route '/admin/api/reports/daily/{userId}/{date}'
 */
        getDailyReportForm.head = (args: { userId: string | number, date: string | number } | [userId: string | number, date: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getDailyReport.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getDailyReport.form = getDailyReportForm
/**
* @see \App\Http\Controllers\ReportController::connectTaskToReport
 * @see app/Http/Controllers/ReportController.php:108
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
export const connectTaskToReport = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: connectTaskToReport.url(args, options),
    method: 'post',
})

connectTaskToReport.definition = {
    methods: ["post"],
    url: '/admin/api/reports/{reportId}/tasks/{taskId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReportController::connectTaskToReport
 * @see app/Http/Controllers/ReportController.php:108
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
connectTaskToReport.url = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                    taskId: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                                taskId: args.taskId,
                }

    return connectTaskToReport.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace('{taskId}', parsedArgs.taskId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::connectTaskToReport
 * @see app/Http/Controllers/ReportController.php:108
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
connectTaskToReport.post = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: connectTaskToReport.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReportController::connectTaskToReport
 * @see app/Http/Controllers/ReportController.php:108
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
    const connectTaskToReportForm = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: connectTaskToReport.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::connectTaskToReport
 * @see app/Http/Controllers/ReportController.php:108
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
        connectTaskToReportForm.post = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: connectTaskToReport.url(args, options),
            method: 'post',
        })
    
    connectTaskToReport.form = connectTaskToReportForm
/**
* @see \App\Http\Controllers\ReportController::disconnectTaskFromReport
 * @see app/Http/Controllers/ReportController.php:117
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
export const disconnectTaskFromReport = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disconnectTaskFromReport.url(args, options),
    method: 'delete',
})

disconnectTaskFromReport.definition = {
    methods: ["delete"],
    url: '/admin/api/reports/{reportId}/tasks/{taskId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ReportController::disconnectTaskFromReport
 * @see app/Http/Controllers/ReportController.php:117
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
disconnectTaskFromReport.url = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                    taskId: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                                taskId: args.taskId,
                }

    return disconnectTaskFromReport.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace('{taskId}', parsedArgs.taskId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::disconnectTaskFromReport
 * @see app/Http/Controllers/ReportController.php:117
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
disconnectTaskFromReport.delete = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disconnectTaskFromReport.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ReportController::disconnectTaskFromReport
 * @see app/Http/Controllers/ReportController.php:117
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
    const disconnectTaskFromReportForm = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: disconnectTaskFromReport.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::disconnectTaskFromReport
 * @see app/Http/Controllers/ReportController.php:117
 * @route '/admin/api/reports/{reportId}/tasks/{taskId}'
 */
        disconnectTaskFromReportForm.delete = (args: { reportId: string | number, taskId: string | number } | [reportId: string | number, taskId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: disconnectTaskFromReport.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    disconnectTaskFromReport.form = disconnectTaskFromReportForm
/**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:154
 * @route '/admin/api/reports/{reportId}/attachments'
 */
export const addAttachment = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addAttachment.url(args, options),
    method: 'post',
})

addAttachment.definition = {
    methods: ["post"],
    url: '/admin/api/reports/{reportId}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:154
 * @route '/admin/api/reports/{reportId}/attachments'
 */
addAttachment.url = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reportId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                }

    return addAttachment.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:154
 * @route '/admin/api/reports/{reportId}/attachments'
 */
addAttachment.post = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addAttachment.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:154
 * @route '/admin/api/reports/{reportId}/attachments'
 */
    const addAttachmentForm = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addAttachment.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::addAttachment
 * @see app/Http/Controllers/ReportController.php:154
 * @route '/admin/api/reports/{reportId}/attachments'
 */
        addAttachmentForm.post = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addAttachment.url(args, options),
            method: 'post',
        })
    
    addAttachment.form = addAttachmentForm
/**
* @see \App\Http\Controllers\ReportController::getEmployeeReports
 * @see app/Http/Controllers/ReportController.php:168
 * @route '/admin/api/reports/employee/{userId}'
 */
export const getEmployeeReports = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeReports.url(args, options),
    method: 'get',
})

getEmployeeReports.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/employee/{userId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::getEmployeeReports
 * @see app/Http/Controllers/ReportController.php:168
 * @route '/admin/api/reports/employee/{userId}'
 */
getEmployeeReports.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return getEmployeeReports.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::getEmployeeReports
 * @see app/Http/Controllers/ReportController.php:168
 * @route '/admin/api/reports/employee/{userId}'
 */
getEmployeeReports.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeReports.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::getEmployeeReports
 * @see app/Http/Controllers/ReportController.php:168
 * @route '/admin/api/reports/employee/{userId}'
 */
getEmployeeReports.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeReports.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::getEmployeeReports
 * @see app/Http/Controllers/ReportController.php:168
 * @route '/admin/api/reports/employee/{userId}'
 */
    const getEmployeeReportsForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeReports.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::getEmployeeReports
 * @see app/Http/Controllers/ReportController.php:168
 * @route '/admin/api/reports/employee/{userId}'
 */
        getEmployeeReportsForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeReports.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::getEmployeeReports
 * @see app/Http/Controllers/ReportController.php:168
 * @route '/admin/api/reports/employee/{userId}'
 */
        getEmployeeReportsForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeReports.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeReports.form = getEmployeeReportsForm
/**
* @see \App\Http\Controllers\ReportController::getAllReports
 * @see app/Http/Controllers/ReportController.php:188
 * @route '/admin/api/reports/all'
 */
export const getAllReports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAllReports.url(options),
    method: 'get',
})

getAllReports.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/all',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::getAllReports
 * @see app/Http/Controllers/ReportController.php:188
 * @route '/admin/api/reports/all'
 */
getAllReports.url = (options?: RouteQueryOptions) => {
    return getAllReports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::getAllReports
 * @see app/Http/Controllers/ReportController.php:188
 * @route '/admin/api/reports/all'
 */
getAllReports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAllReports.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::getAllReports
 * @see app/Http/Controllers/ReportController.php:188
 * @route '/admin/api/reports/all'
 */
getAllReports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAllReports.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::getAllReports
 * @see app/Http/Controllers/ReportController.php:188
 * @route '/admin/api/reports/all'
 */
    const getAllReportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getAllReports.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::getAllReports
 * @see app/Http/Controllers/ReportController.php:188
 * @route '/admin/api/reports/all'
 */
        getAllReportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAllReports.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::getAllReports
 * @see app/Http/Controllers/ReportController.php:188
 * @route '/admin/api/reports/all'
 */
        getAllReportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAllReports.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getAllReports.form = getAllReportsForm
/**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:415
 * @route '/admin/api/reports/{reportId}'
 */
export const update = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/api/reports/{reportId}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:415
 * @route '/admin/api/reports/{reportId}'
 */
update.url = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reportId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                }

    return update.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:415
 * @route '/admin/api/reports/{reportId}'
 */
update.patch = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:415
 * @route '/admin/api/reports/{reportId}'
 */
    const updateForm = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::update
 * @see app/Http/Controllers/ReportController.php:415
 * @route '/admin/api/reports/{reportId}'
 */
        updateForm.patch = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:472
 * @route '/admin/api/reports/{reportId}'
 */
export const destroy = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/api/reports/{reportId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:472
 * @route '/admin/api/reports/{reportId}'
 */
destroy.url = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reportId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                }

    return destroy.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:472
 * @route '/admin/api/reports/{reportId}'
 */
destroy.delete = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:472
 * @route '/admin/api/reports/{reportId}'
 */
    const destroyForm = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::destroy
 * @see app/Http/Controllers/ReportController.php:472
 * @route '/admin/api/reports/{reportId}'
 */
        destroyForm.delete = (args: { reportId: string | number } | [reportId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:453
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
export const deleteAttachment = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAttachment.url(args, options),
    method: 'delete',
})

deleteAttachment.definition = {
    methods: ["delete"],
    url: '/admin/api/reports/{reportId}/attachments/{attachmentId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:453
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
deleteAttachment.url = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    reportId: args[0],
                    attachmentId: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reportId: args.reportId,
                                attachmentId: args.attachmentId,
                }

    return deleteAttachment.definition.url
            .replace('{reportId}', parsedArgs.reportId.toString())
            .replace('{attachmentId}', parsedArgs.attachmentId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:453
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
deleteAttachment.delete = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteAttachment.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:453
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
    const deleteAttachmentForm = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteAttachment.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReportController::deleteAttachment
 * @see app/Http/Controllers/ReportController.php:453
 * @route '/admin/api/reports/{reportId}/attachments/{attachmentId}'
 */
        deleteAttachmentForm.delete = (args: { reportId: string | number, attachmentId: string | number } | [reportId: string | number, attachmentId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteAttachment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteAttachment.form = deleteAttachmentForm
/**
* @see \App\Http\Controllers\ReportController::getConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:518
 * @route '/admin/api/reports/consolidated'
 */
export const getConsolidatedReports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getConsolidatedReports.url(options),
    method: 'get',
})

getConsolidatedReports.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/consolidated',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::getConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:518
 * @route '/admin/api/reports/consolidated'
 */
getConsolidatedReports.url = (options?: RouteQueryOptions) => {
    return getConsolidatedReports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::getConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:518
 * @route '/admin/api/reports/consolidated'
 */
getConsolidatedReports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getConsolidatedReports.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::getConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:518
 * @route '/admin/api/reports/consolidated'
 */
getConsolidatedReports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getConsolidatedReports.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::getConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:518
 * @route '/admin/api/reports/consolidated'
 */
    const getConsolidatedReportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getConsolidatedReports.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::getConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:518
 * @route '/admin/api/reports/consolidated'
 */
        getConsolidatedReportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getConsolidatedReports.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::getConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:518
 * @route '/admin/api/reports/consolidated'
 */
        getConsolidatedReportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getConsolidatedReports.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getConsolidatedReports.form = getConsolidatedReportsForm
/**
* @see \App\Http\Controllers\ReportController::exportConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:618
 * @route '/admin/api/reports/consolidated/export'
 */
export const exportConsolidatedReports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportConsolidatedReports.url(options),
    method: 'get',
})

exportConsolidatedReports.definition = {
    methods: ["get","head"],
    url: '/admin/api/reports/consolidated/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::exportConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:618
 * @route '/admin/api/reports/consolidated/export'
 */
exportConsolidatedReports.url = (options?: RouteQueryOptions) => {
    return exportConsolidatedReports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::exportConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:618
 * @route '/admin/api/reports/consolidated/export'
 */
exportConsolidatedReports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportConsolidatedReports.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::exportConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:618
 * @route '/admin/api/reports/consolidated/export'
 */
exportConsolidatedReports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportConsolidatedReports.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::exportConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:618
 * @route '/admin/api/reports/consolidated/export'
 */
    const exportConsolidatedReportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportConsolidatedReports.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::exportConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:618
 * @route '/admin/api/reports/consolidated/export'
 */
        exportConsolidatedReportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportConsolidatedReports.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::exportConsolidatedReports
 * @see app/Http/Controllers/ReportController.php:618
 * @route '/admin/api/reports/consolidated/export'
 */
        exportConsolidatedReportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportConsolidatedReports.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportConsolidatedReports.form = exportConsolidatedReportsForm
const ReportController = { index, edit, show, getEmployees, store, getDailyReportAll, getDailyReport, connectTaskToReport, disconnectTaskFromReport, addAttachment, getEmployeeReports, getAllReports, update, destroy, deleteAttachment, getConsolidatedReports, exportConsolidatedReports }

export default ReportController