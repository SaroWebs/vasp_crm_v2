import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminClientSsoTestController::redirectToSso
 * @see app/Http/Controllers/AdminClientSsoTestController.php:13
 * @route '/clients/{clientCode}/sso/test'
 */
export const redirectToSso = (args: { clientCode: string | number } | [clientCode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToSso.url(args, options),
    method: 'get',
})

redirectToSso.definition = {
    methods: ["get","head"],
    url: '/clients/{clientCode}/sso/test',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminClientSsoTestController::redirectToSso
 * @see app/Http/Controllers/AdminClientSsoTestController.php:13
 * @route '/clients/{clientCode}/sso/test'
 */
redirectToSso.url = (args: { clientCode: string | number } | [clientCode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clientCode: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    clientCode: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clientCode: args.clientCode,
                }

    return redirectToSso.definition.url
            .replace('{clientCode}', parsedArgs.clientCode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminClientSsoTestController::redirectToSso
 * @see app/Http/Controllers/AdminClientSsoTestController.php:13
 * @route '/clients/{clientCode}/sso/test'
 */
redirectToSso.get = (args: { clientCode: string | number } | [clientCode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToSso.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminClientSsoTestController::redirectToSso
 * @see app/Http/Controllers/AdminClientSsoTestController.php:13
 * @route '/clients/{clientCode}/sso/test'
 */
redirectToSso.head = (args: { clientCode: string | number } | [clientCode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectToSso.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminClientSsoTestController::redirectToSso
 * @see app/Http/Controllers/AdminClientSsoTestController.php:13
 * @route '/clients/{clientCode}/sso/test'
 */
    const redirectToSsoForm = (args: { clientCode: string | number } | [clientCode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: redirectToSso.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminClientSsoTestController::redirectToSso
 * @see app/Http/Controllers/AdminClientSsoTestController.php:13
 * @route '/clients/{clientCode}/sso/test'
 */
        redirectToSsoForm.get = (args: { clientCode: string | number } | [clientCode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToSso.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminClientSsoTestController::redirectToSso
 * @see app/Http/Controllers/AdminClientSsoTestController.php:13
 * @route '/clients/{clientCode}/sso/test'
 */
        redirectToSsoForm.head = (args: { clientCode: string | number } | [clientCode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToSso.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    redirectToSso.form = redirectToSsoForm
const AdminClientSsoTestController = { redirectToSso }

export default AdminClientSsoTestController