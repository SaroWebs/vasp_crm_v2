import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProjectAttachmentController::index
 * @see app/Http/Controllers/ProjectAttachmentController.php:24
 * @route '/admin/projects/{project}/attachments'
 */
export const index = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/attachments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectAttachmentController::index
 * @see app/Http/Controllers/ProjectAttachmentController.php:24
 * @route '/admin/projects/{project}/attachments'
 */
index.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return index.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectAttachmentController::index
 * @see app/Http/Controllers/ProjectAttachmentController.php:24
 * @route '/admin/projects/{project}/attachments'
 */
index.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectAttachmentController::index
 * @see app/Http/Controllers/ProjectAttachmentController.php:24
 * @route '/admin/projects/{project}/attachments'
 */
index.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectAttachmentController::index
 * @see app/Http/Controllers/ProjectAttachmentController.php:24
 * @route '/admin/projects/{project}/attachments'
 */
    const indexForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectAttachmentController::index
 * @see app/Http/Controllers/ProjectAttachmentController.php:24
 * @route '/admin/projects/{project}/attachments'
 */
        indexForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectAttachmentController::index
 * @see app/Http/Controllers/ProjectAttachmentController.php:24
 * @route '/admin/projects/{project}/attachments'
 */
        indexForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ProjectAttachmentController::store
 * @see app/Http/Controllers/ProjectAttachmentController.php:41
 * @route '/admin/projects/{project}/attachments'
 */
export const store = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectAttachmentController::store
 * @see app/Http/Controllers/ProjectAttachmentController.php:41
 * @route '/admin/projects/{project}/attachments'
 */
store.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return store.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectAttachmentController::store
 * @see app/Http/Controllers/ProjectAttachmentController.php:41
 * @route '/admin/projects/{project}/attachments'
 */
store.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectAttachmentController::store
 * @see app/Http/Controllers/ProjectAttachmentController.php:41
 * @route '/admin/projects/{project}/attachments'
 */
    const storeForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectAttachmentController::store
 * @see app/Http/Controllers/ProjectAttachmentController.php:41
 * @route '/admin/projects/{project}/attachments'
 */
        storeForm.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ProjectAttachmentController::show
 * @see app/Http/Controllers/ProjectAttachmentController.php:75
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
export const show = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/attachments/{attachment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectAttachmentController::show
 * @see app/Http/Controllers/ProjectAttachmentController.php:75
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
show.url = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return show.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectAttachmentController::show
 * @see app/Http/Controllers/ProjectAttachmentController.php:75
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
show.get = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectAttachmentController::show
 * @see app/Http/Controllers/ProjectAttachmentController.php:75
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
show.head = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectAttachmentController::show
 * @see app/Http/Controllers/ProjectAttachmentController.php:75
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
    const showForm = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectAttachmentController::show
 * @see app/Http/Controllers/ProjectAttachmentController.php:75
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
        showForm.get = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectAttachmentController::show
 * @see app/Http/Controllers/ProjectAttachmentController.php:75
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
        showForm.head = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ProjectAttachmentController::download
 * @see app/Http/Controllers/ProjectAttachmentController.php:91
 * @route '/admin/projects/{project}/attachments/{attachment}/download'
 */
export const download = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/attachments/{attachment}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectAttachmentController::download
 * @see app/Http/Controllers/ProjectAttachmentController.php:91
 * @route '/admin/projects/{project}/attachments/{attachment}/download'
 */
download.url = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return download.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectAttachmentController::download
 * @see app/Http/Controllers/ProjectAttachmentController.php:91
 * @route '/admin/projects/{project}/attachments/{attachment}/download'
 */
download.get = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectAttachmentController::download
 * @see app/Http/Controllers/ProjectAttachmentController.php:91
 * @route '/admin/projects/{project}/attachments/{attachment}/download'
 */
download.head = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectAttachmentController::download
 * @see app/Http/Controllers/ProjectAttachmentController.php:91
 * @route '/admin/projects/{project}/attachments/{attachment}/download'
 */
    const downloadForm = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectAttachmentController::download
 * @see app/Http/Controllers/ProjectAttachmentController.php:91
 * @route '/admin/projects/{project}/attachments/{attachment}/download'
 */
        downloadForm.get = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectAttachmentController::download
 * @see app/Http/Controllers/ProjectAttachmentController.php:91
 * @route '/admin/projects/{project}/attachments/{attachment}/download'
 */
        downloadForm.head = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
/**
* @see \App\Http\Controllers\ProjectAttachmentController::preview
 * @see app/Http/Controllers/ProjectAttachmentController.php:163
 * @route '/admin/projects/{project}/attachments/{attachment}/preview'
 */
export const preview = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/attachments/{attachment}/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectAttachmentController::preview
 * @see app/Http/Controllers/ProjectAttachmentController.php:163
 * @route '/admin/projects/{project}/attachments/{attachment}/preview'
 */
preview.url = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return preview.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectAttachmentController::preview
 * @see app/Http/Controllers/ProjectAttachmentController.php:163
 * @route '/admin/projects/{project}/attachments/{attachment}/preview'
 */
preview.get = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectAttachmentController::preview
 * @see app/Http/Controllers/ProjectAttachmentController.php:163
 * @route '/admin/projects/{project}/attachments/{attachment}/preview'
 */
preview.head = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectAttachmentController::preview
 * @see app/Http/Controllers/ProjectAttachmentController.php:163
 * @route '/admin/projects/{project}/attachments/{attachment}/preview'
 */
    const previewForm = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preview.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectAttachmentController::preview
 * @see app/Http/Controllers/ProjectAttachmentController.php:163
 * @route '/admin/projects/{project}/attachments/{attachment}/preview'
 */
        previewForm.get = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectAttachmentController::preview
 * @see app/Http/Controllers/ProjectAttachmentController.php:163
 * @route '/admin/projects/{project}/attachments/{attachment}/preview'
 */
        previewForm.head = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preview.form = previewForm
/**
* @see \App\Http\Controllers\ProjectAttachmentController::update
 * @see app/Http/Controllers/ProjectAttachmentController.php:111
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
export const update = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/projects/{project}/attachments/{attachment}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ProjectAttachmentController::update
 * @see app/Http/Controllers/ProjectAttachmentController.php:111
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
update.url = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return update.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectAttachmentController::update
 * @see app/Http/Controllers/ProjectAttachmentController.php:111
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
update.patch = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProjectAttachmentController::update
 * @see app/Http/Controllers/ProjectAttachmentController.php:111
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
    const updateForm = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectAttachmentController::update
 * @see app/Http/Controllers/ProjectAttachmentController.php:111
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
        updateForm.patch = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ProjectAttachmentController::destroy
 * @see app/Http/Controllers/ProjectAttachmentController.php:138
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
export const destroy = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/projects/{project}/attachments/{attachment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProjectAttachmentController::destroy
 * @see app/Http/Controllers/ProjectAttachmentController.php:138
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
destroy.url = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return destroy.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectAttachmentController::destroy
 * @see app/Http/Controllers/ProjectAttachmentController.php:138
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
destroy.delete = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ProjectAttachmentController::destroy
 * @see app/Http/Controllers/ProjectAttachmentController.php:138
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
    const destroyForm = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectAttachmentController::destroy
 * @see app/Http/Controllers/ProjectAttachmentController.php:138
 * @route '/admin/projects/{project}/attachments/{attachment}'
 */
        destroyForm.delete = (args: { project: number | { id: number }, attachment: number | { id: number } } | [project: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ProjectAttachmentController = { index, store, show, download, preview, update, destroy }

export default ProjectAttachmentController