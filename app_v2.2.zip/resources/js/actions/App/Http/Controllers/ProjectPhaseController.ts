import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProjectPhaseController::index
 * @see app/Http/Controllers/ProjectPhaseController.php:24
 * @route '/admin/projects/{project}/phases'
 */
export const index = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/phases',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectPhaseController::index
 * @see app/Http/Controllers/ProjectPhaseController.php:24
 * @route '/admin/projects/{project}/phases'
 */
index.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return index.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectPhaseController::index
 * @see app/Http/Controllers/ProjectPhaseController.php:24
 * @route '/admin/projects/{project}/phases'
 */
index.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectPhaseController::index
 * @see app/Http/Controllers/ProjectPhaseController.php:24
 * @route '/admin/projects/{project}/phases'
 */
index.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectPhaseController::index
 * @see app/Http/Controllers/ProjectPhaseController.php:24
 * @route '/admin/projects/{project}/phases'
 */
    const indexForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectPhaseController::index
 * @see app/Http/Controllers/ProjectPhaseController.php:24
 * @route '/admin/projects/{project}/phases'
 */
        indexForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectPhaseController::index
 * @see app/Http/Controllers/ProjectPhaseController.php:24
 * @route '/admin/projects/{project}/phases'
 */
        indexForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ProjectPhaseController::store
 * @see app/Http/Controllers/ProjectPhaseController.php:41
 * @route '/admin/projects/{project}/phases'
 */
export const store = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/phases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectPhaseController::store
 * @see app/Http/Controllers/ProjectPhaseController.php:41
 * @route '/admin/projects/{project}/phases'
 */
store.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return store.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectPhaseController::store
 * @see app/Http/Controllers/ProjectPhaseController.php:41
 * @route '/admin/projects/{project}/phases'
 */
store.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectPhaseController::store
 * @see app/Http/Controllers/ProjectPhaseController.php:41
 * @route '/admin/projects/{project}/phases'
 */
    const storeForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectPhaseController::store
 * @see app/Http/Controllers/ProjectPhaseController.php:41
 * @route '/admin/projects/{project}/phases'
 */
        storeForm.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ProjectPhaseController::show
 * @see app/Http/Controllers/ProjectPhaseController.php:78
 * @route '/admin/projects/{project}/phases/{phase}'
 */
export const show = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/phases/{phase}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectPhaseController::show
 * @see app/Http/Controllers/ProjectPhaseController.php:78
 * @route '/admin/projects/{project}/phases/{phase}'
 */
show.url = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    phase: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                phase: typeof args.phase === 'object'
                ? args.phase.id
                : args.phase,
                }

    return show.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectPhaseController::show
 * @see app/Http/Controllers/ProjectPhaseController.php:78
 * @route '/admin/projects/{project}/phases/{phase}'
 */
show.get = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectPhaseController::show
 * @see app/Http/Controllers/ProjectPhaseController.php:78
 * @route '/admin/projects/{project}/phases/{phase}'
 */
show.head = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectPhaseController::show
 * @see app/Http/Controllers/ProjectPhaseController.php:78
 * @route '/admin/projects/{project}/phases/{phase}'
 */
    const showForm = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectPhaseController::show
 * @see app/Http/Controllers/ProjectPhaseController.php:78
 * @route '/admin/projects/{project}/phases/{phase}'
 */
        showForm.get = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectPhaseController::show
 * @see app/Http/Controllers/ProjectPhaseController.php:78
 * @route '/admin/projects/{project}/phases/{phase}'
 */
        showForm.head = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ProjectPhaseController::update
 * @see app/Http/Controllers/ProjectPhaseController.php:98
 * @route '/admin/projects/{project}/phases/{phase}'
 */
export const update = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/projects/{project}/phases/{phase}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ProjectPhaseController::update
 * @see app/Http/Controllers/ProjectPhaseController.php:98
 * @route '/admin/projects/{project}/phases/{phase}'
 */
update.url = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    phase: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                phase: typeof args.phase === 'object'
                ? args.phase.id
                : args.phase,
                }

    return update.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectPhaseController::update
 * @see app/Http/Controllers/ProjectPhaseController.php:98
 * @route '/admin/projects/{project}/phases/{phase}'
 */
update.patch = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProjectPhaseController::update
 * @see app/Http/Controllers/ProjectPhaseController.php:98
 * @route '/admin/projects/{project}/phases/{phase}'
 */
    const updateForm = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectPhaseController::update
 * @see app/Http/Controllers/ProjectPhaseController.php:98
 * @route '/admin/projects/{project}/phases/{phase}'
 */
        updateForm.patch = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ProjectPhaseController::destroy
 * @see app/Http/Controllers/ProjectPhaseController.php:131
 * @route '/admin/projects/{project}/phases/{phase}'
 */
export const destroy = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/projects/{project}/phases/{phase}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProjectPhaseController::destroy
 * @see app/Http/Controllers/ProjectPhaseController.php:131
 * @route '/admin/projects/{project}/phases/{phase}'
 */
destroy.url = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    phase: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                phase: typeof args.phase === 'object'
                ? args.phase.id
                : args.phase,
                }

    return destroy.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectPhaseController::destroy
 * @see app/Http/Controllers/ProjectPhaseController.php:131
 * @route '/admin/projects/{project}/phases/{phase}'
 */
destroy.delete = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ProjectPhaseController::destroy
 * @see app/Http/Controllers/ProjectPhaseController.php:131
 * @route '/admin/projects/{project}/phases/{phase}'
 */
    const destroyForm = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectPhaseController::destroy
 * @see app/Http/Controllers/ProjectPhaseController.php:131
 * @route '/admin/projects/{project}/phases/{phase}'
 */
        destroyForm.delete = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\ProjectPhaseController::reorder
 * @see app/Http/Controllers/ProjectPhaseController.php:158
 * @route '/admin/projects/{project}/phases/reorder'
 */
export const reorder = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(args, options),
    method: 'post',
})

reorder.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/phases/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectPhaseController::reorder
 * @see app/Http/Controllers/ProjectPhaseController.php:158
 * @route '/admin/projects/{project}/phases/reorder'
 */
reorder.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return reorder.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectPhaseController::reorder
 * @see app/Http/Controllers/ProjectPhaseController.php:158
 * @route '/admin/projects/{project}/phases/reorder'
 */
reorder.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectPhaseController::reorder
 * @see app/Http/Controllers/ProjectPhaseController.php:158
 * @route '/admin/projects/{project}/phases/reorder'
 */
    const reorderForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectPhaseController::reorder
 * @see app/Http/Controllers/ProjectPhaseController.php:158
 * @route '/admin/projects/{project}/phases/reorder'
 */
        reorderForm.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url(args, options),
            method: 'post',
        })
    
    reorder.form = reorderForm
/**
* @see \App\Http\Controllers\ProjectPhaseController::getTasks
 * @see app/Http/Controllers/ProjectPhaseController.php:186
 * @route '/admin/projects/{project}/phases/{phase}/tasks'
 */
export const getTasks = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTasks.url(args, options),
    method: 'get',
})

getTasks.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/phases/{phase}/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectPhaseController::getTasks
 * @see app/Http/Controllers/ProjectPhaseController.php:186
 * @route '/admin/projects/{project}/phases/{phase}/tasks'
 */
getTasks.url = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    phase: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                phase: typeof args.phase === 'object'
                ? args.phase.id
                : args.phase,
                }

    return getTasks.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectPhaseController::getTasks
 * @see app/Http/Controllers/ProjectPhaseController.php:186
 * @route '/admin/projects/{project}/phases/{phase}/tasks'
 */
getTasks.get = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTasks.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectPhaseController::getTasks
 * @see app/Http/Controllers/ProjectPhaseController.php:186
 * @route '/admin/projects/{project}/phases/{phase}/tasks'
 */
getTasks.head = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTasks.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectPhaseController::getTasks
 * @see app/Http/Controllers/ProjectPhaseController.php:186
 * @route '/admin/projects/{project}/phases/{phase}/tasks'
 */
    const getTasksForm = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTasks.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectPhaseController::getTasks
 * @see app/Http/Controllers/ProjectPhaseController.php:186
 * @route '/admin/projects/{project}/phases/{phase}/tasks'
 */
        getTasksForm.get = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTasks.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectPhaseController::getTasks
 * @see app/Http/Controllers/ProjectPhaseController.php:186
 * @route '/admin/projects/{project}/phases/{phase}/tasks'
 */
        getTasksForm.head = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTasks.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTasks.form = getTasksForm
/**
* @see \App\Http\Controllers\ProjectPhaseController::updateProgress
 * @see app/Http/Controllers/ProjectPhaseController.php:207
 * @route '/admin/projects/{project}/phases/{phase}/update-progress'
 */
export const updateProgress = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateProgress.url(args, options),
    method: 'post',
})

updateProgress.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/phases/{phase}/update-progress',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectPhaseController::updateProgress
 * @see app/Http/Controllers/ProjectPhaseController.php:207
 * @route '/admin/projects/{project}/phases/{phase}/update-progress'
 */
updateProgress.url = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    phase: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                phase: typeof args.phase === 'object'
                ? args.phase.id
                : args.phase,
                }

    return updateProgress.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectPhaseController::updateProgress
 * @see app/Http/Controllers/ProjectPhaseController.php:207
 * @route '/admin/projects/{project}/phases/{phase}/update-progress'
 */
updateProgress.post = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateProgress.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectPhaseController::updateProgress
 * @see app/Http/Controllers/ProjectPhaseController.php:207
 * @route '/admin/projects/{project}/phases/{phase}/update-progress'
 */
    const updateProgressForm = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateProgress.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectPhaseController::updateProgress
 * @see app/Http/Controllers/ProjectPhaseController.php:207
 * @route '/admin/projects/{project}/phases/{phase}/update-progress'
 */
        updateProgressForm.post = (args: { project: number | { id: number }, phase: number | { id: number } } | [project: number | { id: number }, phase: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateProgress.url(args, options),
            method: 'post',
        })
    
    updateProgress.form = updateProgressForm
const ProjectPhaseController = { index, store, show, update, destroy, reorder, getTasks, updateProgress }

export default ProjectPhaseController