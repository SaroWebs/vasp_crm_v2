import AdminClientSsoTestController from './AdminClientSsoTestController'
import ClientSsoController from './ClientSsoController'
import Client from './Client'
import AdminAuthController from './AdminAuthController'
import AdminDashboardController from './AdminDashboardController'
import ClientController from './ClientController'
import OrganizationUserController from './OrganizationUserController'
import ProjectController from './ProjectController'
import ProjectMilestoneController from './ProjectMilestoneController'
import ProjectPhaseController from './ProjectPhaseController'
import ProjectTimelineController from './ProjectTimelineController'
import ProjectAttachmentController from './ProjectAttachmentController'
import ProductController from './ProductController'
import AdminTicketController from './AdminTicketController'
import TicketCommentController from './TicketCommentController'
import CommentAttachmentController from './CommentAttachmentController'
import AdminTaskController from './AdminTaskController'
import TaskAssignmentController from './TaskAssignmentController'
import DepartmentController from './DepartmentController'
import NotificationController from './NotificationController'
import MenuManagementController from './MenuManagementController'
import RoleController from './RoleController'
import PermissionController from './PermissionController'
import UserController from './UserController'
import EmployeeController from './EmployeeController'
import EmployeeProgressController from './EmployeeProgressController'
import WorkloadMatrixController from './WorkloadMatrixController'
import ReportController from './ReportController'
import TaskController from './TaskController'
import TaskCommentController from './TaskCommentController'
import TaskAttachmentController from './TaskAttachmentController'
import TaskForwardingController from './TaskForwardingController'
import UserTaskController from './UserTaskController'
import TimeTrackingController from './TimeTrackingController'
import TimelineEventController from './TimelineEventController'
import TaskDependencyController from './TaskDependencyController'
import ActivityLogController from './ActivityLogController'
import Settings from './Settings'
const Controllers = {
    AdminClientSsoTestController: Object.assign(AdminClientSsoTestController, AdminClientSsoTestController),
ClientSsoController: Object.assign(ClientSsoController, ClientSsoController),
Client: Object.assign(Client, Client),
AdminAuthController: Object.assign(AdminAuthController, AdminAuthController),
AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
ClientController: Object.assign(ClientController, ClientController),
OrganizationUserController: Object.assign(OrganizationUserController, OrganizationUserController),
ProjectController: Object.assign(ProjectController, ProjectController),
ProjectMilestoneController: Object.assign(ProjectMilestoneController, ProjectMilestoneController),
ProjectPhaseController: Object.assign(ProjectPhaseController, ProjectPhaseController),
ProjectTimelineController: Object.assign(ProjectTimelineController, ProjectTimelineController),
ProjectAttachmentController: Object.assign(ProjectAttachmentController, ProjectAttachmentController),
ProductController: Object.assign(ProductController, ProductController),
AdminTicketController: Object.assign(AdminTicketController, AdminTicketController),
TicketCommentController: Object.assign(TicketCommentController, TicketCommentController),
CommentAttachmentController: Object.assign(CommentAttachmentController, CommentAttachmentController),
AdminTaskController: Object.assign(AdminTaskController, AdminTaskController),
TaskAssignmentController: Object.assign(TaskAssignmentController, TaskAssignmentController),
DepartmentController: Object.assign(DepartmentController, DepartmentController),
NotificationController: Object.assign(NotificationController, NotificationController),
MenuManagementController: Object.assign(MenuManagementController, MenuManagementController),
RoleController: Object.assign(RoleController, RoleController),
PermissionController: Object.assign(PermissionController, PermissionController),
UserController: Object.assign(UserController, UserController),
EmployeeController: Object.assign(EmployeeController, EmployeeController),
EmployeeProgressController: Object.assign(EmployeeProgressController, EmployeeProgressController),
WorkloadMatrixController: Object.assign(WorkloadMatrixController, WorkloadMatrixController),
ReportController: Object.assign(ReportController, ReportController),
TaskController: Object.assign(TaskController, TaskController),
TaskCommentController: Object.assign(TaskCommentController, TaskCommentController),
TaskAttachmentController: Object.assign(TaskAttachmentController, TaskAttachmentController),
TaskForwardingController: Object.assign(TaskForwardingController, TaskForwardingController),
UserTaskController: Object.assign(UserTaskController, UserTaskController),
TimeTrackingController: Object.assign(TimeTrackingController, TimeTrackingController),
TimelineEventController: Object.assign(TimelineEventController, TimelineEventController),
TaskDependencyController: Object.assign(TaskDependencyController, TaskDependencyController),
ActivityLogController: Object.assign(ActivityLogController, ActivityLogController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers