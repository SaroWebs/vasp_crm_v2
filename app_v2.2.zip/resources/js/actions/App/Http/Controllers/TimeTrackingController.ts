import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TimeTrackingController::extendDueDateAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:364
 * @route '/my/tasks/{task}/extend-and-start'
 */
export const extendDueDateAndStart = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extendDueDateAndStart.url(args, options),
    method: 'post',
})

extendDueDateAndStart.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/extend-and-start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimeTrackingController::extendDueDateAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:364
 * @route '/my/tasks/{task}/extend-and-start'
 */
extendDueDateAndStart.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return extendDueDateAndStart.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTrackingController::extendDueDateAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:364
 * @route '/my/tasks/{task}/extend-and-start'
 */
extendDueDateAndStart.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extendDueDateAndStart.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TimeTrackingController::extendDueDateAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:364
 * @route '/my/tasks/{task}/extend-and-start'
 */
    const extendDueDateAndStartForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: extendDueDateAndStart.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimeTrackingController::extendDueDateAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:364
 * @route '/my/tasks/{task}/extend-and-start'
 */
        extendDueDateAndStartForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: extendDueDateAndStart.url(args, options),
            method: 'post',
        })
    
    extendDueDateAndStart.form = extendDueDateAndStartForm
/**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:272
 * @route '/my/tasks/{task}/working-time-spent'
 */
export const getWorkingTimeSpent = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getWorkingTimeSpent.url(args, options),
    method: 'get',
})

getWorkingTimeSpent.definition = {
    methods: ["get","head"],
    url: '/my/tasks/{task}/working-time-spent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:272
 * @route '/my/tasks/{task}/working-time-spent'
 */
getWorkingTimeSpent.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return getWorkingTimeSpent.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:272
 * @route '/my/tasks/{task}/working-time-spent'
 */
getWorkingTimeSpent.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getWorkingTimeSpent.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:272
 * @route '/my/tasks/{task}/working-time-spent'
 */
getWorkingTimeSpent.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getWorkingTimeSpent.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:272
 * @route '/my/tasks/{task}/working-time-spent'
 */
    const getWorkingTimeSpentForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getWorkingTimeSpent.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:272
 * @route '/my/tasks/{task}/working-time-spent'
 */
        getWorkingTimeSpentForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getWorkingTimeSpent.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:272
 * @route '/my/tasks/{task}/working-time-spent'
 */
        getWorkingTimeSpentForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getWorkingTimeSpent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getWorkingTimeSpent.form = getWorkingTimeSpentForm
/**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:349
 * @route '/api/working-hours-config'
 */
export const getWorkingHoursConfig = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getWorkingHoursConfig.url(options),
    method: 'get',
})

getWorkingHoursConfig.definition = {
    methods: ["get","head"],
    url: '/api/working-hours-config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:349
 * @route '/api/working-hours-config'
 */
getWorkingHoursConfig.url = (options?: RouteQueryOptions) => {
    return getWorkingHoursConfig.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:349
 * @route '/api/working-hours-config'
 */
getWorkingHoursConfig.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getWorkingHoursConfig.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:349
 * @route '/api/working-hours-config'
 */
getWorkingHoursConfig.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getWorkingHoursConfig.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:349
 * @route '/api/working-hours-config'
 */
    const getWorkingHoursConfigForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getWorkingHoursConfig.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:349
 * @route '/api/working-hours-config'
 */
        getWorkingHoursConfigForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getWorkingHoursConfig.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimeTrackingController::getWorkingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:349
 * @route '/api/working-hours-config'
 */
        getWorkingHoursConfigForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getWorkingHoursConfig.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getWorkingHoursConfig.form = getWorkingHoursConfigForm
const TimeTrackingController = { extendDueDateAndStart, getWorkingTimeSpent, getWorkingHoursConfig }

export default TimeTrackingController