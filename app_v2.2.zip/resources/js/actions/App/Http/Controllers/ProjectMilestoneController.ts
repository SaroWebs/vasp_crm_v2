import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProjectMilestoneController::index
 * @see app/Http/Controllers/ProjectMilestoneController.php:24
 * @route '/admin/projects/{project}/milestones'
 */
export const index = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/milestones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectMilestoneController::index
 * @see app/Http/Controllers/ProjectMilestoneController.php:24
 * @route '/admin/projects/{project}/milestones'
 */
index.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return index.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectMilestoneController::index
 * @see app/Http/Controllers/ProjectMilestoneController.php:24
 * @route '/admin/projects/{project}/milestones'
 */
index.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectMilestoneController::index
 * @see app/Http/Controllers/ProjectMilestoneController.php:24
 * @route '/admin/projects/{project}/milestones'
 */
index.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectMilestoneController::index
 * @see app/Http/Controllers/ProjectMilestoneController.php:24
 * @route '/admin/projects/{project}/milestones'
 */
    const indexForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectMilestoneController::index
 * @see app/Http/Controllers/ProjectMilestoneController.php:24
 * @route '/admin/projects/{project}/milestones'
 */
        indexForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectMilestoneController::index
 * @see app/Http/Controllers/ProjectMilestoneController.php:24
 * @route '/admin/projects/{project}/milestones'
 */
        indexForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ProjectMilestoneController::store
 * @see app/Http/Controllers/ProjectMilestoneController.php:41
 * @route '/admin/projects/{project}/milestones'
 */
export const store = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/milestones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectMilestoneController::store
 * @see app/Http/Controllers/ProjectMilestoneController.php:41
 * @route '/admin/projects/{project}/milestones'
 */
store.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return store.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectMilestoneController::store
 * @see app/Http/Controllers/ProjectMilestoneController.php:41
 * @route '/admin/projects/{project}/milestones'
 */
store.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectMilestoneController::store
 * @see app/Http/Controllers/ProjectMilestoneController.php:41
 * @route '/admin/projects/{project}/milestones'
 */
    const storeForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectMilestoneController::store
 * @see app/Http/Controllers/ProjectMilestoneController.php:41
 * @route '/admin/projects/{project}/milestones'
 */
        storeForm.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ProjectMilestoneController::show
 * @see app/Http/Controllers/ProjectMilestoneController.php:75
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
export const show = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/milestones/{milestone}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectMilestoneController::show
 * @see app/Http/Controllers/ProjectMilestoneController.php:75
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
show.url = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    milestone: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                milestone: typeof args.milestone === 'object'
                ? args.milestone.id
                : args.milestone,
                }

    return show.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{milestone}', parsedArgs.milestone.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectMilestoneController::show
 * @see app/Http/Controllers/ProjectMilestoneController.php:75
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
show.get = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectMilestoneController::show
 * @see app/Http/Controllers/ProjectMilestoneController.php:75
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
show.head = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectMilestoneController::show
 * @see app/Http/Controllers/ProjectMilestoneController.php:75
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
    const showForm = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectMilestoneController::show
 * @see app/Http/Controllers/ProjectMilestoneController.php:75
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
        showForm.get = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectMilestoneController::show
 * @see app/Http/Controllers/ProjectMilestoneController.php:75
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
        showForm.head = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ProjectMilestoneController::update
 * @see app/Http/Controllers/ProjectMilestoneController.php:91
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
export const update = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/projects/{project}/milestones/{milestone}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ProjectMilestoneController::update
 * @see app/Http/Controllers/ProjectMilestoneController.php:91
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
update.url = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    milestone: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                milestone: typeof args.milestone === 'object'
                ? args.milestone.id
                : args.milestone,
                }

    return update.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{milestone}', parsedArgs.milestone.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectMilestoneController::update
 * @see app/Http/Controllers/ProjectMilestoneController.php:91
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
update.patch = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProjectMilestoneController::update
 * @see app/Http/Controllers/ProjectMilestoneController.php:91
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
    const updateForm = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectMilestoneController::update
 * @see app/Http/Controllers/ProjectMilestoneController.php:91
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
        updateForm.patch = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ProjectMilestoneController::destroy
 * @see app/Http/Controllers/ProjectMilestoneController.php:123
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
export const destroy = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/projects/{project}/milestones/{milestone}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProjectMilestoneController::destroy
 * @see app/Http/Controllers/ProjectMilestoneController.php:123
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
destroy.url = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    milestone: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                milestone: typeof args.milestone === 'object'
                ? args.milestone.id
                : args.milestone,
                }

    return destroy.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{milestone}', parsedArgs.milestone.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectMilestoneController::destroy
 * @see app/Http/Controllers/ProjectMilestoneController.php:123
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
destroy.delete = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ProjectMilestoneController::destroy
 * @see app/Http/Controllers/ProjectMilestoneController.php:123
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
    const destroyForm = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectMilestoneController::destroy
 * @see app/Http/Controllers/ProjectMilestoneController.php:123
 * @route '/admin/projects/{project}/milestones/{milestone}'
 */
        destroyForm.delete = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\ProjectMilestoneController::complete
 * @see app/Http/Controllers/ProjectMilestoneController.php:143
 * @route '/admin/projects/{project}/milestones/{milestone}/complete'
 */
export const complete = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/milestones/{milestone}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectMilestoneController::complete
 * @see app/Http/Controllers/ProjectMilestoneController.php:143
 * @route '/admin/projects/{project}/milestones/{milestone}/complete'
 */
complete.url = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    milestone: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                milestone: typeof args.milestone === 'object'
                ? args.milestone.id
                : args.milestone,
                }

    return complete.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{milestone}', parsedArgs.milestone.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectMilestoneController::complete
 * @see app/Http/Controllers/ProjectMilestoneController.php:143
 * @route '/admin/projects/{project}/milestones/{milestone}/complete'
 */
complete.post = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectMilestoneController::complete
 * @see app/Http/Controllers/ProjectMilestoneController.php:143
 * @route '/admin/projects/{project}/milestones/{milestone}/complete'
 */
    const completeForm = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectMilestoneController::complete
 * @see app/Http/Controllers/ProjectMilestoneController.php:143
 * @route '/admin/projects/{project}/milestones/{milestone}/complete'
 */
        completeForm.post = (args: { project: number | { id: number }, milestone: number | { id: number } } | [project: number | { id: number }, milestone: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
/**
* @see \App\Http\Controllers\ProjectMilestoneController::reorder
 * @see app/Http/Controllers/ProjectMilestoneController.php:164
 * @route '/admin/projects/{project}/milestones/reorder'
 */
export const reorder = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(args, options),
    method: 'post',
})

reorder.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/milestones/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectMilestoneController::reorder
 * @see app/Http/Controllers/ProjectMilestoneController.php:164
 * @route '/admin/projects/{project}/milestones/reorder'
 */
reorder.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return reorder.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectMilestoneController::reorder
 * @see app/Http/Controllers/ProjectMilestoneController.php:164
 * @route '/admin/projects/{project}/milestones/reorder'
 */
reorder.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectMilestoneController::reorder
 * @see app/Http/Controllers/ProjectMilestoneController.php:164
 * @route '/admin/projects/{project}/milestones/reorder'
 */
    const reorderForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectMilestoneController::reorder
 * @see app/Http/Controllers/ProjectMilestoneController.php:164
 * @route '/admin/projects/{project}/milestones/reorder'
 */
        reorderForm.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url(args, options),
            method: 'post',
        })
    
    reorder.form = reorderForm
/**
* @see \App\Http\Controllers\ProjectMilestoneController::overdue
 * @see app/Http/Controllers/ProjectMilestoneController.php:192
 * @route '/admin/projects/{project}/milestones/overdue'
 */
export const overdue = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: overdue.url(args, options),
    method: 'get',
})

overdue.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/milestones/overdue',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectMilestoneController::overdue
 * @see app/Http/Controllers/ProjectMilestoneController.php:192
 * @route '/admin/projects/{project}/milestones/overdue'
 */
overdue.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return overdue.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectMilestoneController::overdue
 * @see app/Http/Controllers/ProjectMilestoneController.php:192
 * @route '/admin/projects/{project}/milestones/overdue'
 */
overdue.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: overdue.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectMilestoneController::overdue
 * @see app/Http/Controllers/ProjectMilestoneController.php:192
 * @route '/admin/projects/{project}/milestones/overdue'
 */
overdue.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: overdue.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectMilestoneController::overdue
 * @see app/Http/Controllers/ProjectMilestoneController.php:192
 * @route '/admin/projects/{project}/milestones/overdue'
 */
    const overdueForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: overdue.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectMilestoneController::overdue
 * @see app/Http/Controllers/ProjectMilestoneController.php:192
 * @route '/admin/projects/{project}/milestones/overdue'
 */
        overdueForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: overdue.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectMilestoneController::overdue
 * @see app/Http/Controllers/ProjectMilestoneController.php:192
 * @route '/admin/projects/{project}/milestones/overdue'
 */
        overdueForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: overdue.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    overdue.form = overdueForm
/**
* @see \App\Http\Controllers\ProjectMilestoneController::upcoming
 * @see app/Http/Controllers/ProjectMilestoneController.php:206
 * @route '/admin/projects/{project}/milestones/upcoming'
 */
export const upcoming = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: upcoming.url(args, options),
    method: 'get',
})

upcoming.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/milestones/upcoming',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectMilestoneController::upcoming
 * @see app/Http/Controllers/ProjectMilestoneController.php:206
 * @route '/admin/projects/{project}/milestones/upcoming'
 */
upcoming.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return upcoming.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectMilestoneController::upcoming
 * @see app/Http/Controllers/ProjectMilestoneController.php:206
 * @route '/admin/projects/{project}/milestones/upcoming'
 */
upcoming.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: upcoming.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectMilestoneController::upcoming
 * @see app/Http/Controllers/ProjectMilestoneController.php:206
 * @route '/admin/projects/{project}/milestones/upcoming'
 */
upcoming.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: upcoming.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectMilestoneController::upcoming
 * @see app/Http/Controllers/ProjectMilestoneController.php:206
 * @route '/admin/projects/{project}/milestones/upcoming'
 */
    const upcomingForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: upcoming.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectMilestoneController::upcoming
 * @see app/Http/Controllers/ProjectMilestoneController.php:206
 * @route '/admin/projects/{project}/milestones/upcoming'
 */
        upcomingForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: upcoming.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectMilestoneController::upcoming
 * @see app/Http/Controllers/ProjectMilestoneController.php:206
 * @route '/admin/projects/{project}/milestones/upcoming'
 */
        upcomingForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: upcoming.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    upcoming.form = upcomingForm
const ProjectMilestoneController = { index, store, show, update, destroy, complete, reorder, overdue, upcoming }

export default ProjectMilestoneController