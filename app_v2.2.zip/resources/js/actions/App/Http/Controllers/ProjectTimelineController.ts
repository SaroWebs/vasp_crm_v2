import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProjectTimelineController::index
 * @see app/Http/Controllers/ProjectTimelineController.php:23
 * @route '/admin/projects/{project}/timeline'
 */
export const index = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/timeline',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectTimelineController::index
 * @see app/Http/Controllers/ProjectTimelineController.php:23
 * @route '/admin/projects/{project}/timeline'
 */
index.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return index.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectTimelineController::index
 * @see app/Http/Controllers/ProjectTimelineController.php:23
 * @route '/admin/projects/{project}/timeline'
 */
index.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectTimelineController::index
 * @see app/Http/Controllers/ProjectTimelineController.php:23
 * @route '/admin/projects/{project}/timeline'
 */
index.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectTimelineController::index
 * @see app/Http/Controllers/ProjectTimelineController.php:23
 * @route '/admin/projects/{project}/timeline'
 */
    const indexForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectTimelineController::index
 * @see app/Http/Controllers/ProjectTimelineController.php:23
 * @route '/admin/projects/{project}/timeline'
 */
        indexForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectTimelineController::index
 * @see app/Http/Controllers/ProjectTimelineController.php:23
 * @route '/admin/projects/{project}/timeline'
 */
        indexForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ProjectTimelineController::store
 * @see app/Http/Controllers/ProjectTimelineController.php:40
 * @route '/admin/projects/{project}/timeline'
 */
export const store = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/timeline',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectTimelineController::store
 * @see app/Http/Controllers/ProjectTimelineController.php:40
 * @route '/admin/projects/{project}/timeline'
 */
store.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return store.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectTimelineController::store
 * @see app/Http/Controllers/ProjectTimelineController.php:40
 * @route '/admin/projects/{project}/timeline'
 */
store.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectTimelineController::store
 * @see app/Http/Controllers/ProjectTimelineController.php:40
 * @route '/admin/projects/{project}/timeline'
 */
    const storeForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectTimelineController::store
 * @see app/Http/Controllers/ProjectTimelineController.php:40
 * @route '/admin/projects/{project}/timeline'
 */
        storeForm.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ProjectTimelineController::show
 * @see app/Http/Controllers/ProjectTimelineController.php:80
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
export const show = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/timeline/{timelineEvent}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectTimelineController::show
 * @see app/Http/Controllers/ProjectTimelineController.php:80
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
show.url = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    timelineEvent: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return show.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectTimelineController::show
 * @see app/Http/Controllers/ProjectTimelineController.php:80
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
show.get = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectTimelineController::show
 * @see app/Http/Controllers/ProjectTimelineController.php:80
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
show.head = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectTimelineController::show
 * @see app/Http/Controllers/ProjectTimelineController.php:80
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
    const showForm = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectTimelineController::show
 * @see app/Http/Controllers/ProjectTimelineController.php:80
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
        showForm.get = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectTimelineController::show
 * @see app/Http/Controllers/ProjectTimelineController.php:80
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
        showForm.head = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ProjectTimelineController::update
 * @see app/Http/Controllers/ProjectTimelineController.php:96
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
export const update = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/projects/{project}/timeline/{timelineEvent}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ProjectTimelineController::update
 * @see app/Http/Controllers/ProjectTimelineController.php:96
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
update.url = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    timelineEvent: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return update.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectTimelineController::update
 * @see app/Http/Controllers/ProjectTimelineController.php:96
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
update.patch = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProjectTimelineController::update
 * @see app/Http/Controllers/ProjectTimelineController.php:96
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
    const updateForm = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectTimelineController::update
 * @see app/Http/Controllers/ProjectTimelineController.php:96
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
        updateForm.patch = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ProjectTimelineController::destroy
 * @see app/Http/Controllers/ProjectTimelineController.php:131
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
export const destroy = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/projects/{project}/timeline/{timelineEvent}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProjectTimelineController::destroy
 * @see app/Http/Controllers/ProjectTimelineController.php:131
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
destroy.url = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    timelineEvent: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return destroy.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectTimelineController::destroy
 * @see app/Http/Controllers/ProjectTimelineController.php:131
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
destroy.delete = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ProjectTimelineController::destroy
 * @see app/Http/Controllers/ProjectTimelineController.php:131
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
    const destroyForm = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectTimelineController::destroy
 * @see app/Http/Controllers/ProjectTimelineController.php:131
 * @route '/admin/projects/{project}/timeline/{timelineEvent}'
 */
        destroyForm.delete = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\ProjectTimelineController::complete
 * @see app/Http/Controllers/ProjectTimelineController.php:151
 * @route '/admin/projects/{project}/timeline/{timelineEvent}/complete'
 */
export const complete = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/timeline/{timelineEvent}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectTimelineController::complete
 * @see app/Http/Controllers/ProjectTimelineController.php:151
 * @route '/admin/projects/{project}/timeline/{timelineEvent}/complete'
 */
complete.url = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    timelineEvent: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return complete.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectTimelineController::complete
 * @see app/Http/Controllers/ProjectTimelineController.php:151
 * @route '/admin/projects/{project}/timeline/{timelineEvent}/complete'
 */
complete.post = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectTimelineController::complete
 * @see app/Http/Controllers/ProjectTimelineController.php:151
 * @route '/admin/projects/{project}/timeline/{timelineEvent}/complete'
 */
    const completeForm = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectTimelineController::complete
 * @see app/Http/Controllers/ProjectTimelineController.php:151
 * @route '/admin/projects/{project}/timeline/{timelineEvent}/complete'
 */
        completeForm.post = (args: { project: number | { id: number }, timelineEvent: number | { id: number } } | [project: number | { id: number }, timelineEvent: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
/**
* @see \App\Http\Controllers\ProjectTimelineController::milestones
 * @see app/Http/Controllers/ProjectTimelineController.php:172
 * @route '/admin/projects/{project}/timeline/milestones'
 */
export const milestones = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: milestones.url(args, options),
    method: 'get',
})

milestones.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/timeline/milestones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectTimelineController::milestones
 * @see app/Http/Controllers/ProjectTimelineController.php:172
 * @route '/admin/projects/{project}/timeline/milestones'
 */
milestones.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return milestones.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectTimelineController::milestones
 * @see app/Http/Controllers/ProjectTimelineController.php:172
 * @route '/admin/projects/{project}/timeline/milestones'
 */
milestones.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: milestones.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectTimelineController::milestones
 * @see app/Http/Controllers/ProjectTimelineController.php:172
 * @route '/admin/projects/{project}/timeline/milestones'
 */
milestones.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: milestones.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectTimelineController::milestones
 * @see app/Http/Controllers/ProjectTimelineController.php:172
 * @route '/admin/projects/{project}/timeline/milestones'
 */
    const milestonesForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: milestones.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectTimelineController::milestones
 * @see app/Http/Controllers/ProjectTimelineController.php:172
 * @route '/admin/projects/{project}/timeline/milestones'
 */
        milestonesForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: milestones.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectTimelineController::milestones
 * @see app/Http/Controllers/ProjectTimelineController.php:172
 * @route '/admin/projects/{project}/timeline/milestones'
 */
        milestonesForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: milestones.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    milestones.form = milestonesForm
/**
* @see \App\Http\Controllers\ProjectTimelineController::byType
 * @see app/Http/Controllers/ProjectTimelineController.php:190
 * @route '/admin/projects/{project}/timeline/type/{type}'
 */
export const byType = (args: { project: number | { id: number }, type: string | number } | [project: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byType.url(args, options),
    method: 'get',
})

byType.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/timeline/type/{type}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectTimelineController::byType
 * @see app/Http/Controllers/ProjectTimelineController.php:190
 * @route '/admin/projects/{project}/timeline/type/{type}'
 */
byType.url = (args: { project: number | { id: number }, type: string | number } | [project: number | { id: number }, type: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    type: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                type: args.type,
                }

    return byType.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{type}', parsedArgs.type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectTimelineController::byType
 * @see app/Http/Controllers/ProjectTimelineController.php:190
 * @route '/admin/projects/{project}/timeline/type/{type}'
 */
byType.get = (args: { project: number | { id: number }, type: string | number } | [project: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byType.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectTimelineController::byType
 * @see app/Http/Controllers/ProjectTimelineController.php:190
 * @route '/admin/projects/{project}/timeline/type/{type}'
 */
byType.head = (args: { project: number | { id: number }, type: string | number } | [project: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: byType.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectTimelineController::byType
 * @see app/Http/Controllers/ProjectTimelineController.php:190
 * @route '/admin/projects/{project}/timeline/type/{type}'
 */
    const byTypeForm = (args: { project: number | { id: number }, type: string | number } | [project: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: byType.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectTimelineController::byType
 * @see app/Http/Controllers/ProjectTimelineController.php:190
 * @route '/admin/projects/{project}/timeline/type/{type}'
 */
        byTypeForm.get = (args: { project: number | { id: number }, type: string | number } | [project: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byType.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectTimelineController::byType
 * @see app/Http/Controllers/ProjectTimelineController.php:190
 * @route '/admin/projects/{project}/timeline/type/{type}'
 */
        byTypeForm.head = (args: { project: number | { id: number }, type: string | number } | [project: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byType.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    byType.form = byTypeForm
const ProjectTimelineController = { index, store, show, update, destroy, complete, milestones, byType }

export default ProjectTimelineController