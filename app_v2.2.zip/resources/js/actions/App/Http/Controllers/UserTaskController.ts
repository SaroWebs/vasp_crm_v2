import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\UserTaskController::getTasksWithTimeEntries
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/time-entries'
 */
export const getTasksWithTimeEntries = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTasksWithTimeEntries.url(options),
    method: 'get',
})

getTasksWithTimeEntries.definition = {
    methods: ["get","head"],
    url: '/my/tasks/time-entries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::getTasksWithTimeEntries
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/time-entries'
 */
getTasksWithTimeEntries.url = (options?: RouteQueryOptions) => {
    return getTasksWithTimeEntries.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::getTasksWithTimeEntries
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/time-entries'
 */
getTasksWithTimeEntries.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTasksWithTimeEntries.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::getTasksWithTimeEntries
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/time-entries'
 */
getTasksWithTimeEntries.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTasksWithTimeEntries.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::getTasksWithTimeEntries
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/time-entries'
 */
    const getTasksWithTimeEntriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTasksWithTimeEntries.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::getTasksWithTimeEntries
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/time-entries'
 */
        getTasksWithTimeEntriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTasksWithTimeEntries.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::getTasksWithTimeEntries
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/time-entries'
 */
        getTasksWithTimeEntriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTasksWithTimeEntries.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTasksWithTimeEntries.form = getTasksWithTimeEntriesForm
/**
* @see \App\Http\Controllers\UserTaskController::getBoardTasks
 * @see app/Http/Controllers/UserTaskController.php:66
 * @route '/data/my/board-tasks'
 */
export const getBoardTasks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBoardTasks.url(options),
    method: 'get',
})

getBoardTasks.definition = {
    methods: ["get","head"],
    url: '/data/my/board-tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::getBoardTasks
 * @see app/Http/Controllers/UserTaskController.php:66
 * @route '/data/my/board-tasks'
 */
getBoardTasks.url = (options?: RouteQueryOptions) => {
    return getBoardTasks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::getBoardTasks
 * @see app/Http/Controllers/UserTaskController.php:66
 * @route '/data/my/board-tasks'
 */
getBoardTasks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getBoardTasks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::getBoardTasks
 * @see app/Http/Controllers/UserTaskController.php:66
 * @route '/data/my/board-tasks'
 */
getBoardTasks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getBoardTasks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::getBoardTasks
 * @see app/Http/Controllers/UserTaskController.php:66
 * @route '/data/my/board-tasks'
 */
    const getBoardTasksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getBoardTasks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::getBoardTasks
 * @see app/Http/Controllers/UserTaskController.php:66
 * @route '/data/my/board-tasks'
 */
        getBoardTasksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getBoardTasks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::getBoardTasks
 * @see app/Http/Controllers/UserTaskController.php:66
 * @route '/data/my/board-tasks'
 */
        getBoardTasksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getBoardTasks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getBoardTasks.form = getBoardTasksForm
/**
* @see \App\Http\Controllers\UserTaskController::startTask
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/{task}/start'
 */
export const startTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startTask.url(args, options),
    method: 'post',
})

startTask.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserTaskController::startTask
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/{task}/start'
 */
startTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return startTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::startTask
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/{task}/start'
 */
startTask.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UserTaskController::startTask
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/{task}/start'
 */
    const startTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: startTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::startTask
 * @see app/Http/Controllers/UserTaskController.php:15
 * @route '/my/tasks/{task}/start'
 */
        startTaskForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: startTask.url(args, options),
            method: 'post',
        })
    
    startTask.form = startTaskForm
/**
* @see \App\Http\Controllers\UserTaskController::pauseTask
 * @see app/Http/Controllers/UserTaskController.php:86
 * @route '/my/tasks/{task}/pause'
 */
export const pauseTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pauseTask.url(args, options),
    method: 'post',
})

pauseTask.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/pause',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserTaskController::pauseTask
 * @see app/Http/Controllers/UserTaskController.php:86
 * @route '/my/tasks/{task}/pause'
 */
pauseTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return pauseTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::pauseTask
 * @see app/Http/Controllers/UserTaskController.php:86
 * @route '/my/tasks/{task}/pause'
 */
pauseTask.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pauseTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UserTaskController::pauseTask
 * @see app/Http/Controllers/UserTaskController.php:86
 * @route '/my/tasks/{task}/pause'
 */
    const pauseTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pauseTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::pauseTask
 * @see app/Http/Controllers/UserTaskController.php:86
 * @route '/my/tasks/{task}/pause'
 */
        pauseTaskForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pauseTask.url(args, options),
            method: 'post',
        })
    
    pauseTask.form = pauseTaskForm
/**
* @see \App\Http\Controllers\UserTaskController::resumeTask
 * @see app/Http/Controllers/UserTaskController.php:115
 * @route '/my/tasks/{task}/resume'
 */
export const resumeTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resumeTask.url(args, options),
    method: 'post',
})

resumeTask.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/resume',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserTaskController::resumeTask
 * @see app/Http/Controllers/UserTaskController.php:115
 * @route '/my/tasks/{task}/resume'
 */
resumeTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return resumeTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::resumeTask
 * @see app/Http/Controllers/UserTaskController.php:115
 * @route '/my/tasks/{task}/resume'
 */
resumeTask.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resumeTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UserTaskController::resumeTask
 * @see app/Http/Controllers/UserTaskController.php:115
 * @route '/my/tasks/{task}/resume'
 */
    const resumeTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resumeTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::resumeTask
 * @see app/Http/Controllers/UserTaskController.php:115
 * @route '/my/tasks/{task}/resume'
 */
        resumeTaskForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resumeTask.url(args, options),
            method: 'post',
        })
    
    resumeTask.form = resumeTaskForm
/**
* @see \App\Http\Controllers\UserTaskController::endTask
 * @see app/Http/Controllers/UserTaskController.php:166
 * @route '/my/tasks/{task}/end'
 */
export const endTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: endTask.url(args, options),
    method: 'post',
})

endTask.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/end',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserTaskController::endTask
 * @see app/Http/Controllers/UserTaskController.php:166
 * @route '/my/tasks/{task}/end'
 */
endTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return endTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::endTask
 * @see app/Http/Controllers/UserTaskController.php:166
 * @route '/my/tasks/{task}/end'
 */
endTask.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: endTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UserTaskController::endTask
 * @see app/Http/Controllers/UserTaskController.php:166
 * @route '/my/tasks/{task}/end'
 */
    const endTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: endTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::endTask
 * @see app/Http/Controllers/UserTaskController.php:166
 * @route '/my/tasks/{task}/end'
 */
        endTaskForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: endTask.url(args, options),
            method: 'post',
        })
    
    endTask.form = endTaskForm
/**
* @see \App\Http\Controllers\UserTaskController::calculateTimeSpent
 * @see app/Http/Controllers/UserTaskController.php:201
 * @route '/my/tasks/{task}/time-spent'
 */
export const calculateTimeSpent = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateTimeSpent.url(args, options),
    method: 'get',
})

calculateTimeSpent.definition = {
    methods: ["get","head"],
    url: '/my/tasks/{task}/time-spent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::calculateTimeSpent
 * @see app/Http/Controllers/UserTaskController.php:201
 * @route '/my/tasks/{task}/time-spent'
 */
calculateTimeSpent.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return calculateTimeSpent.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::calculateTimeSpent
 * @see app/Http/Controllers/UserTaskController.php:201
 * @route '/my/tasks/{task}/time-spent'
 */
calculateTimeSpent.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateTimeSpent.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::calculateTimeSpent
 * @see app/Http/Controllers/UserTaskController.php:201
 * @route '/my/tasks/{task}/time-spent'
 */
calculateTimeSpent.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calculateTimeSpent.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::calculateTimeSpent
 * @see app/Http/Controllers/UserTaskController.php:201
 * @route '/my/tasks/{task}/time-spent'
 */
    const calculateTimeSpentForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calculateTimeSpent.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::calculateTimeSpent
 * @see app/Http/Controllers/UserTaskController.php:201
 * @route '/my/tasks/{task}/time-spent'
 */
        calculateTimeSpentForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateTimeSpent.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::calculateTimeSpent
 * @see app/Http/Controllers/UserTaskController.php:201
 * @route '/my/tasks/{task}/time-spent'
 */
        calculateTimeSpentForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateTimeSpent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calculateTimeSpent.form = calculateTimeSpentForm
/**
* @see \App\Http\Controllers\UserTaskController::calculateRemainingTime
 * @see app/Http/Controllers/UserTaskController.php:242
 * @route '/my/tasks/{task}/remaining-time'
 */
export const calculateRemainingTime = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateRemainingTime.url(args, options),
    method: 'get',
})

calculateRemainingTime.definition = {
    methods: ["get","head"],
    url: '/my/tasks/{task}/remaining-time',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::calculateRemainingTime
 * @see app/Http/Controllers/UserTaskController.php:242
 * @route '/my/tasks/{task}/remaining-time'
 */
calculateRemainingTime.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return calculateRemainingTime.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::calculateRemainingTime
 * @see app/Http/Controllers/UserTaskController.php:242
 * @route '/my/tasks/{task}/remaining-time'
 */
calculateRemainingTime.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateRemainingTime.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::calculateRemainingTime
 * @see app/Http/Controllers/UserTaskController.php:242
 * @route '/my/tasks/{task}/remaining-time'
 */
calculateRemainingTime.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calculateRemainingTime.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::calculateRemainingTime
 * @see app/Http/Controllers/UserTaskController.php:242
 * @route '/my/tasks/{task}/remaining-time'
 */
    const calculateRemainingTimeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calculateRemainingTime.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::calculateRemainingTime
 * @see app/Http/Controllers/UserTaskController.php:242
 * @route '/my/tasks/{task}/remaining-time'
 */
        calculateRemainingTimeForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateRemainingTime.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::calculateRemainingTime
 * @see app/Http/Controllers/UserTaskController.php:242
 * @route '/my/tasks/{task}/remaining-time'
 */
        calculateRemainingTimeForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateRemainingTime.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calculateRemainingTime.form = calculateRemainingTimeForm
/**
* @see \App\Http\Controllers\UserTaskController::getTaskTimeEntriesForDate
 * @see app/Http/Controllers/UserTaskController.php:310
 * @route '/my/tasks/{task}/time-entries'
 */
export const getTaskTimeEntriesForDate = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTaskTimeEntriesForDate.url(args, options),
    method: 'get',
})

getTaskTimeEntriesForDate.definition = {
    methods: ["get","head"],
    url: '/my/tasks/{task}/time-entries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::getTaskTimeEntriesForDate
 * @see app/Http/Controllers/UserTaskController.php:310
 * @route '/my/tasks/{task}/time-entries'
 */
getTaskTimeEntriesForDate.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return getTaskTimeEntriesForDate.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::getTaskTimeEntriesForDate
 * @see app/Http/Controllers/UserTaskController.php:310
 * @route '/my/tasks/{task}/time-entries'
 */
getTaskTimeEntriesForDate.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTaskTimeEntriesForDate.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::getTaskTimeEntriesForDate
 * @see app/Http/Controllers/UserTaskController.php:310
 * @route '/my/tasks/{task}/time-entries'
 */
getTaskTimeEntriesForDate.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTaskTimeEntriesForDate.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::getTaskTimeEntriesForDate
 * @see app/Http/Controllers/UserTaskController.php:310
 * @route '/my/tasks/{task}/time-entries'
 */
    const getTaskTimeEntriesForDateForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTaskTimeEntriesForDate.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::getTaskTimeEntriesForDate
 * @see app/Http/Controllers/UserTaskController.php:310
 * @route '/my/tasks/{task}/time-entries'
 */
        getTaskTimeEntriesForDateForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTaskTimeEntriesForDate.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::getTaskTimeEntriesForDate
 * @see app/Http/Controllers/UserTaskController.php:310
 * @route '/my/tasks/{task}/time-entries'
 */
        getTaskTimeEntriesForDateForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTaskTimeEntriesForDate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTaskTimeEntriesForDate.form = getTaskTimeEntriesForDateForm
const UserTaskController = { getTasksWithTimeEntries, getBoardTasks, startTask, pauseTask, resumeTask, endTask, calculateTimeSpent, calculateRemainingTime, getTaskTimeEntriesForDate }

export default UserTaskController