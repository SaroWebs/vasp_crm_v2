import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminDashboardController::stats
 * @see app/Http/Controllers/AdminDashboardController.php:41
 * @route '/admin/api/dashboard/stats'
 */
export const stats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})

stats.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::stats
 * @see app/Http/Controllers/AdminDashboardController.php:41
 * @route '/admin/api/dashboard/stats'
 */
stats.url = (options?: RouteQueryOptions) => {
    return stats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::stats
 * @see app/Http/Controllers/AdminDashboardController.php:41
 * @route '/admin/api/dashboard/stats'
 */
stats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::stats
 * @see app/Http/Controllers/AdminDashboardController.php:41
 * @route '/admin/api/dashboard/stats'
 */
stats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::stats
 * @see app/Http/Controllers/AdminDashboardController.php:41
 * @route '/admin/api/dashboard/stats'
 */
    const statsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::stats
 * @see app/Http/Controllers/AdminDashboardController.php:41
 * @route '/admin/api/dashboard/stats'
 */
        statsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::stats
 * @see app/Http/Controllers/AdminDashboardController.php:41
 * @route '/admin/api/dashboard/stats'
 */
        statsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stats.form = statsForm
/**
* @see \App\Http\Controllers\AdminDashboardController::tickets
 * @see app/Http/Controllers/AdminDashboardController.php:56
 * @route '/admin/api/dashboard/tickets'
 */
export const tickets = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tickets.url(options),
    method: 'get',
})

tickets.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/tickets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::tickets
 * @see app/Http/Controllers/AdminDashboardController.php:56
 * @route '/admin/api/dashboard/tickets'
 */
tickets.url = (options?: RouteQueryOptions) => {
    return tickets.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::tickets
 * @see app/Http/Controllers/AdminDashboardController.php:56
 * @route '/admin/api/dashboard/tickets'
 */
tickets.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tickets.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::tickets
 * @see app/Http/Controllers/AdminDashboardController.php:56
 * @route '/admin/api/dashboard/tickets'
 */
tickets.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tickets.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::tickets
 * @see app/Http/Controllers/AdminDashboardController.php:56
 * @route '/admin/api/dashboard/tickets'
 */
    const ticketsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: tickets.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::tickets
 * @see app/Http/Controllers/AdminDashboardController.php:56
 * @route '/admin/api/dashboard/tickets'
 */
        ticketsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tickets.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::tickets
 * @see app/Http/Controllers/AdminDashboardController.php:56
 * @route '/admin/api/dashboard/tickets'
 */
        ticketsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tickets.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    tickets.form = ticketsForm
/**
* @see \App\Http\Controllers\AdminDashboardController::tasks
 * @see app/Http/Controllers/AdminDashboardController.php:61
 * @route '/admin/api/dashboard/tasks'
 */
export const tasks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tasks.url(options),
    method: 'get',
})

tasks.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::tasks
 * @see app/Http/Controllers/AdminDashboardController.php:61
 * @route '/admin/api/dashboard/tasks'
 */
tasks.url = (options?: RouteQueryOptions) => {
    return tasks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::tasks
 * @see app/Http/Controllers/AdminDashboardController.php:61
 * @route '/admin/api/dashboard/tasks'
 */
tasks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tasks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::tasks
 * @see app/Http/Controllers/AdminDashboardController.php:61
 * @route '/admin/api/dashboard/tasks'
 */
tasks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tasks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::tasks
 * @see app/Http/Controllers/AdminDashboardController.php:61
 * @route '/admin/api/dashboard/tasks'
 */
    const tasksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: tasks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::tasks
 * @see app/Http/Controllers/AdminDashboardController.php:61
 * @route '/admin/api/dashboard/tasks'
 */
        tasksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tasks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::tasks
 * @see app/Http/Controllers/AdminDashboardController.php:61
 * @route '/admin/api/dashboard/tasks'
 */
        tasksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tasks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    tasks.form = tasksForm
/**
* @see \App\Http\Controllers\AdminDashboardController::activities
 * @see app/Http/Controllers/AdminDashboardController.php:76
 * @route '/admin/api/dashboard/activities'
 */
export const activities = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: activities.url(options),
    method: 'get',
})

activities.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/activities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::activities
 * @see app/Http/Controllers/AdminDashboardController.php:76
 * @route '/admin/api/dashboard/activities'
 */
activities.url = (options?: RouteQueryOptions) => {
    return activities.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::activities
 * @see app/Http/Controllers/AdminDashboardController.php:76
 * @route '/admin/api/dashboard/activities'
 */
activities.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: activities.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::activities
 * @see app/Http/Controllers/AdminDashboardController.php:76
 * @route '/admin/api/dashboard/activities'
 */
activities.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: activities.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::activities
 * @see app/Http/Controllers/AdminDashboardController.php:76
 * @route '/admin/api/dashboard/activities'
 */
    const activitiesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: activities.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::activities
 * @see app/Http/Controllers/AdminDashboardController.php:76
 * @route '/admin/api/dashboard/activities'
 */
        activitiesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: activities.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::activities
 * @see app/Http/Controllers/AdminDashboardController.php:76
 * @route '/admin/api/dashboard/activities'
 */
        activitiesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: activities.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    activities.form = activitiesForm
/**
* @see \App\Http\Controllers\AdminDashboardController::chartData
 * @see app/Http/Controllers/AdminDashboardController.php:85
 * @route '/admin/api/dashboard/chart-data'
 */
export const chartData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: chartData.url(options),
    method: 'get',
})

chartData.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/chart-data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::chartData
 * @see app/Http/Controllers/AdminDashboardController.php:85
 * @route '/admin/api/dashboard/chart-data'
 */
chartData.url = (options?: RouteQueryOptions) => {
    return chartData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::chartData
 * @see app/Http/Controllers/AdminDashboardController.php:85
 * @route '/admin/api/dashboard/chart-data'
 */
chartData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: chartData.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::chartData
 * @see app/Http/Controllers/AdminDashboardController.php:85
 * @route '/admin/api/dashboard/chart-data'
 */
chartData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: chartData.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::chartData
 * @see app/Http/Controllers/AdminDashboardController.php:85
 * @route '/admin/api/dashboard/chart-data'
 */
    const chartDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: chartData.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::chartData
 * @see app/Http/Controllers/AdminDashboardController.php:85
 * @route '/admin/api/dashboard/chart-data'
 */
        chartDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: chartData.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::chartData
 * @see app/Http/Controllers/AdminDashboardController.php:85
 * @route '/admin/api/dashboard/chart-data'
 */
        chartDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: chartData.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    chartData.form = chartDataForm
/**
* @see \App\Http\Controllers\AdminDashboardController::recentReports
 * @see app/Http/Controllers/AdminDashboardController.php:96
 * @route '/admin/api/dashboard/recent-reports'
 */
export const recentReports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recentReports.url(options),
    method: 'get',
})

recentReports.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/recent-reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::recentReports
 * @see app/Http/Controllers/AdminDashboardController.php:96
 * @route '/admin/api/dashboard/recent-reports'
 */
recentReports.url = (options?: RouteQueryOptions) => {
    return recentReports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::recentReports
 * @see app/Http/Controllers/AdminDashboardController.php:96
 * @route '/admin/api/dashboard/recent-reports'
 */
recentReports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recentReports.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::recentReports
 * @see app/Http/Controllers/AdminDashboardController.php:96
 * @route '/admin/api/dashboard/recent-reports'
 */
recentReports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: recentReports.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::recentReports
 * @see app/Http/Controllers/AdminDashboardController.php:96
 * @route '/admin/api/dashboard/recent-reports'
 */
    const recentReportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: recentReports.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::recentReports
 * @see app/Http/Controllers/AdminDashboardController.php:96
 * @route '/admin/api/dashboard/recent-reports'
 */
        recentReportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: recentReports.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::recentReports
 * @see app/Http/Controllers/AdminDashboardController.php:96
 * @route '/admin/api/dashboard/recent-reports'
 */
        recentReportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: recentReports.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    recentReports.form = recentReportsForm
const dashboard = {
    stats: Object.assign(stats, stats),
tickets: Object.assign(tickets, tickets),
tasks: Object.assign(tasks, tasks),
activities: Object.assign(activities, activities),
chartData: Object.assign(chartData, chartData),
recentReports: Object.assign(recentReports, recentReports),
}

export default dashboard