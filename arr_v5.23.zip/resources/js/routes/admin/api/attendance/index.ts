import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AttendanceController::employee
 * @see app/Http/Controllers/AttendanceController.php:470
 * @route '/admin/employee-attendance/{employee}'
 */
export const employee = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employee.url(args, options),
    method: 'get',
})

employee.definition = {
    methods: ["get","head"],
    url: '/admin/employee-attendance/{employee}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::employee
 * @see app/Http/Controllers/AttendanceController.php:470
 * @route '/admin/employee-attendance/{employee}'
 */
employee.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return employee.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::employee
 * @see app/Http/Controllers/AttendanceController.php:470
 * @route '/admin/employee-attendance/{employee}'
 */
employee.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: employee.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::employee
 * @see app/Http/Controllers/AttendanceController.php:470
 * @route '/admin/employee-attendance/{employee}'
 */
employee.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: employee.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::employee
 * @see app/Http/Controllers/AttendanceController.php:470
 * @route '/admin/employee-attendance/{employee}'
 */
    const employeeForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: employee.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::employee
 * @see app/Http/Controllers/AttendanceController.php:470
 * @route '/admin/employee-attendance/{employee}'
 */
        employeeForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employee.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::employee
 * @see app/Http/Controllers/AttendanceController.php:470
 * @route '/admin/employee-attendance/{employee}'
 */
        employeeForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: employee.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    employee.form = employeeForm
/**
* @see \App\Http\Controllers\AttendanceController::summary
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/summary'
 */
export const summary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})

summary.definition = {
    methods: ["get","head"],
    url: '/admin/api/attendance/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::summary
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/summary'
 */
summary.url = (options?: RouteQueryOptions) => {
    return summary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::summary
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/summary'
 */
summary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::summary
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/summary'
 */
summary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: summary.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::summary
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/summary'
 */
    const summaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: summary.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::summary
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/summary'
 */
        summaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::summary
 * @see app/Http/Controllers/AttendanceController.php:510
 * @route '/admin/api/attendance/summary'
 */
        summaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    summary.form = summaryForm
/**
* @see \App\Http\Controllers\AttendanceController::byDate
 * @see app/Http/Controllers/AttendanceController.php:607
 * @route '/admin/api/attendance/date'
 */
export const byDate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byDate.url(options),
    method: 'get',
})

byDate.definition = {
    methods: ["get","head"],
    url: '/admin/api/attendance/date',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::byDate
 * @see app/Http/Controllers/AttendanceController.php:607
 * @route '/admin/api/attendance/date'
 */
byDate.url = (options?: RouteQueryOptions) => {
    return byDate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::byDate
 * @see app/Http/Controllers/AttendanceController.php:607
 * @route '/admin/api/attendance/date'
 */
byDate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byDate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::byDate
 * @see app/Http/Controllers/AttendanceController.php:607
 * @route '/admin/api/attendance/date'
 */
byDate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: byDate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::byDate
 * @see app/Http/Controllers/AttendanceController.php:607
 * @route '/admin/api/attendance/date'
 */
    const byDateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: byDate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::byDate
 * @see app/Http/Controllers/AttendanceController.php:607
 * @route '/admin/api/attendance/date'
 */
        byDateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byDate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::byDate
 * @see app/Http/Controllers/AttendanceController.php:607
 * @route '/admin/api/attendance/date'
 */
        byDateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byDate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    byDate.form = byDateForm
/**
* @see \App\Http\Controllers\AttendanceController::override
 * @see app/Http/Controllers/AttendanceController.php:556
 * @route '/admin/api/attendance/{employee}/override'
 */
export const override = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: override.url(args, options),
    method: 'post',
})

override.definition = {
    methods: ["post"],
    url: '/admin/api/attendance/{employee}/override',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AttendanceController::override
 * @see app/Http/Controllers/AttendanceController.php:556
 * @route '/admin/api/attendance/{employee}/override'
 */
override.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return override.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::override
 * @see app/Http/Controllers/AttendanceController.php:556
 * @route '/admin/api/attendance/{employee}/override'
 */
override.post = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: override.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AttendanceController::override
 * @see app/Http/Controllers/AttendanceController.php:556
 * @route '/admin/api/attendance/{employee}/override'
 */
    const overrideForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: override.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::override
 * @see app/Http/Controllers/AttendanceController.php:556
 * @route '/admin/api/attendance/{employee}/override'
 */
        overrideForm.post = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: override.url(args, options),
            method: 'post',
        })
    
    override.form = overrideForm
/**
* @see \App\Http\Controllers\AttendanceController::deleteMethod
 * @see app/Http/Controllers/AttendanceController.php:593
 * @route '/admin/api/attendance/{attendance}'
 */
export const deleteMethod = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(args, options),
    method: 'delete',
})

deleteMethod.definition = {
    methods: ["delete"],
    url: '/admin/api/attendance/{attendance}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AttendanceController::deleteMethod
 * @see app/Http/Controllers/AttendanceController.php:593
 * @route '/admin/api/attendance/{attendance}'
 */
deleteMethod.url = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attendance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { attendance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    attendance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attendance: typeof args.attendance === 'object'
                ? args.attendance.id
                : args.attendance,
                }

    return deleteMethod.definition.url
            .replace('{attendance}', parsedArgs.attendance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::deleteMethod
 * @see app/Http/Controllers/AttendanceController.php:593
 * @route '/admin/api/attendance/{attendance}'
 */
deleteMethod.delete = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AttendanceController::deleteMethod
 * @see app/Http/Controllers/AttendanceController.php:593
 * @route '/admin/api/attendance/{attendance}'
 */
    const deleteMethodForm = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteMethod.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::deleteMethod
 * @see app/Http/Controllers/AttendanceController.php:593
 * @route '/admin/api/attendance/{attendance}'
 */
        deleteMethodForm.delete = (args: { attendance: number | { id: number } } | [attendance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteMethod.form = deleteMethodForm
const attendance = {
    employee: Object.assign(employee, employee),
summary: Object.assign(summary, summary),
byDate: Object.assign(byDate, byDate),
override: Object.assign(override, override),
delete: Object.assign(deleteMethod, deleteMethod),
}

export default attendance