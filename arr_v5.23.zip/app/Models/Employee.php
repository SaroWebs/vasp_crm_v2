<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Employee extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'email',
        'code',
        'phone',
        'department_id',
        'user_id',
        'category_id',
    ];

    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function offices(): BelongsToMany
    {
        return $this->belongsToMany(Office::class, 'employee_offices')
            ->withPivot('is_active')
            ->withTimestamps();
    }

    public function activeOffice(): BelongsToMany
    {
        return $this->offices()->wherePivot('is_active', true);
    }

    public function attendances(): HasMany
    {
        return $this->hasMany(Attendance::class, 'employee_id', 'code');
    }

    public function shiftAssignments(): HasMany
    {
        return $this->hasMany(EmployeeShiftAssignment::class);
    }

    public function category()
    {
        $cat_id = $this->category_id;
        $cat = EmployeeCategory::find($cat_id);
        if (! $cat) {
            return null;
        }

        return $cat;
    }
}
