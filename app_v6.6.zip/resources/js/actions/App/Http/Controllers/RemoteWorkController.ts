import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RemoteWorkController::index
 * @see app/Http/Controllers/RemoteWorkController.php:18
 * @route '/api/remote-work-requests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/remote-work-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RemoteWorkController::index
 * @see app/Http/Controllers/RemoteWorkController.php:18
 * @route '/api/remote-work-requests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkController::index
 * @see app/Http/Controllers/RemoteWorkController.php:18
 * @route '/api/remote-work-requests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RemoteWorkController::index
 * @see app/Http/Controllers/RemoteWorkController.php:18
 * @route '/api/remote-work-requests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RemoteWorkController::index
 * @see app/Http/Controllers/RemoteWorkController.php:18
 * @route '/api/remote-work-requests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkController::index
 * @see app/Http/Controllers/RemoteWorkController.php:18
 * @route '/api/remote-work-requests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RemoteWorkController::index
 * @see app/Http/Controllers/RemoteWorkController.php:18
 * @route '/api/remote-work-requests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RemoteWorkController::store
 * @see app/Http/Controllers/RemoteWorkController.php:50
 * @route '/api/remote-work-requests'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/remote-work-requests',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RemoteWorkController::store
 * @see app/Http/Controllers/RemoteWorkController.php:50
 * @route '/api/remote-work-requests'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkController::store
 * @see app/Http/Controllers/RemoteWorkController.php:50
 * @route '/api/remote-work-requests'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RemoteWorkController::store
 * @see app/Http/Controllers/RemoteWorkController.php:50
 * @route '/api/remote-work-requests'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkController::store
 * @see app/Http/Controllers/RemoteWorkController.php:50
 * @route '/api/remote-work-requests'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RemoteWorkController::show
 * @see app/Http/Controllers/RemoteWorkController.php:83
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
export const show = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/remote-work-requests/{remoteWorkRequest}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RemoteWorkController::show
 * @see app/Http/Controllers/RemoteWorkController.php:83
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
show.url = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { remoteWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { remoteWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    remoteWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        remoteWorkRequest: typeof args.remoteWorkRequest === 'object'
                ? args.remoteWorkRequest.id
                : args.remoteWorkRequest,
                }

    return show.definition.url
            .replace('{remoteWorkRequest}', parsedArgs.remoteWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkController::show
 * @see app/Http/Controllers/RemoteWorkController.php:83
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
show.get = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RemoteWorkController::show
 * @see app/Http/Controllers/RemoteWorkController.php:83
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
show.head = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RemoteWorkController::show
 * @see app/Http/Controllers/RemoteWorkController.php:83
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
    const showForm = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkController::show
 * @see app/Http/Controllers/RemoteWorkController.php:83
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
        showForm.get = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RemoteWorkController::show
 * @see app/Http/Controllers/RemoteWorkController.php:83
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
        showForm.head = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\RemoteWorkController::update
 * @see app/Http/Controllers/RemoteWorkController.php:94
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
export const update = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/remote-work-requests/{remoteWorkRequest}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\RemoteWorkController::update
 * @see app/Http/Controllers/RemoteWorkController.php:94
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
update.url = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { remoteWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { remoteWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    remoteWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        remoteWorkRequest: typeof args.remoteWorkRequest === 'object'
                ? args.remoteWorkRequest.id
                : args.remoteWorkRequest,
                }

    return update.definition.url
            .replace('{remoteWorkRequest}', parsedArgs.remoteWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkController::update
 * @see app/Http/Controllers/RemoteWorkController.php:94
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
update.put = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\RemoteWorkController::update
 * @see app/Http/Controllers/RemoteWorkController.php:94
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
    const updateForm = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkController::update
 * @see app/Http/Controllers/RemoteWorkController.php:94
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
        updateForm.put = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\RemoteWorkController::destroy
 * @see app/Http/Controllers/RemoteWorkController.php:118
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
export const destroy = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/remote-work-requests/{remoteWorkRequest}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RemoteWorkController::destroy
 * @see app/Http/Controllers/RemoteWorkController.php:118
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
destroy.url = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { remoteWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { remoteWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    remoteWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        remoteWorkRequest: typeof args.remoteWorkRequest === 'object'
                ? args.remoteWorkRequest.id
                : args.remoteWorkRequest,
                }

    return destroy.definition.url
            .replace('{remoteWorkRequest}', parsedArgs.remoteWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkController::destroy
 * @see app/Http/Controllers/RemoteWorkController.php:118
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
destroy.delete = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\RemoteWorkController::destroy
 * @see app/Http/Controllers/RemoteWorkController.php:118
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
    const destroyForm = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkController::destroy
 * @see app/Http/Controllers/RemoteWorkController.php:118
 * @route '/api/remote-work-requests/{remoteWorkRequest}'
 */
        destroyForm.delete = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\RemoteWorkController::approve
 * @see app/Http/Controllers/RemoteWorkController.php:135
 * @route '/api/remote-work-requests/{remoteWorkRequest}/approve'
 */
export const approve = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/remote-work-requests/{remoteWorkRequest}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RemoteWorkController::approve
 * @see app/Http/Controllers/RemoteWorkController.php:135
 * @route '/api/remote-work-requests/{remoteWorkRequest}/approve'
 */
approve.url = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { remoteWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { remoteWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    remoteWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        remoteWorkRequest: typeof args.remoteWorkRequest === 'object'
                ? args.remoteWorkRequest.id
                : args.remoteWorkRequest,
                }

    return approve.definition.url
            .replace('{remoteWorkRequest}', parsedArgs.remoteWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkController::approve
 * @see app/Http/Controllers/RemoteWorkController.php:135
 * @route '/api/remote-work-requests/{remoteWorkRequest}/approve'
 */
approve.post = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RemoteWorkController::approve
 * @see app/Http/Controllers/RemoteWorkController.php:135
 * @route '/api/remote-work-requests/{remoteWorkRequest}/approve'
 */
    const approveForm = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkController::approve
 * @see app/Http/Controllers/RemoteWorkController.php:135
 * @route '/api/remote-work-requests/{remoteWorkRequest}/approve'
 */
        approveForm.post = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\RemoteWorkController::reject
 * @see app/Http/Controllers/RemoteWorkController.php:175
 * @route '/api/remote-work-requests/{remoteWorkRequest}/reject'
 */
export const reject = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/api/remote-work-requests/{remoteWorkRequest}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RemoteWorkController::reject
 * @see app/Http/Controllers/RemoteWorkController.php:175
 * @route '/api/remote-work-requests/{remoteWorkRequest}/reject'
 */
reject.url = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { remoteWorkRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { remoteWorkRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    remoteWorkRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        remoteWorkRequest: typeof args.remoteWorkRequest === 'object'
                ? args.remoteWorkRequest.id
                : args.remoteWorkRequest,
                }

    return reject.definition.url
            .replace('{remoteWorkRequest}', parsedArgs.remoteWorkRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkController::reject
 * @see app/Http/Controllers/RemoteWorkController.php:175
 * @route '/api/remote-work-requests/{remoteWorkRequest}/reject'
 */
reject.post = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RemoteWorkController::reject
 * @see app/Http/Controllers/RemoteWorkController.php:175
 * @route '/api/remote-work-requests/{remoteWorkRequest}/reject'
 */
    const rejectForm = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkController::reject
 * @see app/Http/Controllers/RemoteWorkController.php:175
 * @route '/api/remote-work-requests/{remoteWorkRequest}/reject'
 */
        rejectForm.post = (args: { remoteWorkRequest: number | { id: number } } | [remoteWorkRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\RemoteWorkController::getEmployeeRemoteWorkRequests
 * @see app/Http/Controllers/RemoteWorkController.php:206
 * @route '/api/employees/{employee}/remote-work-requests'
 */
export const getEmployeeRemoteWorkRequests = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeRemoteWorkRequests.url(args, options),
    method: 'get',
})

getEmployeeRemoteWorkRequests.definition = {
    methods: ["get","head"],
    url: '/api/employees/{employee}/remote-work-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RemoteWorkController::getEmployeeRemoteWorkRequests
 * @see app/Http/Controllers/RemoteWorkController.php:206
 * @route '/api/employees/{employee}/remote-work-requests'
 */
getEmployeeRemoteWorkRequests.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return getEmployeeRemoteWorkRequests.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RemoteWorkController::getEmployeeRemoteWorkRequests
 * @see app/Http/Controllers/RemoteWorkController.php:206
 * @route '/api/employees/{employee}/remote-work-requests'
 */
getEmployeeRemoteWorkRequests.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeRemoteWorkRequests.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RemoteWorkController::getEmployeeRemoteWorkRequests
 * @see app/Http/Controllers/RemoteWorkController.php:206
 * @route '/api/employees/{employee}/remote-work-requests'
 */
getEmployeeRemoteWorkRequests.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeRemoteWorkRequests.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RemoteWorkController::getEmployeeRemoteWorkRequests
 * @see app/Http/Controllers/RemoteWorkController.php:206
 * @route '/api/employees/{employee}/remote-work-requests'
 */
    const getEmployeeRemoteWorkRequestsForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeRemoteWorkRequests.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RemoteWorkController::getEmployeeRemoteWorkRequests
 * @see app/Http/Controllers/RemoteWorkController.php:206
 * @route '/api/employees/{employee}/remote-work-requests'
 */
        getEmployeeRemoteWorkRequestsForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeRemoteWorkRequests.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RemoteWorkController::getEmployeeRemoteWorkRequests
 * @see app/Http/Controllers/RemoteWorkController.php:206
 * @route '/api/employees/{employee}/remote-work-requests'
 */
        getEmployeeRemoteWorkRequestsForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeRemoteWorkRequests.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeRemoteWorkRequests.form = getEmployeeRemoteWorkRequestsForm
const RemoteWorkController = { index, store, show, update, destroy, approve, reject, getEmployeeRemoteWorkRequests }

export default RemoteWorkController