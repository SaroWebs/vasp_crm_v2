import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminTicketController::getNextTicketNumber
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
export const getNextTicketNumber = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getNextTicketNumber.url(args, options),
    method: 'get',
})

getNextTicketNumber.definition = {
    methods: ["get","head"],
    url: '/admin/client/{client}/next-ticket-number',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::getNextTicketNumber
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
getNextTicketNumber.url = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: args.client,
                }

    return getNextTicketNumber.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::getNextTicketNumber
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
getNextTicketNumber.get = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getNextTicketNumber.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::getNextTicketNumber
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
getNextTicketNumber.head = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getNextTicketNumber.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::getNextTicketNumber
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
    const getNextTicketNumberForm = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getNextTicketNumber.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::getNextTicketNumber
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
        getNextTicketNumberForm.get = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getNextTicketNumber.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::getNextTicketNumber
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
        getNextTicketNumberForm.head = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getNextTicketNumber.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getNextTicketNumber.form = getNextTicketNumberForm
/**
* @see \App\Http\Controllers\AdminTicketController::index
 * @see app/Http/Controllers/AdminTicketController.php:116
 * @route '/admin/tickets'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/tickets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::index
 * @see app/Http/Controllers/AdminTicketController.php:116
 * @route '/admin/tickets'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::index
 * @see app/Http/Controllers/AdminTicketController.php:116
 * @route '/admin/tickets'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::index
 * @see app/Http/Controllers/AdminTicketController.php:116
 * @route '/admin/tickets'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::index
 * @see app/Http/Controllers/AdminTicketController.php:116
 * @route '/admin/tickets'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::index
 * @see app/Http/Controllers/AdminTicketController.php:116
 * @route '/admin/tickets'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::index
 * @see app/Http/Controllers/AdminTicketController.php:116
 * @route '/admin/tickets'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminTicketController::getTicketData
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
export const getTicketData = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTicketData.url(args, options),
    method: 'get',
})

getTicketData.definition = {
    methods: ["get","head"],
    url: '/admin/data/tickets/{ticket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::getTicketData
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
getTicketData.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return getTicketData.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::getTicketData
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
getTicketData.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTicketData.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::getTicketData
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
getTicketData.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTicketData.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::getTicketData
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
    const getTicketDataForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTicketData.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::getTicketData
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
        getTicketDataForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTicketData.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::getTicketData
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
        getTicketDataForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTicketData.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTicketData.form = getTicketDataForm
/**
* @see \App\Http\Controllers\AdminTicketController::store
 * @see app/Http/Controllers/AdminTicketController.php:275
 * @route '/admin/tickets'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/tickets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTicketController::store
 * @see app/Http/Controllers/AdminTicketController.php:275
 * @route '/admin/tickets'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::store
 * @see app/Http/Controllers/AdminTicketController.php:275
 * @route '/admin/tickets'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::store
 * @see app/Http/Controllers/AdminTicketController.php:275
 * @route '/admin/tickets'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::store
 * @see app/Http/Controllers/AdminTicketController.php:275
 * @route '/admin/tickets'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
export const show = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
show.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return show.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
show.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
show.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
    const showForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
        showForm.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
        showForm.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
export const edit = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
edit.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return edit.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
edit.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
edit.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
    const editForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
        editForm.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
        editForm.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AdminTicketController::update
 * @see app/Http/Controllers/AdminTicketController.php:352
 * @route '/admin/tickets/{ticket}'
 */
export const update = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/tickets/{ticket}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AdminTicketController::update
 * @see app/Http/Controllers/AdminTicketController.php:352
 * @route '/admin/tickets/{ticket}'
 */
update.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return update.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::update
 * @see app/Http/Controllers/AdminTicketController.php:352
 * @route '/admin/tickets/{ticket}'
 */
update.patch = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::update
 * @see app/Http/Controllers/AdminTicketController.php:352
 * @route '/admin/tickets/{ticket}'
 */
    const updateForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::update
 * @see app/Http/Controllers/AdminTicketController.php:352
 * @route '/admin/tickets/{ticket}'
 */
        updateForm.patch = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AdminTicketController::destroy
 * @see app/Http/Controllers/AdminTicketController.php:649
 * @route '/admin/tickets/{ticket}'
 */
export const destroy = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/tickets/{ticket}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminTicketController::destroy
 * @see app/Http/Controllers/AdminTicketController.php:649
 * @route '/admin/tickets/{ticket}'
 */
destroy.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return destroy.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::destroy
 * @see app/Http/Controllers/AdminTicketController.php:649
 * @route '/admin/tickets/{ticket}'
 */
destroy.delete = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::destroy
 * @see app/Http/Controllers/AdminTicketController.php:649
 * @route '/admin/tickets/{ticket}'
 */
    const destroyForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::destroy
 * @see app/Http/Controllers/AdminTicketController.php:649
 * @route '/admin/tickets/{ticket}'
 */
        destroyForm.delete = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\AdminTicketController::restore
 * @see app/Http/Controllers/AdminTicketController.php:687
 * @route '/admin/tickets/{ticket}/restore'
 */
export const restore = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/tickets/{ticket}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTicketController::restore
 * @see app/Http/Controllers/AdminTicketController.php:687
 * @route '/admin/tickets/{ticket}/restore'
 */
restore.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return restore.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::restore
 * @see app/Http/Controllers/AdminTicketController.php:687
 * @route '/admin/tickets/{ticket}/restore'
 */
restore.post = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::restore
 * @see app/Http/Controllers/AdminTicketController.php:687
 * @route '/admin/tickets/{ticket}/restore'
 */
    const restoreForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::restore
 * @see app/Http/Controllers/AdminTicketController.php:687
 * @route '/admin/tickets/{ticket}/restore'
 */
        restoreForm.post = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\AdminTicketController::assignTicket
 * @see app/Http/Controllers/AdminTicketController.php:1028
 * @route '/admin/ticket/{ticket}/assign'
 */
export const assignTicket = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignTicket.url(args, options),
    method: 'post',
})

assignTicket.definition = {
    methods: ["post"],
    url: '/admin/ticket/{ticket}/assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTicketController::assignTicket
 * @see app/Http/Controllers/AdminTicketController.php:1028
 * @route '/admin/ticket/{ticket}/assign'
 */
assignTicket.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return assignTicket.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::assignTicket
 * @see app/Http/Controllers/AdminTicketController.php:1028
 * @route '/admin/ticket/{ticket}/assign'
 */
assignTicket.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignTicket.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::assignTicket
 * @see app/Http/Controllers/AdminTicketController.php:1028
 * @route '/admin/ticket/{ticket}/assign'
 */
    const assignTicketForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assignTicket.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::assignTicket
 * @see app/Http/Controllers/AdminTicketController.php:1028
 * @route '/admin/ticket/{ticket}/assign'
 */
        assignTicketForm.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assignTicket.url(args, options),
            method: 'post',
        })
    
    assignTicket.form = assignTicketForm
/**
* @see \App\Http\Controllers\AdminTicketController::getTicketHistory
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
export const getTicketHistory = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTicketHistory.url(args, options),
    method: 'get',
})

getTicketHistory.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::getTicketHistory
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
getTicketHistory.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return getTicketHistory.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::getTicketHistory
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
getTicketHistory.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTicketHistory.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::getTicketHistory
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
getTicketHistory.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTicketHistory.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::getTicketHistory
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
    const getTicketHistoryForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTicketHistory.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::getTicketHistory
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
        getTicketHistoryForm.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTicketHistory.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::getTicketHistory
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
        getTicketHistoryForm.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTicketHistory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTicketHistory.form = getTicketHistoryForm
/**
* @see \App\Http\Controllers\AdminTicketController::approve
 * @see app/Http/Controllers/AdminTicketController.php:731
 * @route '/admin/tickets/{ticket}/approve'
 */
export const approve = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/tickets/{ticket}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTicketController::approve
 * @see app/Http/Controllers/AdminTicketController.php:731
 * @route '/admin/tickets/{ticket}/approve'
 */
approve.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return approve.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::approve
 * @see app/Http/Controllers/AdminTicketController.php:731
 * @route '/admin/tickets/{ticket}/approve'
 */
approve.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::approve
 * @see app/Http/Controllers/AdminTicketController.php:731
 * @route '/admin/tickets/{ticket}/approve'
 */
    const approveForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::approve
 * @see app/Http/Controllers/AdminTicketController.php:731
 * @route '/admin/tickets/{ticket}/approve'
 */
        approveForm.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\AdminTicketController::reject
 * @see app/Http/Controllers/AdminTicketController.php:786
 * @route '/admin/tickets/{ticket}/reject'
 */
export const reject = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/admin/tickets/{ticket}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTicketController::reject
 * @see app/Http/Controllers/AdminTicketController.php:786
 * @route '/admin/tickets/{ticket}/reject'
 */
reject.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return reject.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::reject
 * @see app/Http/Controllers/AdminTicketController.php:786
 * @route '/admin/tickets/{ticket}/reject'
 */
reject.post = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::reject
 * @see app/Http/Controllers/AdminTicketController.php:786
 * @route '/admin/tickets/{ticket}/reject'
 */
    const rejectForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::reject
 * @see app/Http/Controllers/AdminTicketController.php:786
 * @route '/admin/tickets/{ticket}/reject'
 */
        rejectForm.post = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\AdminTicketController::getTicketsForApproval
 * @see app/Http/Controllers/AdminTicketController.php:702
 * @route '/admin/tickets/approval-queue'
 */
export const getTicketsForApproval = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTicketsForApproval.url(options),
    method: 'get',
})

getTicketsForApproval.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/approval-queue',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::getTicketsForApproval
 * @see app/Http/Controllers/AdminTicketController.php:702
 * @route '/admin/tickets/approval-queue'
 */
getTicketsForApproval.url = (options?: RouteQueryOptions) => {
    return getTicketsForApproval.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::getTicketsForApproval
 * @see app/Http/Controllers/AdminTicketController.php:702
 * @route '/admin/tickets/approval-queue'
 */
getTicketsForApproval.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTicketsForApproval.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::getTicketsForApproval
 * @see app/Http/Controllers/AdminTicketController.php:702
 * @route '/admin/tickets/approval-queue'
 */
getTicketsForApproval.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTicketsForApproval.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::getTicketsForApproval
 * @see app/Http/Controllers/AdminTicketController.php:702
 * @route '/admin/tickets/approval-queue'
 */
    const getTicketsForApprovalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTicketsForApproval.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::getTicketsForApproval
 * @see app/Http/Controllers/AdminTicketController.php:702
 * @route '/admin/tickets/approval-queue'
 */
        getTicketsForApprovalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTicketsForApproval.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::getTicketsForApproval
 * @see app/Http/Controllers/AdminTicketController.php:702
 * @route '/admin/tickets/approval-queue'
 */
        getTicketsForApprovalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTicketsForApproval.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTicketsForApproval.form = getTicketsForApprovalForm
/**
* @see \App\Http\Controllers\AdminTicketController::updateStatus
 * @see app/Http/Controllers/AdminTicketController.php:832
 * @route '/admin/tickets/{ticket}/status'
 */
export const updateStatus = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/admin/tickets/{ticket}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AdminTicketController::updateStatus
 * @see app/Http/Controllers/AdminTicketController.php:832
 * @route '/admin/tickets/{ticket}/status'
 */
updateStatus.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return updateStatus.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::updateStatus
 * @see app/Http/Controllers/AdminTicketController.php:832
 * @route '/admin/tickets/{ticket}/status'
 */
updateStatus.patch = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::updateStatus
 * @see app/Http/Controllers/AdminTicketController.php:832
 * @route '/admin/tickets/{ticket}/status'
 */
    const updateStatusForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::updateStatus
 * @see app/Http/Controllers/AdminTicketController.php:832
 * @route '/admin/tickets/{ticket}/status'
 */
        updateStatusForm.patch = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\AdminTicketController::checkTaskStatus
 * @see app/Http/Controllers/AdminTicketController.php:876
 * @route '/admin/tickets/{ticket}/check-tasks'
 */
export const checkTaskStatus = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkTaskStatus.url(args, options),
    method: 'get',
})

checkTaskStatus.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/check-tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::checkTaskStatus
 * @see app/Http/Controllers/AdminTicketController.php:876
 * @route '/admin/tickets/{ticket}/check-tasks'
 */
checkTaskStatus.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return checkTaskStatus.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::checkTaskStatus
 * @see app/Http/Controllers/AdminTicketController.php:876
 * @route '/admin/tickets/{ticket}/check-tasks'
 */
checkTaskStatus.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkTaskStatus.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::checkTaskStatus
 * @see app/Http/Controllers/AdminTicketController.php:876
 * @route '/admin/tickets/{ticket}/check-tasks'
 */
checkTaskStatus.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: checkTaskStatus.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::checkTaskStatus
 * @see app/Http/Controllers/AdminTicketController.php:876
 * @route '/admin/tickets/{ticket}/check-tasks'
 */
    const checkTaskStatusForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: checkTaskStatus.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::checkTaskStatus
 * @see app/Http/Controllers/AdminTicketController.php:876
 * @route '/admin/tickets/{ticket}/check-tasks'
 */
        checkTaskStatusForm.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkTaskStatus.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::checkTaskStatus
 * @see app/Http/Controllers/AdminTicketController.php:876
 * @route '/admin/tickets/{ticket}/check-tasks'
 */
        checkTaskStatusForm.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkTaskStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    checkTaskStatus.form = checkTaskStatusForm
const AdminTicketController = { getNextTicketNumber, index, getTicketData, store, show, edit, update, destroy, restore, assignTicket, getTicketHistory, approve, reject, getTicketsForApproval, updateStatus, checkTaskStatus }

export default AdminTicketController