import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
export const index = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/comments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
index.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return index.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
index.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
index.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
    const indexForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
        indexForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketCommentController::index
 * @see app/Http/Controllers/TicketCommentController.php:20
 * @route '/admin/tickets/{ticket}/comments'
 */
        indexForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
export const store = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/tickets/{ticket}/comments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
store.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return store.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
store.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
    const storeForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::store
 * @see app/Http/Controllers/TicketCommentController.php:72
 * @route '/admin/tickets/{ticket}/comments'
 */
        storeForm.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
export const update = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/tickets/{ticket}/comments/{comment}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
update.url = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return update.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
update.patch = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
    const updateForm = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::update
 * @see app/Http/Controllers/TicketCommentController.php:166
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
        updateForm.patch = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
export const destroy = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/tickets/{ticket}/comments/{comment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
destroy.url = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return destroy.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
destroy.delete = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
    const destroyForm = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::destroy
 * @see app/Http/Controllers/TicketCommentController.php:218
 * @route '/admin/tickets/{ticket}/comments/{comment}'
 */
        destroyForm.delete = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\TicketCommentController::deleted
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
export const deleted = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: deleted.url(args, options),
    method: 'get',
})

deleted.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/comments/deleted',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketCommentController::deleted
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
deleted.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return deleted.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::deleted
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
deleted.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: deleted.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketCommentController::deleted
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
deleted.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: deleted.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::deleted
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
    const deletedForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: deleted.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::deleted
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
        deletedForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: deleted.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketCommentController::deleted
 * @see app/Http/Controllers/TicketCommentController.php:268
 * @route '/admin/tickets/{ticket}/comments/deleted'
 */
        deletedForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: deleted.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    deleted.form = deletedForm
/**
* @see \App\Http\Controllers\TicketCommentController::restore
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
export const restore = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

restore.definition = {
    methods: ["patch"],
    url: '/admin/tickets/{ticket}/comments/{comment}/restore',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TicketCommentController::restore
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
restore.url = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return restore.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::restore
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
restore.patch = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::restore
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
    const restoreForm = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::restore
 * @see app/Http/Controllers/TicketCommentController.php:311
 * @route '/admin/tickets/{ticket}/comments/{comment}/restore'
 */
        restoreForm.patch = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\TicketCommentController::forceDelete
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
export const forceDelete = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: forceDelete.url(args, options),
    method: 'delete',
})

forceDelete.definition = {
    methods: ["delete"],
    url: '/admin/tickets/{ticket}/comments/{comment}/force-delete',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TicketCommentController::forceDelete
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
forceDelete.url = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return forceDelete.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketCommentController::forceDelete
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
forceDelete.delete = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: forceDelete.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TicketCommentController::forceDelete
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
    const forceDeleteForm = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceDelete.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketCommentController::forceDelete
 * @see app/Http/Controllers/TicketCommentController.php:365
 * @route '/admin/tickets/{ticket}/comments/{comment}/force-delete'
 */
        forceDeleteForm.delete = (args: { ticket: number | { id: number }, comment: number | { id: number } } | [ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceDelete.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    forceDelete.form = forceDeleteForm
const comments = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
deleted: Object.assign(deleted, deleted),
restore: Object.assign(restore, restore),
forceDelete: Object.assign(forceDelete, forceDelete),
}

export default comments