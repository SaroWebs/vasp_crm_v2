import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import comments from './comments'
/**
* @see \App\Http\Controllers\AdminTicketController::data
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
export const data = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(args, options),
    method: 'get',
})

data.definition = {
    methods: ["get","head"],
    url: '/admin/data/tickets/{ticket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::data
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
data.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return data.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::data
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
data.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::data
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
data.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::data
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
    const dataForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: data.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::data
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
        dataForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::data
 * @see app/Http/Controllers/AdminTicketController.php:234
 * @route '/admin/data/tickets/{ticket}'
 */
        dataForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    data.form = dataForm
/**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
export const show = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
show.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return show.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
show.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
show.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
    const showForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
        showForm.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::show
 * @see app/Http/Controllers/AdminTicketController.php:209
 * @route '/admin/tickets/{ticket}'
 */
        showForm.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
export const edit = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
edit.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return edit.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
edit.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
edit.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
    const editForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
        editForm.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::edit
 * @see app/Http/Controllers/AdminTicketController.php:329
 * @route '/admin/tickets/{ticket}/edit'
 */
        editForm.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AdminTicketController::history
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
export const history = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::history
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
history.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return history.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::history
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
history.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::history
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
history.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::history
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
    const historyForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: history.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::history
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
        historyForm.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::history
 * @see app/Http/Controllers/AdminTicketController.php:1265
 * @route '/admin/tickets/{ticket}/history'
 */
        historyForm.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    history.form = historyForm
const tickets = {
    data: Object.assign(data, data),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
comments: Object.assign(comments, comments),
history: Object.assign(history, history),
}

export default tickets