import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminTicketController::number
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
export const number = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: number.url(args, options),
    method: 'get',
})

number.definition = {
    methods: ["get","head"],
    url: '/admin/client/{client}/next-ticket-number',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminTicketController::number
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
number.url = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: args.client,
                }

    return number.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTicketController::number
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
number.get = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: number.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminTicketController::number
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
number.head = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: number.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminTicketController::number
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
    const numberForm = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: number.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminTicketController::number
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
        numberForm.get = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: number.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminTicketController::number
 * @see app/Http/Controllers/AdminTicketController.php:1290
 * @route '/admin/client/{client}/next-ticket-number'
 */
        numberForm.head = (args: { client: string | number } | [client: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: number.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    number.form = numberForm
const tickets = {
    number: Object.assign(number, number),
}

export default tickets