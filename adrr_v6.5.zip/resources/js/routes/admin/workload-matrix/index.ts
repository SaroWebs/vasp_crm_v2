import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/workload-matrix',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const workloadMatrix = {
    index: Object.assign(index, index),
}

export default workloadMatrix