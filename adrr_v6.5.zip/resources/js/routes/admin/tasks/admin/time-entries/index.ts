import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
import manual from './manual'
import batch from './batch'
/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
export const destroy = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/tasks/{task}/time-entries/{timeEntry}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
destroy.url = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                    timeEntry: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                                timeEntry: typeof args.timeEntry === 'object'
                ? args.timeEntry.id
                : args.timeEntry,
                }

    return destroy.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace('{timeEntry}', parsedArgs.timeEntry.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
destroy.delete = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
    const destroyForm = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
        destroyForm.delete = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const timeEntries = {
    manual: Object.assign(manual, manual),
batch: Object.assign(batch, batch),
destroy: Object.assign(destroy, destroy),
}

export default timeEntries