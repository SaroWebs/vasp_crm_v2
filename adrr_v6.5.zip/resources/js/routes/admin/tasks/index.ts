import admin from './admin'
const tasks = {
    admin: Object.assign(admin, admin),
}

export default tasks