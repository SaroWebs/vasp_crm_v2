import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import self from './self'
import myA9b1d5 from './my'
import forwarding from './forwarding'
/**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:1313
 * @route '/my/tasks'
 */
export const my = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})

my.definition = {
    methods: ["get","head"],
    url: '/my/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:1313
 * @route '/my/tasks'
 */
my.url = (options?: RouteQueryOptions) => {
    return my.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:1313
 * @route '/my/tasks'
 */
my.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:1313
 * @route '/my/tasks'
 */
my.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: my.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:1313
 * @route '/my/tasks'
 */
    const myForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: my.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:1313
 * @route '/my/tasks'
 */
        myForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:1313
 * @route '/my/tasks'
 */
        myForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    my.form = myForm
/**
* @see \App\Http\Controllers\TaskController::start
 * @see app/Http/Controllers/TaskController.php:703
 * @route '/tasks/{task}/start'
 */
export const start = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/tasks/{task}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::start
 * @see app/Http/Controllers/TaskController.php:703
 * @route '/tasks/{task}/start'
 */
start.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return start.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::start
 * @see app/Http/Controllers/TaskController.php:703
 * @route '/tasks/{task}/start'
 */
start.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::start
 * @see app/Http/Controllers/TaskController.php:703
 * @route '/tasks/{task}/start'
 */
    const startForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::start
 * @see app/Http/Controllers/TaskController.php:703
 * @route '/tasks/{task}/start'
 */
        startForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(args, options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\TaskController::pause
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
export const pause = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

pause.definition = {
    methods: ["post"],
    url: '/tasks/{task}/pause',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::pause
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
pause.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return pause.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::pause
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
pause.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::pause
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
    const pauseForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pause.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::pause
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
        pauseForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pause.url(args, options),
            method: 'post',
        })
    
    pause.form = pauseForm
/**
* @see \App\Http\Controllers\TaskController::resume
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
export const resume = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

resume.definition = {
    methods: ["post"],
    url: '/tasks/{task}/resume',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::resume
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
resume.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return resume.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::resume
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
resume.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::resume
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
    const resumeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resume.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::resume
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
        resumeForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resume.url(args, options),
            method: 'post',
        })
    
    resume.form = resumeForm
/**
* @see \App\Http\Controllers\TaskController::end
 * @see app/Http/Controllers/TaskController.php:924
 * @route '/tasks/{task}/end'
 */
export const end = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: end.url(args, options),
    method: 'post',
})

end.definition = {
    methods: ["post"],
    url: '/tasks/{task}/end',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::end
 * @see app/Http/Controllers/TaskController.php:924
 * @route '/tasks/{task}/end'
 */
end.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return end.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::end
 * @see app/Http/Controllers/TaskController.php:924
 * @route '/tasks/{task}/end'
 */
end.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: end.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::end
 * @see app/Http/Controllers/TaskController.php:924
 * @route '/tasks/{task}/end'
 */
    const endForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: end.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::end
 * @see app/Http/Controllers/TaskController.php:924
 * @route '/tasks/{task}/end'
 */
        endForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: end.url(args, options),
            method: 'post',
        })
    
    end.form = endForm
/**
* @see \App\Http\Controllers\TaskController::timeSpent
 * @see app/Http/Controllers/TaskController.php:995
 * @route '/tasks/{task}/time-spent'
 */
export const timeSpent = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeSpent.url(args, options),
    method: 'get',
})

timeSpent.definition = {
    methods: ["get","head"],
    url: '/tasks/{task}/time-spent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::timeSpent
 * @see app/Http/Controllers/TaskController.php:995
 * @route '/tasks/{task}/time-spent'
 */
timeSpent.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return timeSpent.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::timeSpent
 * @see app/Http/Controllers/TaskController.php:995
 * @route '/tasks/{task}/time-spent'
 */
timeSpent.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeSpent.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::timeSpent
 * @see app/Http/Controllers/TaskController.php:995
 * @route '/tasks/{task}/time-spent'
 */
timeSpent.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: timeSpent.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::timeSpent
 * @see app/Http/Controllers/TaskController.php:995
 * @route '/tasks/{task}/time-spent'
 */
    const timeSpentForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: timeSpent.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::timeSpent
 * @see app/Http/Controllers/TaskController.php:995
 * @route '/tasks/{task}/time-spent'
 */
        timeSpentForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeSpent.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::timeSpent
 * @see app/Http/Controllers/TaskController.php:995
 * @route '/tasks/{task}/time-spent'
 */
        timeSpentForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeSpent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    timeSpent.form = timeSpentForm
/**
* @see \App\Http\Controllers\TaskController::remainingTime
 * @see app/Http/Controllers/TaskController.php:1039
 * @route '/tasks/{task}/remaining-time'
 */
export const remainingTime = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: remainingTime.url(args, options),
    method: 'get',
})

remainingTime.definition = {
    methods: ["get","head"],
    url: '/tasks/{task}/remaining-time',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::remainingTime
 * @see app/Http/Controllers/TaskController.php:1039
 * @route '/tasks/{task}/remaining-time'
 */
remainingTime.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return remainingTime.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::remainingTime
 * @see app/Http/Controllers/TaskController.php:1039
 * @route '/tasks/{task}/remaining-time'
 */
remainingTime.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: remainingTime.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::remainingTime
 * @see app/Http/Controllers/TaskController.php:1039
 * @route '/tasks/{task}/remaining-time'
 */
remainingTime.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: remainingTime.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::remainingTime
 * @see app/Http/Controllers/TaskController.php:1039
 * @route '/tasks/{task}/remaining-time'
 */
    const remainingTimeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: remainingTime.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::remainingTime
 * @see app/Http/Controllers/TaskController.php:1039
 * @route '/tasks/{task}/remaining-time'
 */
        remainingTimeForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: remainingTime.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::remainingTime
 * @see app/Http/Controllers/TaskController.php:1039
 * @route '/tasks/{task}/remaining-time'
 */
        remainingTimeForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: remainingTime.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    remainingTime.form = remainingTimeForm
/**
* @see \App\Http\Controllers\TaskForwardingController::forward
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/tasks/{task}/forward'
 */
export const forward = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forward.url(args, options),
    method: 'post',
})

forward.definition = {
    methods: ["post"],
    url: '/tasks/{task}/forward',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::forward
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/tasks/{task}/forward'
 */
forward.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return forward.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::forward
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/tasks/{task}/forward'
 */
forward.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forward.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::forward
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/tasks/{task}/forward'
 */
    const forwardForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forward.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::forward
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/tasks/{task}/forward'
 */
        forwardForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forward.url(args, options),
            method: 'post',
        })
    
    forward.form = forwardForm
const tasks = {
    self: Object.assign(self, self),
my: Object.assign(my, myA9b1d5),
start: Object.assign(start, start),
pause: Object.assign(pause, pause),
resume: Object.assign(resume, resume),
end: Object.assign(end, end),
timeSpent: Object.assign(timeSpent, timeSpent),
remainingTime: Object.assign(remainingTime, remainingTime),
forwarding: Object.assign(forwarding, forwarding),
forward: Object.assign(forward, forward),
}

export default tasks