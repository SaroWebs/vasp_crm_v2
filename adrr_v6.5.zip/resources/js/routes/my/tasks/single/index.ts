import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:382
 * @route '/my/tasks/{task}/time-entries'
 */
export const timeEntries = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeEntries.url(args, options),
    method: 'get',
})

timeEntries.definition = {
    methods: ["get","head"],
    url: '/my/tasks/{task}/time-entries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:382
 * @route '/my/tasks/{task}/time-entries'
 */
timeEntries.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return timeEntries.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:382
 * @route '/my/tasks/{task}/time-entries'
 */
timeEntries.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeEntries.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:382
 * @route '/my/tasks/{task}/time-entries'
 */
timeEntries.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: timeEntries.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:382
 * @route '/my/tasks/{task}/time-entries'
 */
    const timeEntriesForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: timeEntries.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:382
 * @route '/my/tasks/{task}/time-entries'
 */
        timeEntriesForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeEntries.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:382
 * @route '/my/tasks/{task}/time-entries'
 */
        timeEntriesForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeEntries.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    timeEntries.form = timeEntriesForm
const single = {
    timeEntries: Object.assign(timeEntries, timeEntries),
}

export default single