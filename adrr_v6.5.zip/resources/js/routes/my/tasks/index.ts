import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import single from './single'
/**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/time-entries'
 */
export const timeEntries = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeEntries.url(options),
    method: 'get',
})

timeEntries.definition = {
    methods: ["get","head"],
    url: '/my/tasks/time-entries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/time-entries'
 */
timeEntries.url = (options?: RouteQueryOptions) => {
    return timeEntries.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/time-entries'
 */
timeEntries.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeEntries.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/time-entries'
 */
timeEntries.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: timeEntries.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/time-entries'
 */
    const timeEntriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: timeEntries.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/time-entries'
 */
        timeEntriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeEntries.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::timeEntries
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/time-entries'
 */
        timeEntriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeEntries.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    timeEntries.form = timeEntriesForm
/**
* @see \App\Http\Controllers\UserTaskController::start
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/{task}/start'
 */
export const start = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserTaskController::start
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/{task}/start'
 */
start.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return start.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::start
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/{task}/start'
 */
start.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UserTaskController::start
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/{task}/start'
 */
    const startForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::start
 * @see app/Http/Controllers/UserTaskController.php:18
 * @route '/my/tasks/{task}/start'
 */
        startForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(args, options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\TimeTrackingController::extendAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:437
 * @route '/my/tasks/{task}/extend-and-start'
 */
export const extendAndStart = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extendAndStart.url(args, options),
    method: 'post',
})

extendAndStart.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/extend-and-start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimeTrackingController::extendAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:437
 * @route '/my/tasks/{task}/extend-and-start'
 */
extendAndStart.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return extendAndStart.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTrackingController::extendAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:437
 * @route '/my/tasks/{task}/extend-and-start'
 */
extendAndStart.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extendAndStart.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TimeTrackingController::extendAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:437
 * @route '/my/tasks/{task}/extend-and-start'
 */
    const extendAndStartForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: extendAndStart.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimeTrackingController::extendAndStart
 * @see app/Http/Controllers/TimeTrackingController.php:437
 * @route '/my/tasks/{task}/extend-and-start'
 */
        extendAndStartForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: extendAndStart.url(args, options),
            method: 'post',
        })
    
    extendAndStart.form = extendAndStartForm
/**
* @see \App\Http\Controllers\UserTaskController::pause
 * @see app/Http/Controllers/UserTaskController.php:111
 * @route '/my/tasks/{task}/pause'
 */
export const pause = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

pause.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/pause',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserTaskController::pause
 * @see app/Http/Controllers/UserTaskController.php:111
 * @route '/my/tasks/{task}/pause'
 */
pause.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return pause.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::pause
 * @see app/Http/Controllers/UserTaskController.php:111
 * @route '/my/tasks/{task}/pause'
 */
pause.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UserTaskController::pause
 * @see app/Http/Controllers/UserTaskController.php:111
 * @route '/my/tasks/{task}/pause'
 */
    const pauseForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pause.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::pause
 * @see app/Http/Controllers/UserTaskController.php:111
 * @route '/my/tasks/{task}/pause'
 */
        pauseForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pause.url(args, options),
            method: 'post',
        })
    
    pause.form = pauseForm
/**
* @see \App\Http\Controllers\UserTaskController::resume
 * @see app/Http/Controllers/UserTaskController.php:154
 * @route '/my/tasks/{task}/resume'
 */
export const resume = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

resume.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/resume',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserTaskController::resume
 * @see app/Http/Controllers/UserTaskController.php:154
 * @route '/my/tasks/{task}/resume'
 */
resume.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return resume.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::resume
 * @see app/Http/Controllers/UserTaskController.php:154
 * @route '/my/tasks/{task}/resume'
 */
resume.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UserTaskController::resume
 * @see app/Http/Controllers/UserTaskController.php:154
 * @route '/my/tasks/{task}/resume'
 */
    const resumeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resume.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::resume
 * @see app/Http/Controllers/UserTaskController.php:154
 * @route '/my/tasks/{task}/resume'
 */
        resumeForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resume.url(args, options),
            method: 'post',
        })
    
    resume.form = resumeForm
/**
* @see \App\Http\Controllers\UserTaskController::end
 * @see app/Http/Controllers/UserTaskController.php:227
 * @route '/my/tasks/{task}/end'
 */
export const end = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: end.url(args, options),
    method: 'post',
})

end.definition = {
    methods: ["post"],
    url: '/my/tasks/{task}/end',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UserTaskController::end
 * @see app/Http/Controllers/UserTaskController.php:227
 * @route '/my/tasks/{task}/end'
 */
end.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return end.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::end
 * @see app/Http/Controllers/UserTaskController.php:227
 * @route '/my/tasks/{task}/end'
 */
end.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: end.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UserTaskController::end
 * @see app/Http/Controllers/UserTaskController.php:227
 * @route '/my/tasks/{task}/end'
 */
    const endForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: end.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::end
 * @see app/Http/Controllers/UserTaskController.php:227
 * @route '/my/tasks/{task}/end'
 */
        endForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: end.url(args, options),
            method: 'post',
        })
    
    end.form = endForm
/**
* @see \App\Http\Controllers\UserTaskController::timeSpent
 * @see app/Http/Controllers/UserTaskController.php:270
 * @route '/my/tasks/{task}/time-spent'
 */
export const timeSpent = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeSpent.url(args, options),
    method: 'get',
})

timeSpent.definition = {
    methods: ["get","head"],
    url: '/my/tasks/{task}/time-spent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::timeSpent
 * @see app/Http/Controllers/UserTaskController.php:270
 * @route '/my/tasks/{task}/time-spent'
 */
timeSpent.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return timeSpent.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::timeSpent
 * @see app/Http/Controllers/UserTaskController.php:270
 * @route '/my/tasks/{task}/time-spent'
 */
timeSpent.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeSpent.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::timeSpent
 * @see app/Http/Controllers/UserTaskController.php:270
 * @route '/my/tasks/{task}/time-spent'
 */
timeSpent.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: timeSpent.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::timeSpent
 * @see app/Http/Controllers/UserTaskController.php:270
 * @route '/my/tasks/{task}/time-spent'
 */
    const timeSpentForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: timeSpent.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::timeSpent
 * @see app/Http/Controllers/UserTaskController.php:270
 * @route '/my/tasks/{task}/time-spent'
 */
        timeSpentForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeSpent.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::timeSpent
 * @see app/Http/Controllers/UserTaskController.php:270
 * @route '/my/tasks/{task}/time-spent'
 */
        timeSpentForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeSpent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    timeSpent.form = timeSpentForm
/**
* @see \App\Http\Controllers\UserTaskController::remainingTime
 * @see app/Http/Controllers/UserTaskController.php:311
 * @route '/my/tasks/{task}/remaining-time'
 */
export const remainingTime = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: remainingTime.url(args, options),
    method: 'get',
})

remainingTime.definition = {
    methods: ["get","head"],
    url: '/my/tasks/{task}/remaining-time',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::remainingTime
 * @see app/Http/Controllers/UserTaskController.php:311
 * @route '/my/tasks/{task}/remaining-time'
 */
remainingTime.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return remainingTime.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::remainingTime
 * @see app/Http/Controllers/UserTaskController.php:311
 * @route '/my/tasks/{task}/remaining-time'
 */
remainingTime.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: remainingTime.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::remainingTime
 * @see app/Http/Controllers/UserTaskController.php:311
 * @route '/my/tasks/{task}/remaining-time'
 */
remainingTime.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: remainingTime.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::remainingTime
 * @see app/Http/Controllers/UserTaskController.php:311
 * @route '/my/tasks/{task}/remaining-time'
 */
    const remainingTimeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: remainingTime.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::remainingTime
 * @see app/Http/Controllers/UserTaskController.php:311
 * @route '/my/tasks/{task}/remaining-time'
 */
        remainingTimeForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: remainingTime.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::remainingTime
 * @see app/Http/Controllers/UserTaskController.php:311
 * @route '/my/tasks/{task}/remaining-time'
 */
        remainingTimeForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: remainingTime.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    remainingTime.form = remainingTimeForm
/**
* @see \App\Http\Controllers\TimeTrackingController::workingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:341
 * @route '/my/tasks/{task}/working-time-spent'
 */
export const workingTimeSpent = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workingTimeSpent.url(args, options),
    method: 'get',
})

workingTimeSpent.definition = {
    methods: ["get","head"],
    url: '/my/tasks/{task}/working-time-spent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimeTrackingController::workingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:341
 * @route '/my/tasks/{task}/working-time-spent'
 */
workingTimeSpent.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return workingTimeSpent.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTrackingController::workingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:341
 * @route '/my/tasks/{task}/working-time-spent'
 */
workingTimeSpent.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workingTimeSpent.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimeTrackingController::workingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:341
 * @route '/my/tasks/{task}/working-time-spent'
 */
workingTimeSpent.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workingTimeSpent.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimeTrackingController::workingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:341
 * @route '/my/tasks/{task}/working-time-spent'
 */
    const workingTimeSpentForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: workingTimeSpent.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimeTrackingController::workingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:341
 * @route '/my/tasks/{task}/working-time-spent'
 */
        workingTimeSpentForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: workingTimeSpent.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimeTrackingController::workingTimeSpent
 * @see app/Http/Controllers/TimeTrackingController.php:341
 * @route '/my/tasks/{task}/working-time-spent'
 */
        workingTimeSpentForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: workingTimeSpent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    workingTimeSpent.form = workingTimeSpentForm
const tasks = {
    timeEntries: Object.assign(timeEntries, timeEntries),
start: Object.assign(start, start),
extendAndStart: Object.assign(extendAndStart, extendAndStart),
pause: Object.assign(pause, pause),
resume: Object.assign(resume, resume),
end: Object.assign(end, end),
timeSpent: Object.assign(timeSpent, timeSpent),
remainingTime: Object.assign(remainingTime, remainingTime),
workingTimeSpent: Object.assign(workingTimeSpent, workingTimeSpent),
single: Object.assign(single, single),
}

export default tasks