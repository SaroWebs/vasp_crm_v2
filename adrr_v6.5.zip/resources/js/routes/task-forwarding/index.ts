import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:155
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
export const accept = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: accept.url(args, options),
    method: 'patch',
})

accept.definition = {
    methods: ["patch"],
    url: '/task-forwarding/{taskForwarding}/accept',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:155
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
accept.url = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskForwarding: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { taskForwarding: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    taskForwarding: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskForwarding: typeof args.taskForwarding === 'object'
                ? args.taskForwarding.id
                : args.taskForwarding,
                }

    return accept.definition.url
            .replace('{taskForwarding}', parsedArgs.taskForwarding.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:155
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
accept.patch = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: accept.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:155
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
    const acceptForm = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: accept.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::accept
 * @see app/Http/Controllers/TaskForwardingController.php:155
 * @route '/task-forwarding/{taskForwarding}/accept'
 */
        acceptForm.patch = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: accept.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    accept.form = acceptForm
/**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:215
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
export const reject = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

reject.definition = {
    methods: ["patch"],
    url: '/task-forwarding/{taskForwarding}/reject',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:215
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
reject.url = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskForwarding: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { taskForwarding: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    taskForwarding: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskForwarding: typeof args.taskForwarding === 'object'
                ? args.taskForwarding.id
                : args.taskForwarding,
                }

    return reject.definition.url
            .replace('{taskForwarding}', parsedArgs.taskForwarding.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:215
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
reject.patch = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:215
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
    const rejectForm = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::reject
 * @see app/Http/Controllers/TaskForwardingController.php:215
 * @route '/task-forwarding/{taskForwarding}/reject'
 */
        rejectForm.patch = (args: { taskForwarding: number | { id: number } } | [taskForwarding: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reject.form = rejectForm
const taskForwarding = {
    accept: Object.assign(accept, accept),
reject: Object.assign(reject, reject),
}

export default taskForwarding