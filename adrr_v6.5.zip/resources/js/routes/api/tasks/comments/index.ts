import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskCommentController::index
 * @see app/Http/Controllers/TaskCommentController.php:28
 * @route '/data/tasks/{task}/comments'
 */
export const index = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/comments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskCommentController::index
 * @see app/Http/Controllers/TaskCommentController.php:28
 * @route '/data/tasks/{task}/comments'
 */
index.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return index.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskCommentController::index
 * @see app/Http/Controllers/TaskCommentController.php:28
 * @route '/data/tasks/{task}/comments'
 */
index.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskCommentController::index
 * @see app/Http/Controllers/TaskCommentController.php:28
 * @route '/data/tasks/{task}/comments'
 */
index.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskCommentController::index
 * @see app/Http/Controllers/TaskCommentController.php:28
 * @route '/data/tasks/{task}/comments'
 */
    const indexForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskCommentController::index
 * @see app/Http/Controllers/TaskCommentController.php:28
 * @route '/data/tasks/{task}/comments'
 */
        indexForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskCommentController::index
 * @see app/Http/Controllers/TaskCommentController.php:28
 * @route '/data/tasks/{task}/comments'
 */
        indexForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TaskCommentController::store
 * @see app/Http/Controllers/TaskCommentController.php:72
 * @route '/data/tasks/{task}/comments'
 */
export const store = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/data/tasks/{task}/comments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskCommentController::store
 * @see app/Http/Controllers/TaskCommentController.php:72
 * @route '/data/tasks/{task}/comments'
 */
store.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return store.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskCommentController::store
 * @see app/Http/Controllers/TaskCommentController.php:72
 * @route '/data/tasks/{task}/comments'
 */
store.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskCommentController::store
 * @see app/Http/Controllers/TaskCommentController.php:72
 * @route '/data/tasks/{task}/comments'
 */
    const storeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskCommentController::store
 * @see app/Http/Controllers/TaskCommentController.php:72
 * @route '/data/tasks/{task}/comments'
 */
        storeForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TaskCommentController::update
 * @see app/Http/Controllers/TaskCommentController.php:157
 * @route '/data/tasks/{task}/comments/{comment}'
 */
export const update = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/data/tasks/{task}/comments/{comment}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskCommentController::update
 * @see app/Http/Controllers/TaskCommentController.php:157
 * @route '/data/tasks/{task}/comments/{comment}'
 */
update.url = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return update.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskCommentController::update
 * @see app/Http/Controllers/TaskCommentController.php:157
 * @route '/data/tasks/{task}/comments/{comment}'
 */
update.patch = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskCommentController::update
 * @see app/Http/Controllers/TaskCommentController.php:157
 * @route '/data/tasks/{task}/comments/{comment}'
 */
    const updateForm = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskCommentController::update
 * @see app/Http/Controllers/TaskCommentController.php:157
 * @route '/data/tasks/{task}/comments/{comment}'
 */
        updateForm.patch = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TaskCommentController::destroy
 * @see app/Http/Controllers/TaskCommentController.php:222
 * @route '/data/tasks/{task}/comments/{comment}'
 */
export const destroy = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/data/tasks/{task}/comments/{comment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TaskCommentController::destroy
 * @see app/Http/Controllers/TaskCommentController.php:222
 * @route '/data/tasks/{task}/comments/{comment}'
 */
destroy.url = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return destroy.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskCommentController::destroy
 * @see app/Http/Controllers/TaskCommentController.php:222
 * @route '/data/tasks/{task}/comments/{comment}'
 */
destroy.delete = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TaskCommentController::destroy
 * @see app/Http/Controllers/TaskCommentController.php:222
 * @route '/data/tasks/{task}/comments/{comment}'
 */
    const destroyForm = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskCommentController::destroy
 * @see app/Http/Controllers/TaskCommentController.php:222
 * @route '/data/tasks/{task}/comments/{comment}'
 */
        destroyForm.delete = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\TaskCommentController::deleted
 * @see app/Http/Controllers/TaskCommentController.php:285
 * @route '/data/tasks/{task}/comments/deleted'
 */
export const deleted = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: deleted.url(args, options),
    method: 'get',
})

deleted.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/comments/deleted',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskCommentController::deleted
 * @see app/Http/Controllers/TaskCommentController.php:285
 * @route '/data/tasks/{task}/comments/deleted'
 */
deleted.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return deleted.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskCommentController::deleted
 * @see app/Http/Controllers/TaskCommentController.php:285
 * @route '/data/tasks/{task}/comments/deleted'
 */
deleted.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: deleted.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskCommentController::deleted
 * @see app/Http/Controllers/TaskCommentController.php:285
 * @route '/data/tasks/{task}/comments/deleted'
 */
deleted.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: deleted.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskCommentController::deleted
 * @see app/Http/Controllers/TaskCommentController.php:285
 * @route '/data/tasks/{task}/comments/deleted'
 */
    const deletedForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: deleted.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskCommentController::deleted
 * @see app/Http/Controllers/TaskCommentController.php:285
 * @route '/data/tasks/{task}/comments/deleted'
 */
        deletedForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: deleted.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskCommentController::deleted
 * @see app/Http/Controllers/TaskCommentController.php:285
 * @route '/data/tasks/{task}/comments/deleted'
 */
        deletedForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: deleted.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    deleted.form = deletedForm
/**
* @see \App\Http\Controllers\TaskCommentController::restore
 * @see app/Http/Controllers/TaskCommentController.php:328
 * @route '/data/tasks/{task}/comments/{comment}/restore'
 */
export const restore = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

restore.definition = {
    methods: ["patch"],
    url: '/data/tasks/{task}/comments/{comment}/restore',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskCommentController::restore
 * @see app/Http/Controllers/TaskCommentController.php:328
 * @route '/data/tasks/{task}/comments/{comment}/restore'
 */
restore.url = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return restore.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskCommentController::restore
 * @see app/Http/Controllers/TaskCommentController.php:328
 * @route '/data/tasks/{task}/comments/{comment}/restore'
 */
restore.patch = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskCommentController::restore
 * @see app/Http/Controllers/TaskCommentController.php:328
 * @route '/data/tasks/{task}/comments/{comment}/restore'
 */
    const restoreForm = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskCommentController::restore
 * @see app/Http/Controllers/TaskCommentController.php:328
 * @route '/data/tasks/{task}/comments/{comment}/restore'
 */
        restoreForm.patch = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\TaskCommentController::forceDelete
 * @see app/Http/Controllers/TaskCommentController.php:382
 * @route '/data/tasks/{task}/comments/{comment}/force-delete'
 */
export const forceDelete = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: forceDelete.url(args, options),
    method: 'delete',
})

forceDelete.definition = {
    methods: ["delete"],
    url: '/data/tasks/{task}/comments/{comment}/force-delete',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TaskCommentController::forceDelete
 * @see app/Http/Controllers/TaskCommentController.php:382
 * @route '/data/tasks/{task}/comments/{comment}/force-delete'
 */
forceDelete.url = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                    comment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return forceDelete.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskCommentController::forceDelete
 * @see app/Http/Controllers/TaskCommentController.php:382
 * @route '/data/tasks/{task}/comments/{comment}/force-delete'
 */
forceDelete.delete = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: forceDelete.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TaskCommentController::forceDelete
 * @see app/Http/Controllers/TaskCommentController.php:382
 * @route '/data/tasks/{task}/comments/{comment}/force-delete'
 */
    const forceDeleteForm = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceDelete.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskCommentController::forceDelete
 * @see app/Http/Controllers/TaskCommentController.php:382
 * @route '/data/tasks/{task}/comments/{comment}/force-delete'
 */
        forceDeleteForm.delete = (args: { task: number | { id: number }, comment: number | { id: number } } | [task: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceDelete.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    forceDelete.form = forceDeleteForm
const comments = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
deleted: Object.assign(deleted, deleted),
restore: Object.assign(restore, restore),
forceDelete: Object.assign(forceDelete, forceDelete),
}

export default comments