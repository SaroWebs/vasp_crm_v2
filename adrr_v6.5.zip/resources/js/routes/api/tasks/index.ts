import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import comments from './comments'
import attachments from './attachments'
import forwardings from './forwardings'
/**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1823
 * @route '/data/tasks/calculate-min-due-date'
 */
export const calculateMinDueDate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateMinDueDate.url(options),
    method: 'get',
})

calculateMinDueDate.definition = {
    methods: ["get","head"],
    url: '/data/tasks/calculate-min-due-date',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1823
 * @route '/data/tasks/calculate-min-due-date'
 */
calculateMinDueDate.url = (options?: RouteQueryOptions) => {
    return calculateMinDueDate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1823
 * @route '/data/tasks/calculate-min-due-date'
 */
calculateMinDueDate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateMinDueDate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1823
 * @route '/data/tasks/calculate-min-due-date'
 */
calculateMinDueDate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calculateMinDueDate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1823
 * @route '/data/tasks/calculate-min-due-date'
 */
    const calculateMinDueDateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calculateMinDueDate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1823
 * @route '/data/tasks/calculate-min-due-date'
 */
        calculateMinDueDateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateMinDueDate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1823
 * @route '/data/tasks/calculate-min-due-date'
 */
        calculateMinDueDateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateMinDueDate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calculateMinDueDate.form = calculateMinDueDateForm
/**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:147
 * @route '/data/tasks/{task}'
 */
export const show = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:147
 * @route '/data/tasks/{task}'
 */
show.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return show.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:147
 * @route '/data/tasks/{task}'
 */
show.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:147
 * @route '/data/tasks/{task}'
 */
show.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:147
 * @route '/data/tasks/{task}'
 */
    const showForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:147
 * @route '/data/tasks/{task}'
 */
        showForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:147
 * @route '/data/tasks/{task}'
 */
        showForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:290
 * @route '/data/tasks/{task}'
 */
export const update = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/data/tasks/{task}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:290
 * @route '/data/tasks/{task}'
 */
update.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return update.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:290
 * @route '/data/tasks/{task}'
 */
update.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:290
 * @route '/data/tasks/{task}'
 */
    const updateForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:290
 * @route '/data/tasks/{task}'
 */
        updateForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:346
 * @route '/data/tasks/{task}/extend-due-date'
 */
export const extendDueDate = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: extendDueDate.url(args, options),
    method: 'patch',
})

extendDueDate.definition = {
    methods: ["patch"],
    url: '/data/tasks/{task}/extend-due-date',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:346
 * @route '/data/tasks/{task}/extend-due-date'
 */
extendDueDate.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return extendDueDate.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:346
 * @route '/data/tasks/{task}/extend-due-date'
 */
extendDueDate.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: extendDueDate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:346
 * @route '/data/tasks/{task}/extend-due-date'
 */
    const extendDueDateForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: extendDueDate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:346
 * @route '/data/tasks/{task}/extend-due-date'
 */
        extendDueDateForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: extendDueDate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    extendDueDate.form = extendDueDateForm
/**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:374
 * @route '/data/tasks/{task}'
 */
export const destroy = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/data/tasks/{task}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:374
 * @route '/data/tasks/{task}'
 */
destroy.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return destroy.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:374
 * @route '/data/tasks/{task}'
 */
destroy.delete = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:374
 * @route '/data/tasks/{task}'
 */
    const destroyForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:374
 * @route '/data/tasks/{task}'
 */
        destroyForm.delete = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:636
 * @route '/data/tasks/{task}/status'
 */
export const updateStatus = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/data/tasks/{task}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:636
 * @route '/data/tasks/{task}/status'
 */
updateStatus.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return updateStatus.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:636
 * @route '/data/tasks/{task}/status'
 */
updateStatus.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:636
 * @route '/data/tasks/{task}/status'
 */
    const updateStatusForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:636
 * @route '/data/tasks/{task}/status'
 */
        updateStatusForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\TaskController::byStatus
 * @see app/Http/Controllers/TaskController.php:598
 * @route '/data/tasks/status/{status}'
 */
export const byStatus = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byStatus.url(args, options),
    method: 'get',
})

byStatus.definition = {
    methods: ["get","head"],
    url: '/data/tasks/status/{status}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::byStatus
 * @see app/Http/Controllers/TaskController.php:598
 * @route '/data/tasks/status/{status}'
 */
byStatus.url = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { status: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    status: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        status: args.status,
                }

    return byStatus.definition.url
            .replace('{status}', parsedArgs.status.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::byStatus
 * @see app/Http/Controllers/TaskController.php:598
 * @route '/data/tasks/status/{status}'
 */
byStatus.get = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byStatus.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::byStatus
 * @see app/Http/Controllers/TaskController.php:598
 * @route '/data/tasks/status/{status}'
 */
byStatus.head = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: byStatus.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::byStatus
 * @see app/Http/Controllers/TaskController.php:598
 * @route '/data/tasks/status/{status}'
 */
    const byStatusForm = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: byStatus.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::byStatus
 * @see app/Http/Controllers/TaskController.php:598
 * @route '/data/tasks/status/{status}'
 */
        byStatusForm.get = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byStatus.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::byStatus
 * @see app/Http/Controllers/TaskController.php:598
 * @route '/data/tasks/status/{status}'
 */
        byStatusForm.head = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    byStatus.form = byStatusForm
/**
* @see \App\Http\Controllers\TaskController::history
 * @see app/Http/Controllers/TaskController.php:1420
 * @route '/data/tasks/{task}/history'
 */
export const history = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::history
 * @see app/Http/Controllers/TaskController.php:1420
 * @route '/data/tasks/{task}/history'
 */
history.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return history.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::history
 * @see app/Http/Controllers/TaskController.php:1420
 * @route '/data/tasks/{task}/history'
 */
history.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::history
 * @see app/Http/Controllers/TaskController.php:1420
 * @route '/data/tasks/{task}/history'
 */
history.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::history
 * @see app/Http/Controllers/TaskController.php:1420
 * @route '/data/tasks/{task}/history'
 */
    const historyForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: history.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::history
 * @see app/Http/Controllers/TaskController.php:1420
 * @route '/data/tasks/{task}/history'
 */
        historyForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::history
 * @see app/Http/Controllers/TaskController.php:1420
 * @route '/data/tasks/{task}/history'
 */
        historyForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    history.form = historyForm
/**
* @see \App\Http\Controllers\TaskController::workloadMetrics
 * @see app/Http/Controllers/TaskController.php:1369
 * @route '/data/tasks/{task}/workload-metrics'
 */
export const workloadMetrics = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workloadMetrics.url(args, options),
    method: 'get',
})

workloadMetrics.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/workload-metrics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::workloadMetrics
 * @see app/Http/Controllers/TaskController.php:1369
 * @route '/data/tasks/{task}/workload-metrics'
 */
workloadMetrics.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return workloadMetrics.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::workloadMetrics
 * @see app/Http/Controllers/TaskController.php:1369
 * @route '/data/tasks/{task}/workload-metrics'
 */
workloadMetrics.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workloadMetrics.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::workloadMetrics
 * @see app/Http/Controllers/TaskController.php:1369
 * @route '/data/tasks/{task}/workload-metrics'
 */
workloadMetrics.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workloadMetrics.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::workloadMetrics
 * @see app/Http/Controllers/TaskController.php:1369
 * @route '/data/tasks/{task}/workload-metrics'
 */
    const workloadMetricsForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: workloadMetrics.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::workloadMetrics
 * @see app/Http/Controllers/TaskController.php:1369
 * @route '/data/tasks/{task}/workload-metrics'
 */
        workloadMetricsForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: workloadMetrics.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::workloadMetrics
 * @see app/Http/Controllers/TaskController.php:1369
 * @route '/data/tasks/{task}/workload-metrics'
 */
        workloadMetricsForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: workloadMetrics.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    workloadMetrics.form = workloadMetricsForm
/**
* @see \App\Http\Controllers\TaskController::auditEvents
 * @see app/Http/Controllers/TaskController.php:1397
 * @route '/data/tasks/{task}/audit-events'
 */
export const auditEvents = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: auditEvents.url(args, options),
    method: 'get',
})

auditEvents.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/audit-events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::auditEvents
 * @see app/Http/Controllers/TaskController.php:1397
 * @route '/data/tasks/{task}/audit-events'
 */
auditEvents.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return auditEvents.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::auditEvents
 * @see app/Http/Controllers/TaskController.php:1397
 * @route '/data/tasks/{task}/audit-events'
 */
auditEvents.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: auditEvents.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::auditEvents
 * @see app/Http/Controllers/TaskController.php:1397
 * @route '/data/tasks/{task}/audit-events'
 */
auditEvents.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: auditEvents.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::auditEvents
 * @see app/Http/Controllers/TaskController.php:1397
 * @route '/data/tasks/{task}/audit-events'
 */
    const auditEventsForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: auditEvents.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::auditEvents
 * @see app/Http/Controllers/TaskController.php:1397
 * @route '/data/tasks/{task}/audit-events'
 */
        auditEventsForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: auditEvents.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::auditEvents
 * @see app/Http/Controllers/TaskController.php:1397
 * @route '/data/tasks/{task}/audit-events'
 */
        auditEventsForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: auditEvents.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    auditEvents.form = auditEventsForm
/**
* @see \App\Http\Controllers\TimelineEventController::milestones
 * @see app/Http/Controllers/TimelineEventController.php:318
 * @route '/tasks/{task}/milestones'
 */
export const milestones = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: milestones.url(args, options),
    method: 'get',
})

milestones.definition = {
    methods: ["get","head"],
    url: '/tasks/{task}/milestones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineEventController::milestones
 * @see app/Http/Controllers/TimelineEventController.php:318
 * @route '/tasks/{task}/milestones'
 */
milestones.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return milestones.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::milestones
 * @see app/Http/Controllers/TimelineEventController.php:318
 * @route '/tasks/{task}/milestones'
 */
milestones.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: milestones.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineEventController::milestones
 * @see app/Http/Controllers/TimelineEventController.php:318
 * @route '/tasks/{task}/milestones'
 */
milestones.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: milestones.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::milestones
 * @see app/Http/Controllers/TimelineEventController.php:318
 * @route '/tasks/{task}/milestones'
 */
    const milestonesForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: milestones.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::milestones
 * @see app/Http/Controllers/TimelineEventController.php:318
 * @route '/tasks/{task}/milestones'
 */
        milestonesForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: milestones.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineEventController::milestones
 * @see app/Http/Controllers/TimelineEventController.php:318
 * @route '/tasks/{task}/milestones'
 */
        milestonesForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: milestones.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    milestones.form = milestonesForm
/**
* @see \App\Http\Controllers\TaskAssignmentController::assign
 * @see app/Http/Controllers/TaskAssignmentController.php:244
 * @route '/api/tasks/{task}/assign'
 */
export const assign = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assign.url(args, options),
    method: 'post',
})

assign.definition = {
    methods: ["post"],
    url: '/api/tasks/{task}/assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::assign
 * @see app/Http/Controllers/TaskAssignmentController.php:244
 * @route '/api/tasks/{task}/assign'
 */
assign.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return assign.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::assign
 * @see app/Http/Controllers/TaskAssignmentController.php:244
 * @route '/api/tasks/{task}/assign'
 */
assign.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assign.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::assign
 * @see app/Http/Controllers/TaskAssignmentController.php:244
 * @route '/api/tasks/{task}/assign'
 */
    const assignForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assign.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::assign
 * @see app/Http/Controllers/TaskAssignmentController.php:244
 * @route '/api/tasks/{task}/assign'
 */
        assignForm.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assign.url(args, options),
            method: 'post',
        })
    
    assign.form = assignForm
/**
* @see \App\Http\Controllers\TaskAssignmentController::unassign
 * @see app/Http/Controllers/TaskAssignmentController.php:307
 * @route '/api/tasks/{task}/unassign'
 */
export const unassign = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unassign.url(args, options),
    method: 'post',
})

unassign.definition = {
    methods: ["post"],
    url: '/api/tasks/{task}/unassign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::unassign
 * @see app/Http/Controllers/TaskAssignmentController.php:307
 * @route '/api/tasks/{task}/unassign'
 */
unassign.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return unassign.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::unassign
 * @see app/Http/Controllers/TaskAssignmentController.php:307
 * @route '/api/tasks/{task}/unassign'
 */
unassign.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unassign.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::unassign
 * @see app/Http/Controllers/TaskAssignmentController.php:307
 * @route '/api/tasks/{task}/unassign'
 */
    const unassignForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unassign.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::unassign
 * @see app/Http/Controllers/TaskAssignmentController.php:307
 * @route '/api/tasks/{task}/unassign'
 */
        unassignForm.post = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unassign.url(args, options),
            method: 'post',
        })
    
    unassign.form = unassignForm
/**
* @see \App\Http\Controllers\TaskAssignmentController::assignments
 * @see app/Http/Controllers/TaskAssignmentController.php:211
 * @route '/api/tasks/{task}/assignments'
 */
export const assignments = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assignments.url(args, options),
    method: 'get',
})

assignments.definition = {
    methods: ["get","head"],
    url: '/api/tasks/{task}/assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::assignments
 * @see app/Http/Controllers/TaskAssignmentController.php:211
 * @route '/api/tasks/{task}/assignments'
 */
assignments.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return assignments.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::assignments
 * @see app/Http/Controllers/TaskAssignmentController.php:211
 * @route '/api/tasks/{task}/assignments'
 */
assignments.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assignments.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskAssignmentController::assignments
 * @see app/Http/Controllers/TaskAssignmentController.php:211
 * @route '/api/tasks/{task}/assignments'
 */
assignments.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: assignments.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::assignments
 * @see app/Http/Controllers/TaskAssignmentController.php:211
 * @route '/api/tasks/{task}/assignments'
 */
    const assignmentsForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: assignments.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::assignments
 * @see app/Http/Controllers/TaskAssignmentController.php:211
 * @route '/api/tasks/{task}/assignments'
 */
        assignmentsForm.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: assignments.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskAssignmentController::assignments
 * @see app/Http/Controllers/TaskAssignmentController.php:211
 * @route '/api/tasks/{task}/assignments'
 */
        assignmentsForm.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: assignments.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    assignments.form = assignmentsForm
/**
* @see \App\Http\Controllers\TaskAssignmentController::availableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:528
 * @route '/api/tasks/{task}/available-users'
 */
export const availableUsers = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableUsers.url(args, options),
    method: 'get',
})

availableUsers.definition = {
    methods: ["get","head"],
    url: '/api/tasks/{task}/available-users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskAssignmentController::availableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:528
 * @route '/api/tasks/{task}/available-users'
 */
availableUsers.url = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: args.task,
                }

    return availableUsers.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAssignmentController::availableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:528
 * @route '/api/tasks/{task}/available-users'
 */
availableUsers.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableUsers.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskAssignmentController::availableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:528
 * @route '/api/tasks/{task}/available-users'
 */
availableUsers.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availableUsers.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskAssignmentController::availableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:528
 * @route '/api/tasks/{task}/available-users'
 */
    const availableUsersForm = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: availableUsers.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskAssignmentController::availableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:528
 * @route '/api/tasks/{task}/available-users'
 */
        availableUsersForm.get = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availableUsers.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskAssignmentController::availableUsers
 * @see app/Http/Controllers/TaskAssignmentController.php:528
 * @route '/api/tasks/{task}/available-users'
 */
        availableUsersForm.head = (args: { task: string | number } | [task: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availableUsers.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    availableUsers.form = availableUsersForm
const tasks = {
    calculateMinDueDate: Object.assign(calculateMinDueDate, calculateMinDueDate),
show: Object.assign(show, show),
update: Object.assign(update, update),
extendDueDate: Object.assign(extendDueDate, extendDueDate),
destroy: Object.assign(destroy, destroy),
updateStatus: Object.assign(updateStatus, updateStatus),
byStatus: Object.assign(byStatus, byStatus),
comments: Object.assign(comments, comments),
history: Object.assign(history, history),
attachments: Object.assign(attachments, attachments),
forwardings: Object.assign(forwardings, forwardings),
workloadMetrics: Object.assign(workloadMetrics, workloadMetrics),
auditEvents: Object.assign(auditEvents, auditEvents),
milestones: Object.assign(milestones, milestones),
assign: Object.assign(assign, assign),
unassign: Object.assign(unassign, unassign),
assignments: Object.assign(assignments, assignments),
availableUsers: Object.assign(availableUsers, availableUsers),
}

export default tasks