import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskAttachmentController::index
 * @see app/Http/Controllers/TaskAttachmentController.php:18
 * @route '/data/tasks/{task}/attachments'
 */
export const index = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/attachments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskAttachmentController::index
 * @see app/Http/Controllers/TaskAttachmentController.php:18
 * @route '/data/tasks/{task}/attachments'
 */
index.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return index.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAttachmentController::index
 * @see app/Http/Controllers/TaskAttachmentController.php:18
 * @route '/data/tasks/{task}/attachments'
 */
index.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskAttachmentController::index
 * @see app/Http/Controllers/TaskAttachmentController.php:18
 * @route '/data/tasks/{task}/attachments'
 */
index.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskAttachmentController::index
 * @see app/Http/Controllers/TaskAttachmentController.php:18
 * @route '/data/tasks/{task}/attachments'
 */
    const indexForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskAttachmentController::index
 * @see app/Http/Controllers/TaskAttachmentController.php:18
 * @route '/data/tasks/{task}/attachments'
 */
        indexForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskAttachmentController::index
 * @see app/Http/Controllers/TaskAttachmentController.php:18
 * @route '/data/tasks/{task}/attachments'
 */
        indexForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TaskAttachmentController::store
 * @see app/Http/Controllers/TaskAttachmentController.php:80
 * @route '/data/tasks/{task}/attachments'
 */
export const store = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/data/tasks/{task}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskAttachmentController::store
 * @see app/Http/Controllers/TaskAttachmentController.php:80
 * @route '/data/tasks/{task}/attachments'
 */
store.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return store.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAttachmentController::store
 * @see app/Http/Controllers/TaskAttachmentController.php:80
 * @route '/data/tasks/{task}/attachments'
 */
store.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskAttachmentController::store
 * @see app/Http/Controllers/TaskAttachmentController.php:80
 * @route '/data/tasks/{task}/attachments'
 */
    const storeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskAttachmentController::store
 * @see app/Http/Controllers/TaskAttachmentController.php:80
 * @route '/data/tasks/{task}/attachments'
 */
        storeForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TaskAttachmentController::destroy
 * @see app/Http/Controllers/TaskAttachmentController.php:133
 * @route '/data/tasks/{task}/attachments/{attachment}'
 */
export const destroy = (args: { task: number | { id: number }, attachment: number | { id: number } } | [task: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/data/tasks/{task}/attachments/{attachment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TaskAttachmentController::destroy
 * @see app/Http/Controllers/TaskAttachmentController.php:133
 * @route '/data/tasks/{task}/attachments/{attachment}'
 */
destroy.url = (args: { task: number | { id: number }, attachment: number | { id: number } } | [task: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return destroy.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskAttachmentController::destroy
 * @see app/Http/Controllers/TaskAttachmentController.php:133
 * @route '/data/tasks/{task}/attachments/{attachment}'
 */
destroy.delete = (args: { task: number | { id: number }, attachment: number | { id: number } } | [task: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TaskAttachmentController::destroy
 * @see app/Http/Controllers/TaskAttachmentController.php:133
 * @route '/data/tasks/{task}/attachments/{attachment}'
 */
    const destroyForm = (args: { task: number | { id: number }, attachment: number | { id: number } } | [task: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskAttachmentController::destroy
 * @see app/Http/Controllers/TaskAttachmentController.php:133
 * @route '/data/tasks/{task}/attachments/{attachment}'
 */
        destroyForm.delete = (args: { task: number | { id: number }, attachment: number | { id: number } } | [task: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const attachments = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default attachments