import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:28
 * @route '/data/tasks/{task}/forwardings'
 */
export const index = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/forwardings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:28
 * @route '/data/tasks/{task}/forwardings'
 */
index.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return index.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:28
 * @route '/data/tasks/{task}/forwardings'
 */
index.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:28
 * @route '/data/tasks/{task}/forwardings'
 */
index.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:28
 * @route '/data/tasks/{task}/forwardings'
 */
    const indexForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:28
 * @route '/data/tasks/{task}/forwardings'
 */
        indexForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskForwardingController::index
 * @see app/Http/Controllers/TaskForwardingController.php:28
 * @route '/data/tasks/{task}/forwardings'
 */
        indexForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/data/tasks/{task}/forwardings'
 */
export const store = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/data/tasks/{task}/forwardings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/data/tasks/{task}/forwardings'
 */
store.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return store.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/data/tasks/{task}/forwardings'
 */
store.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/data/tasks/{task}/forwardings'
 */
    const storeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskForwardingController::store
 * @see app/Http/Controllers/TaskForwardingController.php:60
 * @route '/data/tasks/{task}/forwardings'
 */
        storeForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const forwardings = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
}

export default forwardings