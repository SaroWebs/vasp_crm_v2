import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/timeline-events/milestones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:167
 * @route '/timeline-events/milestones'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:220
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
export const update = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/timeline-events/{timelineEvent}/milestone',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:220
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
update.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return update.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:220
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
update.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:220
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
    const updateForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:220
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
        updateForm.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:302
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
export const destroy = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/timeline-events/{timelineEvent}/milestone',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:302
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
destroy.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return destroy.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:302
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
destroy.delete = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:302
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
    const destroyForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:302
 * @route '/timeline-events/{timelineEvent}/milestone'
 */
        destroyForm.delete = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\TimelineEventController::complete
 * @see app/Http/Controllers/TimelineEventController.php:275
 * @route '/timeline-events/{timelineEvent}/complete'
 */
export const complete = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: complete.url(args, options),
    method: 'patch',
})

complete.definition = {
    methods: ["patch"],
    url: '/timeline-events/{timelineEvent}/complete',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TimelineEventController::complete
 * @see app/Http/Controllers/TimelineEventController.php:275
 * @route '/timeline-events/{timelineEvent}/complete'
 */
complete.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return complete.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::complete
 * @see app/Http/Controllers/TimelineEventController.php:275
 * @route '/timeline-events/{timelineEvent}/complete'
 */
complete.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: complete.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::complete
 * @see app/Http/Controllers/TimelineEventController.php:275
 * @route '/timeline-events/{timelineEvent}/complete'
 */
    const completeForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::complete
 * @see app/Http/Controllers/TimelineEventController.php:275
 * @route '/timeline-events/{timelineEvent}/complete'
 */
        completeForm.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    complete.form = completeForm
const milestones = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
complete: Object.assign(complete, complete),
}

export default milestones