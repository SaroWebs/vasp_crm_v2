import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import milestones from './milestones'
/**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/timeline-events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineEventController::index
 * @see app/Http/Controllers/TimelineEventController.php:16
 * @route '/timeline-events'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/timeline-events',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::store
 * @see app/Http/Controllers/TimelineEventController.php:44
 * @route '/timeline-events'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
export const storeReport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeReport.url(options),
    method: 'post',
})

storeReport.definition = {
    methods: ["post"],
    url: '/timeline-events/store-report',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
storeReport.url = (options?: RouteQueryOptions) => {
    return storeReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
storeReport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeReport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
    const storeReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeReport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::storeReport
 * @see app/Http/Controllers/TimelineEventController.php:123
 * @route '/timeline-events/store-report'
 */
        storeReportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeReport.url(options),
            method: 'post',
        })
    
    storeReport.form = storeReportForm
/**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
export const show = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/timeline-events/{timelineEvent}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
show.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return show.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
show.get = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
show.head = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
    const showForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
        showForm.get = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineEventController::show
 * @see app/Http/Controllers/TimelineEventController.php:89
 * @route '/timeline-events/{timelineEvent}'
 */
        showForm.head = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
export const update = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/timeline-events/{timelineEvent}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
update.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return update.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
update.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
    const updateForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::update
 * @see app/Http/Controllers/TimelineEventController.php:97
 * @route '/timeline-events/{timelineEvent}'
 */
        updateForm.patch = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
export const destroy = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/timeline-events/{timelineEvent}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
destroy.url = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timelineEvent: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timelineEvent: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timelineEvent: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timelineEvent: typeof args.timelineEvent === 'object'
                ? args.timelineEvent.id
                : args.timelineEvent,
                }

    return destroy.definition.url
            .replace('{timelineEvent}', parsedArgs.timelineEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
destroy.delete = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
    const destroyForm = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimelineEventController::destroy
 * @see app/Http/Controllers/TimelineEventController.php:116
 * @route '/timeline-events/{timelineEvent}'
 */
        destroyForm.delete = (args: { timelineEvent: number | { id: number } } | [timelineEvent: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const timelineEvents = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
storeReport: Object.assign(storeReport, storeReport),
show: Object.assign(show, show),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
milestones: Object.assign(milestones, milestones),
}

export default timelineEvents