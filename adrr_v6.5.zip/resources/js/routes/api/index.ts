import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import notifications from './notifications'
import tasks from './tasks'
import taskTypes from './task-types'
import timelineEvents from './timeline-events'
import milestones from './milestones'
import taskDependencies from './task-dependencies'
import taskAssignments from './task-assignments'
import activityLogs from './activity-logs'
import my from './my'
/**
* @see \App\Http\Controllers\TimeTrackingController::workingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:421
 * @route '/api/working-hours-config'
 */
export const workingHoursConfig = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workingHoursConfig.url(options),
    method: 'get',
})

workingHoursConfig.definition = {
    methods: ["get","head"],
    url: '/api/working-hours-config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimeTrackingController::workingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:421
 * @route '/api/working-hours-config'
 */
workingHoursConfig.url = (options?: RouteQueryOptions) => {
    return workingHoursConfig.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTrackingController::workingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:421
 * @route '/api/working-hours-config'
 */
workingHoursConfig.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workingHoursConfig.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimeTrackingController::workingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:421
 * @route '/api/working-hours-config'
 */
workingHoursConfig.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workingHoursConfig.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimeTrackingController::workingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:421
 * @route '/api/working-hours-config'
 */
    const workingHoursConfigForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: workingHoursConfig.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimeTrackingController::workingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:421
 * @route '/api/working-hours-config'
 */
        workingHoursConfigForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: workingHoursConfig.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimeTrackingController::workingHoursConfig
 * @see app/Http/Controllers/TimeTrackingController.php:421
 * @route '/api/working-hours-config'
 */
        workingHoursConfigForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: workingHoursConfig.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    workingHoursConfig.form = workingHoursConfigForm
/**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:557
 * @route '/api/attendance/{employeeId}'
 */
export const attendance = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendance.url(args, options),
    method: 'get',
})

attendance.definition = {
    methods: ["get","head"],
    url: '/api/attendance/{employeeId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:557
 * @route '/api/attendance/{employeeId}'
 */
attendance.url = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employeeId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    employeeId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employeeId: args.employeeId,
                }

    return attendance.definition.url
            .replace('{employeeId}', parsedArgs.employeeId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:557
 * @route '/api/attendance/{employeeId}'
 */
attendance.get = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendance.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:557
 * @route '/api/attendance/{employeeId}'
 */
attendance.head = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: attendance.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:557
 * @route '/api/attendance/{employeeId}'
 */
    const attendanceForm = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: attendance.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:557
 * @route '/api/attendance/{employeeId}'
 */
        attendanceForm.get = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendance.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:557
 * @route '/api/attendance/{employeeId}'
 */
        attendanceForm.head = (args: { employeeId: string | number } | [employeeId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendance.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    attendance.form = attendanceForm
const api = {
    notifications: Object.assign(notifications, notifications),
tasks: Object.assign(tasks, tasks),
taskTypes: Object.assign(taskTypes, taskTypes),
workingHoursConfig: Object.assign(workingHoursConfig, workingHoursConfig),
timelineEvents: Object.assign(timelineEvents, timelineEvents),
milestones: Object.assign(milestones, milestones),
taskDependencies: Object.assign(taskDependencies, taskDependencies),
taskAssignments: Object.assign(taskAssignments, taskAssignments),
activityLogs: Object.assign(activityLogs, activityLogs),
attendance: Object.assign(attendance, attendance),
my: Object.assign(my, my),
}

export default api