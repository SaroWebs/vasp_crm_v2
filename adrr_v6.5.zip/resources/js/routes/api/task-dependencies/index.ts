import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskDependencyController::index
 * @see app/Http/Controllers/TaskDependencyController.php:15
 * @route '/task-dependencies'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/task-dependencies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskDependencyController::index
 * @see app/Http/Controllers/TaskDependencyController.php:15
 * @route '/task-dependencies'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskDependencyController::index
 * @see app/Http/Controllers/TaskDependencyController.php:15
 * @route '/task-dependencies'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskDependencyController::index
 * @see app/Http/Controllers/TaskDependencyController.php:15
 * @route '/task-dependencies'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskDependencyController::index
 * @see app/Http/Controllers/TaskDependencyController.php:15
 * @route '/task-dependencies'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskDependencyController::index
 * @see app/Http/Controllers/TaskDependencyController.php:15
 * @route '/task-dependencies'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskDependencyController::index
 * @see app/Http/Controllers/TaskDependencyController.php:15
 * @route '/task-dependencies'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TaskDependencyController::store
 * @see app/Http/Controllers/TaskDependencyController.php:39
 * @route '/task-dependencies'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/task-dependencies',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskDependencyController::store
 * @see app/Http/Controllers/TaskDependencyController.php:39
 * @route '/task-dependencies'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskDependencyController::store
 * @see app/Http/Controllers/TaskDependencyController.php:39
 * @route '/task-dependencies'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskDependencyController::store
 * @see app/Http/Controllers/TaskDependencyController.php:39
 * @route '/task-dependencies'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskDependencyController::store
 * @see app/Http/Controllers/TaskDependencyController.php:39
 * @route '/task-dependencies'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TaskDependencyController::show
 * @see app/Http/Controllers/TaskDependencyController.php:57
 * @route '/task-dependencies/{taskDependency}'
 */
export const show = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/task-dependencies/{taskDependency}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskDependencyController::show
 * @see app/Http/Controllers/TaskDependencyController.php:57
 * @route '/task-dependencies/{taskDependency}'
 */
show.url = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskDependency: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { taskDependency: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    taskDependency: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskDependency: typeof args.taskDependency === 'object'
                ? args.taskDependency.id
                : args.taskDependency,
                }

    return show.definition.url
            .replace('{taskDependency}', parsedArgs.taskDependency.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskDependencyController::show
 * @see app/Http/Controllers/TaskDependencyController.php:57
 * @route '/task-dependencies/{taskDependency}'
 */
show.get = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskDependencyController::show
 * @see app/Http/Controllers/TaskDependencyController.php:57
 * @route '/task-dependencies/{taskDependency}'
 */
show.head = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskDependencyController::show
 * @see app/Http/Controllers/TaskDependencyController.php:57
 * @route '/task-dependencies/{taskDependency}'
 */
    const showForm = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskDependencyController::show
 * @see app/Http/Controllers/TaskDependencyController.php:57
 * @route '/task-dependencies/{taskDependency}'
 */
        showForm.get = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskDependencyController::show
 * @see app/Http/Controllers/TaskDependencyController.php:57
 * @route '/task-dependencies/{taskDependency}'
 */
        showForm.head = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\TaskDependencyController::update
 * @see app/Http/Controllers/TaskDependencyController.php:65
 * @route '/task-dependencies/{taskDependency}'
 */
export const update = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/task-dependencies/{taskDependency}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskDependencyController::update
 * @see app/Http/Controllers/TaskDependencyController.php:65
 * @route '/task-dependencies/{taskDependency}'
 */
update.url = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskDependency: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { taskDependency: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    taskDependency: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskDependency: typeof args.taskDependency === 'object'
                ? args.taskDependency.id
                : args.taskDependency,
                }

    return update.definition.url
            .replace('{taskDependency}', parsedArgs.taskDependency.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskDependencyController::update
 * @see app/Http/Controllers/TaskDependencyController.php:65
 * @route '/task-dependencies/{taskDependency}'
 */
update.patch = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskDependencyController::update
 * @see app/Http/Controllers/TaskDependencyController.php:65
 * @route '/task-dependencies/{taskDependency}'
 */
    const updateForm = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskDependencyController::update
 * @see app/Http/Controllers/TaskDependencyController.php:65
 * @route '/task-dependencies/{taskDependency}'
 */
        updateForm.patch = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TaskDependencyController::destroy
 * @see app/Http/Controllers/TaskDependencyController.php:81
 * @route '/task-dependencies/{taskDependency}'
 */
export const destroy = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/task-dependencies/{taskDependency}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TaskDependencyController::destroy
 * @see app/Http/Controllers/TaskDependencyController.php:81
 * @route '/task-dependencies/{taskDependency}'
 */
destroy.url = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskDependency: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { taskDependency: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    taskDependency: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskDependency: typeof args.taskDependency === 'object'
                ? args.taskDependency.id
                : args.taskDependency,
                }

    return destroy.definition.url
            .replace('{taskDependency}', parsedArgs.taskDependency.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskDependencyController::destroy
 * @see app/Http/Controllers/TaskDependencyController.php:81
 * @route '/task-dependencies/{taskDependency}'
 */
destroy.delete = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TaskDependencyController::destroy
 * @see app/Http/Controllers/TaskDependencyController.php:81
 * @route '/task-dependencies/{taskDependency}'
 */
    const destroyForm = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskDependencyController::destroy
 * @see app/Http/Controllers/TaskDependencyController.php:81
 * @route '/task-dependencies/{taskDependency}'
 */
        destroyForm.delete = (args: { taskDependency: number | { id: number } } | [taskDependency: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const taskDependencies = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
show: Object.assign(show, show),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default taskDependencies