import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskController::index
 * @see app/Http/Controllers/TaskController.php:1443
 * @route '/data/task-types'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/data/task-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::index
 * @see app/Http/Controllers/TaskController.php:1443
 * @route '/data/task-types'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::index
 * @see app/Http/Controllers/TaskController.php:1443
 * @route '/data/task-types'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::index
 * @see app/Http/Controllers/TaskController.php:1443
 * @route '/data/task-types'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::index
 * @see app/Http/Controllers/TaskController.php:1443
 * @route '/data/task-types'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::index
 * @see app/Http/Controllers/TaskController.php:1443
 * @route '/data/task-types'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::index
 * @see app/Http/Controllers/TaskController.php:1443
 * @route '/data/task-types'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TaskController::slaPolicies
 * @see app/Http/Controllers/TaskController.php:1466
 * @route '/data/task-types/{taskType}/sla-policies'
 */
export const slaPolicies = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: slaPolicies.url(args, options),
    method: 'get',
})

slaPolicies.definition = {
    methods: ["get","head"],
    url: '/data/task-types/{taskType}/sla-policies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::slaPolicies
 * @see app/Http/Controllers/TaskController.php:1466
 * @route '/data/task-types/{taskType}/sla-policies'
 */
slaPolicies.url = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskType: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    taskType: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskType: args.taskType,
                }

    return slaPolicies.definition.url
            .replace('{taskType}', parsedArgs.taskType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::slaPolicies
 * @see app/Http/Controllers/TaskController.php:1466
 * @route '/data/task-types/{taskType}/sla-policies'
 */
slaPolicies.get = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: slaPolicies.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::slaPolicies
 * @see app/Http/Controllers/TaskController.php:1466
 * @route '/data/task-types/{taskType}/sla-policies'
 */
slaPolicies.head = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: slaPolicies.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::slaPolicies
 * @see app/Http/Controllers/TaskController.php:1466
 * @route '/data/task-types/{taskType}/sla-policies'
 */
    const slaPoliciesForm = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: slaPolicies.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::slaPolicies
 * @see app/Http/Controllers/TaskController.php:1466
 * @route '/data/task-types/{taskType}/sla-policies'
 */
        slaPoliciesForm.get = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: slaPolicies.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::slaPolicies
 * @see app/Http/Controllers/TaskController.php:1466
 * @route '/data/task-types/{taskType}/sla-policies'
 */
        slaPoliciesForm.head = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: slaPolicies.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    slaPolicies.form = slaPoliciesForm
const taskTypes = {
    index: Object.assign(index, index),
slaPolicies: Object.assign(slaPolicies, slaPolicies),
}

export default taskTypes