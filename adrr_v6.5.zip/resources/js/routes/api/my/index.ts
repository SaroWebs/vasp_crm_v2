import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import attendanceC12b95 from './attendance'
/**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:465
 * @route '/api/my/attendance'
 */
export const attendance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendance.url(options),
    method: 'get',
})

attendance.definition = {
    methods: ["get","head"],
    url: '/api/my/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:465
 * @route '/api/my/attendance'
 */
attendance.url = (options?: RouteQueryOptions) => {
    return attendance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:465
 * @route '/api/my/attendance'
 */
attendance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendance.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:465
 * @route '/api/my/attendance'
 */
attendance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: attendance.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:465
 * @route '/api/my/attendance'
 */
    const attendanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: attendance.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:465
 * @route '/api/my/attendance'
 */
        attendanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendance.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttendanceController::attendance
 * @see app/Http/Controllers/AttendanceController.php:465
 * @route '/api/my/attendance'
 */
        attendanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendance.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    attendance.form = attendanceForm
const my = {
    attendance: Object.assign(attendance, attendanceC12b95),
}

export default my