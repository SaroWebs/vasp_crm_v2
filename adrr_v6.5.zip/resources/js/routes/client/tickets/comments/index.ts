import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::index
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:21
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
export const index = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/c/{client}/tickets/{ticket}/comments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::index
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:21
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
index.url = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    ticket: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                                ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return index.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::index
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:21
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
index.get = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::index
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:21
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
index.head = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::index
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:21
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
    const indexForm = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::index
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:21
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
        indexForm.get = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::index
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:21
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
        indexForm.head = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::store
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:61
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
export const store = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/c/{client}/tickets/{ticket}/comments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::store
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:61
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
store.url = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    ticket: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                                ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::store
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:61
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
store.post = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::store
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:61
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
    const storeForm = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::store
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:61
 * @route '/c/{client}/tickets/{ticket}/comments'
 */
        storeForm.post = (args: { client: string | { code: string }, ticket: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::update
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:123
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
export const update = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/c/{client}/tickets/{ticket}/comments/{comment}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::update
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:123
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
update.url = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    ticket: args[1],
                    comment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                                ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::update
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:123
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
update.patch = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::update
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:123
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
    const updateForm = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::update
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:123
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
        updateForm.patch = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::destroy
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:165
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
export const destroy = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/c/{client}/tickets/{ticket}/comments/{comment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::destroy
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:165
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
destroy.url = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    ticket: args[1],
                    comment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.code
                : args.client,
                                ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                comment: typeof args.comment === 'object'
                ? args.comment.id
                : args.comment,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{comment}', parsedArgs.comment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::destroy
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:165
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
destroy.delete = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::destroy
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:165
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
    const destroyForm = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Client\ClientTicketCommentController::destroy
 * @see app/Http/Controllers/Client/ClientTicketCommentController.php:165
 * @route '/c/{client}/tickets/{ticket}/comments/{comment}'
 */
        destroyForm.delete = (args: { client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } } | [client: string | { code: string }, ticket: number | { id: number }, comment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const comments = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default comments