import tasks from './tasks'
const data = {
    tasks: Object.assign(tasks, tasks),
}

export default data