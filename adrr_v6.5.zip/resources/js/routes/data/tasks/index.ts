import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:510
 * @route '/data/my/tasks'
 */
export const my = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})

my.definition = {
    methods: ["get","head"],
    url: '/data/my/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:510
 * @route '/data/my/tasks'
 */
my.url = (options?: RouteQueryOptions) => {
    return my.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:510
 * @route '/data/my/tasks'
 */
my.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:510
 * @route '/data/my/tasks'
 */
my.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: my.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:510
 * @route '/data/my/tasks'
 */
    const myForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: my.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:510
 * @route '/data/my/tasks'
 */
        myForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::my
 * @see app/Http/Controllers/TaskController.php:510
 * @route '/data/my/tasks'
 */
        myForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    my.form = myForm
/**
* @see \App\Http\Controllers\TaskController::all
 * @see app/Http/Controllers/TaskController.php:408
 * @route '/data/all/tasks'
 */
export const all = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(options),
    method: 'get',
})

all.definition = {
    methods: ["get","head"],
    url: '/data/all/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::all
 * @see app/Http/Controllers/TaskController.php:408
 * @route '/data/all/tasks'
 */
all.url = (options?: RouteQueryOptions) => {
    return all.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::all
 * @see app/Http/Controllers/TaskController.php:408
 * @route '/data/all/tasks'
 */
all.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::all
 * @see app/Http/Controllers/TaskController.php:408
 * @route '/data/all/tasks'
 */
all.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: all.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::all
 * @see app/Http/Controllers/TaskController.php:408
 * @route '/data/all/tasks'
 */
    const allForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: all.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::all
 * @see app/Http/Controllers/TaskController.php:408
 * @route '/data/all/tasks'
 */
        allForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: all.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::all
 * @see app/Http/Controllers/TaskController.php:408
 * @route '/data/all/tasks'
 */
        allForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: all.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    all.form = allForm
/**
* @see \App\Http\Controllers\UserTaskController::board
 * @see app/Http/Controllers/UserTaskController.php:184
 * @route '/data/my/board-tasks'
 */
export const board = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: board.url(options),
    method: 'get',
})

board.definition = {
    methods: ["get","head"],
    url: '/data/my/board-tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserTaskController::board
 * @see app/Http/Controllers/UserTaskController.php:184
 * @route '/data/my/board-tasks'
 */
board.url = (options?: RouteQueryOptions) => {
    return board.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserTaskController::board
 * @see app/Http/Controllers/UserTaskController.php:184
 * @route '/data/my/board-tasks'
 */
board.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: board.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserTaskController::board
 * @see app/Http/Controllers/UserTaskController.php:184
 * @route '/data/my/board-tasks'
 */
board.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: board.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserTaskController::board
 * @see app/Http/Controllers/UserTaskController.php:184
 * @route '/data/my/board-tasks'
 */
    const boardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: board.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserTaskController::board
 * @see app/Http/Controllers/UserTaskController.php:184
 * @route '/data/my/board-tasks'
 */
        boardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: board.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserTaskController::board
 * @see app/Http/Controllers/UserTaskController.php:184
 * @route '/data/my/board-tasks'
 */
        boardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: board.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    board.form = boardForm
const tasks = {
    my: Object.assign(my, my),
all: Object.assign(all, all),
board: Object.assign(board, board),
}

export default tasks