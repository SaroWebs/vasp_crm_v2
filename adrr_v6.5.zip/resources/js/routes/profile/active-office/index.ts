import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\EmployeeOfficeController::update
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/settings/active-office',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\EmployeeOfficeController::update
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeOfficeController::update
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\EmployeeOfficeController::update
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\EmployeeOfficeController::update
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const activeOffice = {
    update: Object.assign(update, update),
}

export default activeOffice