<?php

namespace App\Services;

use App\Models\Attendance;
use App\Models\Client;
use App\Models\Department;
use App\Models\Notification;
use App\Models\Product;
use App\Models\Report;
use App\Models\Task;
use App\Models\TaskAuditEvent;
use App\Models\TaskForwarding;
use App\Models\TaskTimeEntry;
use App\Models\Ticket;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Carbon;

class DashboardService
{
    private const TASK_STATES_PENDING = ['Draft', 'Assigned', 'Blocked'];

    private const TASK_STATES_IN_PROGRESS = ['InProgress', 'InReview'];

    private const TASK_STATES_COMPLETED = ['Done', 'Cancelled', 'Rejected'];

    /**
     * Get dashboard data based on user role.
     */
    public function getDashboardData(User $user): array
    {
        // Admin roles: full system access
        if ($user->hasRole(['super-admin', 'admin'])) {
            return $this->getAdminDashboard($user);
        }

        // Managerial roles: department/team oversight
        if ($user->hasRole(['manager', 'team-lead', 'hr'])) {
            return $this->getManagerDashboard($user);
        }

        // Employee roles: individual contributors
        if ($user->hasRole(['developer', 'support-agent', 'employee', 'sales'])) {
            return $this->getEmployeeDashboard($user);
        }

        // Default fallback to employee dashboard
        return $this->getEmployeeDashboard($user);
    }

    /**
     * Get admin dashboard data (system-wide overview).
     */
    public function getAdminDashboard(User $user): array
    {
        return [
            'dashboard_type' => 'admin',
            'stats' => $this->getAdminStats(),
            'recentTickets' => $this->getRecentTickets(),
            'recentTasks' => $this->getRecentTasks(),
            'departmentStats' => $this->getDepartmentStats(),
            'ticketStats' => $this->getTicketStats(),
            'taskStats' => $this->getTaskStats(),
            'employeeProgress' => $this->getEmployeeProgress(),
            'employees' => $this->getEmployees(),
            'unreadNotifications' => $this->getUnreadNotifications($user),
        ];
    }

    /**
     * Get manager/department head dashboard data.
     */
    public function getManagerDashboard(User $user): array
    {
        $departmentIds = $this->getUserDepartmentIds($user);

        return [
            'dashboard_type' => 'manager',
            'stats' => $this->getManagerStats($user, $departmentIds),
            'myDepartmentTasks' => $this->getDepartmentTasks($departmentIds),
            'teamWorkload' => $this->getTeamWorkload($departmentIds),
            'recentTasks' => $this->getRecentTasksForDepartments($departmentIds),
            'departmentStats' => $this->getDepartmentStatsForManager($departmentIds),
            'unreadNotifications' => $this->getUnreadNotifications($user),
            'unreadNotificationsList' => $this->getUnreadNotificationsList($user),
        ];
    }

    /**
     * Get employee dashboard data (personal tasks).
     */
    public function getEmployeeDashboard(User $user): array
    {
        return [
            'dashboard_type' => 'employee',
            'stats' => $this->getEmployeeStats($user),
            'myTasks' => $this->getMyTasks($user),
            'myTaskStats' => $this->getMyTaskStats($user),
            'forwardedTasks' => $this->getForwardedTasks($user),
            'upcomingDeadlines' => $this->getUpcomingDeadlines($user),
            'recentTimeEntries' => $this->getRecentTimeEntries($user),
            'timeSpentChartData' => $this->getTimeSpentChartData($user),
            'unreadNotifications' => $this->getUnreadNotifications($user),
            'unreadNotificationsList' => $this->getUnreadNotificationsList($user),
            'recentTickets' => $this->getRecentTickets(),
        ];
    }

    /**
     * Get admin-level statistics.
     */
    public function getAdminStats(): array
    {
        $ticketStats = $this->getTicketDashboardCounts();
        $taskStats = $this->getTaskDashboardCounts(Task::withTrashed());
        $visibleTaskStats = $this->getTaskDashboardCounts(Task::query());

        return [
            'total_departments' => Department::active()->count(),
            'total_users' => User::count(),
            'total_clients' => Client::where('status', 'active')->count(),
            'total_products' => Product::where('status', 'active')->count(),
            'total_tickets' => $ticketStats['total'],
            'total_tasks' => $taskStats['total'],
            'open_tickets' => $ticketStats['open'],
            'tickets_closed_today' => $ticketStats['closed_today'],
            'pending_tasks' => $taskStats['pending'],
            'tasks_completed_today' => $taskStats['completed_today'],
            'active_users_today' => User::where('last_login_at', '>=', today())->count(),
            'tickets_created_today' => $ticketStats['created_today'],
            'ticket_status_distribution' => [
                'open' => $ticketStats['open'],
                'approved' => $ticketStats['approved'],
                'in_progress' => $ticketStats['in_progress'],
                'closed' => $ticketStats['closed'],
                'cancelled' => $ticketStats['cancelled'],
            ],
            'task_status_distribution' => [
                'pending' => $visibleTaskStats['pending'],
                'in_progress' => $visibleTaskStats['inprogress'],
                'waiting' => $visibleTaskStats['waiting'],
                'completed' => $visibleTaskStats['completed'],
            ],
        ];
    }

    /**
     * Get employee progress data for admin dashboard.
     */
    public function getEmployeeProgress(): array
    {
        $users = User::with('employee')->get();
        $employeeData = [];
        $totalTime = 0;
        $totalTasks = 0;

        /** @var User $user */
        foreach ($users as $user) {
            if ($user->employee) {
                $taskIds = $user->assignedTasks()->pluck('tasks.id');
                $timeEntries = TaskTimeEntry::whereIn('task_id', $taskIds)
                    ->whereMonth('created_at', now()->month)
                    ->get();

                $hours = $timeEntries->sum('hours');
                $minutes = $timeEntries->sum('minutes');
                $totalHours = $hours + ($minutes / 60);

                $employeeData[] = [
                    'user_id' => $user->id,
                    'user_name' => $user->name,
                    'total_time' => round($totalHours, 2),
                    'total_tasks' => $user->assignedTasks()->count(),
                ];

                $totalTime += $totalHours;
                $totalTasks += $user->assignedTasks()->count();
            }
        }

        $avgTimePerEmployee = count($employeeData) > 0 ? $totalTime / count($employeeData) : 0;

        return [
            'data' => $employeeData,
            'total_employees' => count($employeeData),
            'total_time' => round($totalTime, 2),
            'total_tasks' => $totalTasks,
            'avg_time_per_employee' => round($avgTimePerEmployee, 2),
        ];
    }

    /**
     * Get employees list for admin dashboard.
     */
    public function getEmployees(): array
    {
        return User::whereHas('employee', function ($query) {
            $query->assignable();
        })
            ->select('id', 'name', 'email')
            ->get()
            ->toArray();
    }

    /**
     * Get manager-level statistics.
     */
    public function getManagerStats(User $user, array $departmentIds): array
    {
        $departmentTasks = Task::withTrashed()->whereIn('assigned_department_id', $departmentIds);
        $userIds = Department::whereIn('id', $departmentIds)
            ->with('users')
            ->get()
            ->pluck('users.*.id')
            ->flatten()
            ->unique()
            ->toArray();

        return [
            'total_team_members' => count($userIds),
            'total_department_tasks' => (clone $departmentTasks)->count(),
            'pending_tasks' => (clone $departmentTasks)->whereIn('state', self::TASK_STATES_PENDING)->count(),
            'in_progress_tasks' => (clone $departmentTasks)->whereIn('state', self::TASK_STATES_IN_PROGRESS)->count(),
            'completed_tasks_this_month' => (clone $departmentTasks)->whereIn('state', self::TASK_STATES_COMPLETED)
                ->whereMonth('updated_at', now()->month)
                ->count(),
            'tasks_due_today' => (clone $departmentTasks)->whereDate('due_at', today())->count(),
            'tasks_due_this_week' => (clone $departmentTasks)->whereBetween('due_at', [now(), now()->addDays(7)])->count(),
            'overdue_tasks' => (clone $departmentTasks)->whereNotIn('state', self::TASK_STATES_COMPLETED)
                ->whereDate('due_at', '<', today())
                ->count(),
        ];
    }

    /**
     * Get employee-level statistics.
     */
    public function getEmployeeStats(User $user): array
    {
        $myTasks = Task::whereHas('assignedUsers', function ($query) use ($user) {
            $query->where('user_id', $user->id);
        });

        return [
            'total_my_tasks' => (clone $myTasks)->count(),
            'pending_tasks' => (clone $myTasks)->whereIn('state', self::TASK_STATES_PENDING)->count(),
            'in_progress_tasks' => (clone $myTasks)->where('state', 'InProgress')->count(),
            'waiting_tasks' => (clone $myTasks)->where('state', 'InReview')->count(),
            'completed_tasks' => (clone $myTasks)->whereIn('state', self::TASK_STATES_COMPLETED)->count(),
            'completed_this_month' => (clone $myTasks)->whereIn('state', self::TASK_STATES_COMPLETED)
                ->whereMonth('updated_at', now()->month)
                ->count(),
            'tasks_due_today' => (clone $myTasks)->whereDate('due_at', today())->count(),
            'tasks_due_this_week' => (clone $myTasks)->whereBetween('due_at', [now(), now()->addDays(7)])->count(),
            'overdue_tasks' => (clone $myTasks)->whereNotIn('state', self::TASK_STATES_COMPLETED)
                ->whereDate('due_at', '<', today())
                ->count(),
            'forwarded_tasks_count' => TaskForwarding::where('to_user_id', $user->id)
                ->where('status', 'pending')
                ->count(),
        ];
    }

    /**
     * Get recent tickets (admin view).
     */
    public function getRecentTickets()
    {
        return Ticket::with(['client', 'organizationUser', 'assignedTo'])
            ->latest('created_at')
            ->limit(10)
            ->get()
            ->map(function ($ticket) {
                return [
                    'id' => $ticket->id,
                    'ticket_number' => $ticket->ticket_number,
                    'subject' => $ticket->subject ?? $ticket->title,
                    'status' => $ticket->status,
                    'priority' => $ticket->priority,
                    'client' => $ticket->client?->name,
                    'assigned_to' => $ticket->assignedTo
                        ? [
                            'id' => $ticket->assignedTo->id,
                            'name' => $ticket->assignedTo->name,
                        ]
                        : null,
                    'created_at' => $ticket->created_at->toISOString(),
                ];
            });
    }

    /**
     * Get recent tasks (admin view).
     */
    public function getRecentTasks()
    {
        return Task::with(['ticket', 'assignedDepartment', 'assignedUsers'])
            ->latest('created_at')
            ->limit(10)
            ->get()
            ->map(function ($task) {
                return [
                    'id' => $task->id,
                    'title' => $task->title,
                    'status' => $task->state,
                    'priority' => $task->priority,
                    'department' => $task->assignedDepartment?->name,
                    'assigned_users' => $task->assignedUsers->pluck('name'),
                    'due_date' => $task->due_at?->toISOString(),
                    'created_at' => $task->created_at->toISOString(),
                ];
            });
    }

    /**
     * Get department statistics (admin view).
     */
    public function getDepartmentStats()
    {
        return Department::active()
            ->withCount([
                'users',
                'assignedTasks as pending_tasks_count' => function ($query) {
                    $query->where('state', '!=', 'Done');
                },
            ])
            ->get()
            ->map(function ($department) {
                return [
                    'id' => $department->id,
                    'name' => $department->name,
                    'user_count' => $department->users_count,
                    'pending_tasks' => $department->pending_tasks_count,
                    'completed_this_month' => $department->assignedTasks()
                        ->whereMonth('updated_at', now()->month)
                        ->where('state', 'Done')
                        ->count(),
                ];
            });
    }

    /**
     * Get ticket status distribution.
     */
    public function getTicketStats(): array
    {
        $ticketStats = $this->getTicketDashboardCounts();

        return [
            'open' => $ticketStats['open'],
            'approved' => $ticketStats['approved'],
            'in_progress' => $ticketStats['in_progress'],
            'closed' => $ticketStats['closed'],
            'cancelled' => $ticketStats['cancelled'],
        ];
    }

    /**
     * Get task status distribution.
     */
    public function getTaskStats(): array
    {
        $taskStats = $this->getTaskDashboardCounts(Task::query());

        return [
            'pending' => $taskStats['pending'],
            'in_progress' => $taskStats['inprogress'],
            'waiting' => $taskStats['waiting'],
            'completed' => $taskStats['completed'],
        ];
    }

    /**
     * @return array{total:int,open:int,approved:int,in_progress:int,closed:int,cancelled:int,closed_today:int,created_today:int}
     */
    private function getTicketDashboardCounts(): array
    {
        $todayStart = today();
        $tomorrowStart = today()->addDay();

        $counts = Ticket::query()
            ->selectRaw(
                <<<'SQL'
                COUNT(*) as total,
                SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as open,
                SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as closed,
                SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as cancelled,
                SUM(CASE WHEN status = ? AND updated_at >= ? AND updated_at < ? THEN 1 ELSE 0 END) as closed_today,
                SUM(CASE WHEN created_at >= ? AND created_at < ? THEN 1 ELSE 0 END) as created_today
                SQL,
                [
                    'open',
                    'approved',
                    'in-progress',
                    'closed',
                    'cancelled',
                    'closed',
                    $todayStart,
                    $tomorrowStart,
                    $todayStart,
                    $tomorrowStart,
                ]
            )
            ->first();

        return [
            'total' => (int) ($counts->total ?? 0),
            'open' => (int) ($counts->open ?? 0),
            'approved' => (int) ($counts->approved ?? 0),
            'in_progress' => (int) ($counts->in_progress ?? 0),
            'closed' => (int) ($counts->closed ?? 0),
            'cancelled' => (int) ($counts->cancelled ?? 0),
            'closed_today' => (int) ($counts->closed_today ?? 0),
            'created_today' => (int) ($counts->created_today ?? 0),
        ];
    }

    /**
     * @return array{total:int,pending:int,inprogress:int,waiting:int,completed:int,completed_today:int}
     */
    private function getTaskDashboardCounts(Builder $query): array
    {
        $todayStart = today();
        $tomorrowStart = today()->addDay();

        $counts = (clone $query)
            ->selectRaw(
                <<<'SQL'
                COUNT(*) as total,
                SUM(CASE WHEN state IN (?, ?, ?) THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN state IN (?, ?) THEN 1 ELSE 0 END) as inprogress,
                SUM(CASE WHEN state = ? THEN 1 ELSE 0 END) as waiting,
                SUM(CASE WHEN state IN (?, ?, ?) THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN state IN (?, ?, ?) AND updated_at >= ? AND updated_at < ? THEN 1 ELSE 0 END) as completed_today
                SQL,
                [
                    ...self::TASK_STATES_PENDING,
                    ...self::TASK_STATES_IN_PROGRESS,
                    'InReview',
                    ...self::TASK_STATES_COMPLETED,
                    ...self::TASK_STATES_COMPLETED,
                    $todayStart,
                    $tomorrowStart,
                ]
            )
            ->first();

        return [
            'total' => (int) ($counts->total ?? 0),
            'pending' => (int) ($counts->pending ?? 0),
            'inprogress' => (int) ($counts->inprogress ?? 0),
            'waiting' => (int) ($counts->waiting ?? 0),
            'completed' => (int) ($counts->completed ?? 0),
            'completed_today' => (int) ($counts->completed_today ?? 0),
        ];
    }

    /**
     * Get unread notifications count for a user.
     */
    public function getUnreadNotifications(User $user): int
    {
        return Notification::getUnreadCountForUser($user->id);
    }

    /**
     * Get unread notifications list for a user.
     */
    public function getUnreadNotificationsList(User $user)
    {
        return Notification::whereHas('users', function ($query) use ($user) {
            $query->where('user_id', $user->id)
                ->where('users_notifications.read', false);
        })
            ->with([
                'users' => function ($query) use ($user) {
                    $query->where('user_id', $user->id);
                },
            ])
            ->latest()
            ->limit(10)
            ->get()
            ->map(function ($notification) {
                return [
                    'id' => $notification->id,
                    'type' => $notification->type,
                    'title' => $notification->title,
                    'message' => $notification->message,
                    'created_at' => $notification->created_at->toISOString(),
                ];
            });
    }

    /**
     * Get user's department IDs.
     */
    public function getUserDepartmentIds(User $user): array
    {
        return $user->departmentUsers()
            ->pluck('department_id')
            ->toArray();
    }

    /**
     * Get tasks for specific departments.
     */
    public function getDepartmentTasks(array $departmentIds)
    {
        return Task::whereIn('assigned_department_id', $departmentIds)
            ->where('state', '!=', 'Done')
            ->with(['assignedDepartment', 'assignedUsers'])
            ->latest('created_at')
            ->limit(10)
            ->get()
            ->map(function ($task) {
                return [
                    'id' => $task->id,
                    'title' => $task->title,
                    'status' => $task->state,
                    'priority' => $task->priority,
                    'department' => $task->assignedDepartment?->name,
                    'assigned_users' => $task->assignedUsers->pluck('name'),
                    'due_date' => $task->due_at?->toISOString(),
                ];
            });
    }

    /**
     * Get team workload (tasks per user in departments).
     */
    public function getTeamWorkload(array $departmentIds)
    {
        $userIds = Department::whereIn('id', $departmentIds)
            ->with('users')
            ->get()
            ->pluck('users.*.id')
            ->flatten()
            ->unique()
            ->toArray();

        $tasksByUser = Task::whereIn('assigned_department_id', $departmentIds)
            ->where('state', '!=', 'Done')
            ->get()
            ->groupBy(function ($task) {
                return $task->assignedUsers->pluck('id')->first();
            });

        $workload = [];
        foreach ($userIds as $userId) {
            $user = User::find($userId);
            if ($user) {
                $taskCount = $tasksByUser->get($userId)?->count() ?? 0;
                $workload[] = [
                    'user_id' => $user->id,
                    'name' => $user->name,
                    'task_count' => $taskCount,
                    'status' => $taskCount > 10 ? 'overloaded' : ($taskCount > 5 ? 'busy' : 'available'),
                ];
            }
        }

        return $workload;
    }

    /**
     * Get recent tasks for departments.
     */
    public function getRecentTasksForDepartments(array $departmentIds)
    {
        return Task::whereIn('assigned_department_id', $departmentIds)
            ->with(['assignedDepartment', 'assignedUsers'])
            ->latest('created_at')
            ->limit(10)
            ->get()
            ->map(function ($task) {
                return [
                    'id' => $task->id,
                    'title' => $task->title,
                    'status' => $task->state,
                    'priority' => $task->priority,
                    'department' => $task->assignedDepartment?->name,
                    'assigned_users' => $task->assignedUsers->pluck('name'),
                    'due_date' => $task->due_at?->toISOString(),
                ];
            });
    }

    /**
     * Get department stats for manager view.
     */
    public function getDepartmentStatsForManager(array $departmentIds)
    {
        return Department::whereIn('id', $departmentIds)
            ->active()
            ->withCount([
                'users',
                'assignedTasks as pending_tasks_count' => function ($query) {
                    $query->where('state', '!=', 'Done');
                },
            ])
            ->get()
            ->map(function ($department) {
                return [
                    'id' => $department->id,
                    'name' => $department->name,
                    'user_count' => $department->users_count,
                    'pending_tasks' => $department->pending_tasks_count,
                    'completed_this_month' => $department->assignedTasks()
                        ->whereMonth('updated_at', now()->month)
                        ->where('state', 'Done')
                        ->count(),
                ];
            });
    }

    /**
     * Get user's personal tasks.
     */
    public function getMyTasks(User $user)
    {
        return Task::whereHas('assignedUsers', function ($query) use ($user) {
            $query->where('user_id', $user->id);
        })
            ->with(['assignedDepartment'])
            ->latest('created_at')
            ->limit(10)
            ->get()
            ->map(function ($task) {
                return [
                    'id' => $task->id,
                    'title' => $task->title,
                    'status' => $task->state,
                    'priority' => $task->priority,
                    'department' => $task->assignedDepartment?->name,
                    'due_date' => $task->due_at?->toISOString(),
                    'created_at' => $task->created_at->toISOString(),
                ];
            });
    }

    /**
     * Get user's task statistics.
     */
    public function getMyTaskStats(User $user): array
    {
        $myTasks = Task::whereHas('assignedUsers', function ($query) use ($user) {
            $query->where('user_id', $user->id);
        });

        return [
            'pending' => $myTasks->where('state', 'Draft')->count(),
            'in_progress' => $myTasks->where('state', 'InProgress')->count(),
            'waiting' => $myTasks->where('state', 'InReview')->count(),
            'completed' => $myTasks->where('state', 'Done')->count(),
        ];
    }

    /**
     * Get tasks forwarded to user.
     */
    public function getForwardedTasks(User $user)
    {
        return TaskForwarding::where('to_user_id', $user->id)
            ->where('status', 'pending')
            ->with(['task.assignedDepartment'])
            ->latest('forwarded_at')
            ->limit(10)
            ->get()
            ->map(function ($forwarding) {
                return [
                    'id' => $forwarding->id,
                    'task_id' => $forwarding->task_id,
                    'task_title' => $forwarding->task?->title,
                    'from_user' => $forwarding->fromUser?->name,
                    'from_department' => $forwarding->fromDepartment?->name,
                    'forwarded_at' => $forwarding->forwarded_at?->toISOString(),
                    'remarks' => $forwarding->remarks,
                ];
            });
    }

    /**
     * Get upcoming deadlines for user's tasks.
     */
    public function getUpcomingDeadlines(User $user)
    {
        return Task::whereHas('assignedUsers', function ($query) use ($user) {
            $query->where('user_id', $user->id);
        })
            ->where('state', '!=', 'Done')
            ->whereDate('due_at', '>=', today())
            ->whereDate('due_at', '<=', now()->addDays(7))
            ->orderBy('due_at')
            ->limit(10)
            ->get()
            ->map(function ($task) {
                return [
                    'id' => $task->id,
                    'title' => $task->title,
                    'status' => $task->state,
                    'priority' => $task->priority,
                    'due_date' => $task->due_at?->toISOString(),
                    'is_overdue' => $task->due_at?->isPast() ?? false,
                ];
            });
    }

    /**
     * Get recent activities for user (unified polymorphic stream).
     */
    public function getRecentActivities(User $user)
    {
        $activities = collect();

        // 1. Task Audit Events
        $taskEvents = TaskAuditEvent::with('task')
            ->where('actor_user_id', $user->id)
            ->whereIn('action', ['CREATE', 'ASSIGN', 'COMPLETE', 'FORWARD', 'COMMENT_ADD', 'STATE_CHANGE'])
            ->latest('occurred_at')
            ->limit(10)
            ->get()
            ->map(function ($event) {
                $title = 'Task Event';
                $description = $event->description;
                $icon = 'Activity';
                $link = $event->task_id ? "/admin/tasks/{$event->task_id}" : null;

                if ($event->action === 'CREATE') {
                    $title = 'Task Created';
                    $description = "Created task '{$event->task?->title}'";
                    $icon = 'PlusCircle';
                } elseif ($event->action === 'COMPLETE') {
                    $title = 'Task Completed';
                    $description = "Completed task '{$event->task?->title}'";
                    $icon = 'CheckCircle';
                } elseif ($event->action === 'ASSIGN') {
                    $title = 'Task Assigned';
                    $description = "Assigned to task '{$event->task?->title}'";
                    $icon = 'UserPlus';
                } elseif ($event->action === 'FORWARD') {
                    $title = 'Task Forwarded';
                    $description = "Forwarded task '{$event->task?->title}'";
                    $icon = 'ArrowRight';
                } elseif ($event->action === 'COMMENT_ADD') {
                    $title = 'Comment Added';
                    $description = "Commented on '{$event->task?->title}'";
                    $icon = 'MessageSquare';
                } elseif ($event->action === 'STATE_CHANGE') {
                    $title = 'Status Updated';
                    $description = "Updated status of '{$event->task?->title}' to {$event->to_state}";
                    $icon = 'RefreshCcw';
                }

                return [
                    'id' => 'task_event_'.$event->id,
                    'type' => 'task_event',
                    'title' => $title,
                    'description' => $description,
                    'timestamp' => $event->occurred_at,
                    'icon' => $icon,
                    'link' => $link,
                ];
            });

        $activities = $activities->concat($taskEvents);

        // 2. Attendance Punches
        if ($user->employee) {
            $punches = Attendance::where('employee_id', $user->employee->id)
                ->latest('created_at')
                ->limit(10)
                ->get();

            foreach ($punches as $punch) {
                if ($punch->punch_in) {
                    $activities->push([
                        'id' => 'punch_in_'.$punch->id,
                        'type' => 'punch_in',
                        'title' => 'Punched In',
                        'description' => 'Punched in for work',
                        'timestamp' => $punch->punch_in,
                        'icon' => 'Clock',
                        'link' => null,
                    ]);
                }
                if ($punch->punch_out) {
                    $activities->push([
                        'id' => 'punch_out_'.$punch->id,
                        'type' => 'punch_out',
                        'title' => 'Punched Out',
                        'description' => 'Punched out from work',
                        'timestamp' => $punch->punch_out,
                        'icon' => 'LogOut',
                        'link' => null,
                    ]);
                }
            }
        }

        // Sort by timestamp descending and take top 10
        return $activities->sortByDesc('timestamp')->values()->take(10)->map(function ($activity) {
            $activity['timestamp'] = Carbon::parse($activity['timestamp'])->toISOString();

            return $activity;
        })->toArray();
    }

    /**
     * Get daily time spent chart data for the current user with pagination.
     */
    public function getPaginatedChartData(User $user, string $range, int $offset): array
    {
        $days = $range === 'monthly' ? 30 : 7;

        // End date for the calculation (offset moves the window back in time)
        $baseEndDate = Carbon::now()->subDays($offset * $days);

        $rangeEnd = (clone $baseEndDate)->endOfDay();
        $rangeStart = (clone $baseEndDate)->subDays($days - 1)->startOfDay();

        $timeEntries = TaskTimeEntry::where('user_id', $user->id)
            ->where(function ($query) use ($rangeStart, $rangeEnd) {
                $query->whereBetween('start_time', [$rangeStart, $rangeEnd])
                    ->orWhereBetween('end_time', [$rangeStart, $rangeEnd])
                    ->orWhere(function ($query) use ($rangeStart, $rangeEnd) {
                        $query->where('start_time', '<', $rangeStart)
                            ->where('end_time', '>', $rangeEnd);
                    });
            })
            ->get();

        $series = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = (clone $baseEndDate)->subDays($i)->startOfDay();
            $series[] = [
                'label' => $range === 'weekly' ? $date->format('D') : $date->format('M j'),
                'date' => $date->toDateString(),
                'hours' => round($this->calculateTotalHoursForDate($timeEntries, $date->toDateString()), 2),
            ];
        }

        return $series;
    }

    private function calculateTotalHoursForDate($timeEntries, string $date): float
    {
        $totalSeconds = 0;

        foreach ($timeEntries as $entry) {
            $totalSeconds += $entry->calculateDurationForDate($date, Carbon::parse($date)->endOfDay());
        }

        return $totalSeconds / 3600;
    }

    /**
     * Get recent reports for a user.
     */
    public function getRecentReports(User $user, int $limit = 5): array
    {
        return Report::where('user_id', $user->id)
            ->latest()
            ->limit($limit)
            ->get()
            ->toArray();
    }
}
