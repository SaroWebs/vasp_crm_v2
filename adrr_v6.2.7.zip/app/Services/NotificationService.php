<?php

namespace App\Services;

use App\Events\NotificationEvent;
use App\Events\TaskAssignedNotificationEvent;
use App\Events\TaskForwardedNotificationEvent;
use App\Events\TaskStatusChangedNotificationEvent;
use App\Models\Department;
use App\Models\Notification;
use App\Models\Report;
use App\Models\Task;
use App\Models\TaskComment;
use App\Models\Ticket;
use App\Models\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Log;

class NotificationService
{
    /**
     * Send a notification to a specific user.
     */
    public function sendToUser(int $userId, string $type, string $title, string $message, array $data = []): Notification
    {
        $notification = Notification::createWorkflowNotification($userId, $type, $title, $message, $data);

        // Broadcast the notification
        $this->broadcastNotification($notification, $userId);

        return $notification;
    }

    /**
     * Broadcast notification.
     */
    protected function broadcastNotification(Notification $notification, int $userId): bool
    {
        return $this->broadcastEvent(
            new NotificationEvent($notification, $userId),
            'general_notification',
            [
                'notification_id' => $notification->id,
                'user_id' => $userId,
            ]
        );
    }

    /**
     * Broadcast an event and log the outcome.
     */
    protected function broadcastEvent(object $event, string $context, array $contextData = []): bool
    {
        $logContext = array_merge([
            'context' => $context,
            'event_class' => $event::class,
        ], $contextData);

        try {
            Log::debug('Broadcasting notification event', $logContext);
            broadcast($event)->toOthers();

            return true;
        } catch (\Throwable $e) {
            Log::error('Failed to broadcast notification event', $logContext + [
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * Send notifications to multiple users.
     */
    public function sendToUsers(array $userIds, string $type, string $title, string $message, array $data = []): array
    {
        return Notification::notifyUsers($userIds, $type, $title, $message, $data);
    }

    /**
     * Send notification to department users.
     */
    public function sendToDepartment(int $departmentId, string $type, string $title, string $message, array $data = []): array
    {
        return Notification::notifyUsers(
            Department::find($departmentId)->users()->pluck('id')->toArray(),
            $type,
            $title,
            $message,
            $data
        );
    }

    /**
     * Send notification to department managers.
     */
    public function sendToDepartmentManagers(int $departmentId, string $type, string $title, string $message, array $data = []): array
    {
        return Notification::notifyUsers(
            Department::find($departmentId)->getManagers()->pluck('id')->toArray(),
            $type,
            $title,
            $message,
            $data
        );
    }

    /**
     * Send task assignment notification.
     */
    public function sendTaskAssignmentNotification(int $taskId, int $assignedUserId, string $taskTitle, int $assignedByUserId): Notification
    {
        $assignedUser = User::find($assignedUserId);
        $assignedByUser = User::find($assignedByUserId);

        $notification = $this->sendToUser(
            $assignedUserId,
            'App\Notifications\TaskAssignedNotification',
            'Task Assigned',
            "You have been assigned to task: {$taskTitle}",
            [
                'task_id' => $taskId,
                'task_title' => $taskTitle,
                'assigned_by_id' => $assignedByUserId,
                'assigned_by_name' => $assignedByUser->name ?? 'System',
            ]
        );

        // Broadcast using specific task assignment event
        $this->broadcastEvent(
            new TaskAssignedNotificationEvent($notification, $assignedUserId),
            'task_assignment',
            [
                'notification_id' => $notification->id,
                'task_id' => $taskId,
                'user_id' => $assignedUserId,
            ]
        );

        return $notification;
    }

    /**
     * Send task status change notification.
     */
    public function sendTaskStatusChangeNotification(int $taskId, string $taskTitle, string $newStatus, int $changedByUserId): Notification
    {
        $task = Task::find($taskId);
        $changedByUser = User::find($changedByUserId);

        // Notify task assignee
        $notifications = [];
        if ($task->assigned_to) {
            $notification = $this->sendToUser(
                $task->assigned_to,
                'App\Notifications\TaskStatusChangedNotification',
                'Task Status Updated',
                "Task '{$taskTitle}' status changed to: {$newStatus}",
                [
                    'task_id' => $taskId,
                    'task_title' => $taskTitle,
                    'new_status' => $newStatus,
                    'changed_by_id' => $changedByUserId,
                    'changed_by_name' => $changedByUser->name ?? 'System',
                ]
            );

            // Broadcast using specific task status change event
            $this->broadcastEvent(
                new TaskStatusChangedNotificationEvent($notification, $task->assigned_to),
                'task_status_change',
                [
                    'notification_id' => $notification->id,
                    'task_id' => $taskId,
                    'user_id' => $task->assigned_to,
                ]
            );

            $notifications[] = $notification;
        }

        // Notify department users if assigned to department
        if ($task->assigned_department_id) {
            $departmentNotifications = $this->sendToDepartment(
                $task->assigned_department_id,
                'App\Notifications\TaskStatusChangedNotification',
                'Task Status Updated',
                "Task '{$taskTitle}' status changed to: {$newStatus}",
                [
                    'task_id' => $taskId,
                    'task_title' => $taskTitle,
                    'new_status' => $newStatus,
                    'changed_by_id' => $changedByUserId,
                    'changed_by_name' => $changedByUser->name ?? 'System',
                ]
            );

            // Broadcast to department users
            $departmentUserIds = Department::find($task->assigned_department_id)->users()->pluck('id')->toArray();
            foreach ($departmentUserIds as $userId) {
                $this->broadcastEvent(
                    new TaskStatusChangedNotificationEvent($departmentNotifications[0], $userId),
                    'task_status_change_department',
                    [
                        'notification_id' => $departmentNotifications[0]->id,
                        'task_id' => $taskId,
                        'user_id' => $userId,
                    ]
                );
            }

            $notifications = array_merge($notifications, $departmentNotifications);
        }

        return $notifications[0] ?? null;
    }

    /**
     * Send task forwarding notification.
     */
    public function sendTaskForwardingNotification(int $taskId, int $fromDepartmentId, int $toDepartmentId, string $reason, int $forwardedByUserId): array
    {
        $task = Task::find($taskId);
        $forwardedByUser = User::find($forwardedByUserId);
        $fromDepartment = Department::find($fromDepartmentId);
        $toDepartment = Department::find($toDepartmentId);

        $notifications = [];

        // Notify target department users
        $departmentNotifications = $this->sendToDepartment(
            $toDepartmentId,
            'App\Notifications\TaskForwardedNotification',
            'Task Forwarded to Your Department',
            "Task '{$task->title}' has been forwarded from {$fromDepartment->name} to {$toDepartment->name}",
            [
                'task_id' => $taskId,
                'task_title' => $task->title,
                'from_department_id' => $fromDepartmentId,
                'from_department_name' => $fromDepartment->name,
                'to_department_id' => $toDepartmentId,
                'to_department_name' => $toDepartment->name,
                'reason' => $reason,
                'forwarded_by_id' => $forwardedByUserId,
                'forwarded_by_name' => $forwardedByUser->name ?? 'System',
            ]
        );

        // Broadcast to department users
        $departmentUserIds = Department::find($toDepartmentId)->users()->pluck('id')->toArray();
        foreach ($departmentUserIds as $userId) {
            $this->broadcastEvent(
                new TaskForwardedNotificationEvent($departmentNotifications[0], $userId),
                'task_forwarded_department',
                [
                    'notification_id' => $departmentNotifications[0]->id,
                    'task_id' => $taskId,
                    'user_id' => $userId,
                ]
            );
        }

        $notifications = array_merge($notifications, $departmentNotifications);

        // Notify department managers
        $managerNotifications = $this->sendToDepartmentManagers(
            $toDepartmentId,
            'App\Notifications\TaskForwardedManagerNotification',
            'Task Forwarded - Manager Notification',
            "Task '{$task->title}' has been forwarded to your department by {$forwardedByUser->name}",
            [
                'task_id' => $taskId,
                'task_title' => $task->title,
                'requires_approval' => true,
                'forwarded_by_id' => $forwardedByUserId,
                'forwarded_by_name' => $forwardedByUser->name ?? 'System',
            ]
        );

        // Broadcast to department managers
        $managerUserIds = Department::find($toDepartmentId)->getManagers()->pluck('id')->toArray();
        foreach ($managerUserIds as $userId) {
            $this->broadcastEvent(
                new TaskForwardedNotificationEvent($managerNotifications[0], $userId),
                'task_forwarded_manager',
                [
                    'notification_id' => $managerNotifications[0]->id,
                    'task_id' => $taskId,
                    'user_id' => $userId,
                ]
            );
        }

        $notifications = array_merge($notifications, $managerNotifications);

        return $notifications;
    }

    /**
     * Send task forwarding acceptance notification.
     */
    public function sendTaskForwardingAcceptanceNotification(int $taskId, int $acceptedByUserId, int $forwardedUserId): Notification
    {
        $task = Task::find($taskId);
        $acceptedByUser = User::find($acceptedByUserId);
        $forwardedUser = User::find($forwardedUserId);

        return $this->sendToUser(
            $forwardedUserId,
            'App\Notifications\TaskForwardAcceptedNotification',
            'Task Forward Accepted',
            "Your forwarded task '{$task->title}' has been accepted by {$acceptedByUser->name}",
            [
                'task_id' => $taskId,
                'task_title' => $task->title,
                'accepted_by_id' => $acceptedByUserId,
                'accepted_by_name' => $acceptedByUser->name,
            ]
        );
    }

    /**
     * Send task forwarding rejection notification.
     */
    public function sendTaskForwardingRejectionNotification(int $taskId, int $rejectedByUserId, int $forwardedUserId, string $reason): Notification
    {
        $task = Task::find($taskId);
        $rejectedByUser = User::find($rejectedByUserId);
        $forwardedUser = User::find($forwardedUserId);

        return $this->sendToUser(
            $forwardedUserId,
            'App\Notifications\TaskForwardRejectedNotification',
            'Task Forward Rejected',
            "Your forwarded task '{$task->title}' has been rejected. Reason: {$reason}",
            [
                'task_id' => $taskId,
                'task_title' => $task->title,
                'rejected_by_id' => $rejectedByUserId,
                'rejected_by_name' => $rejectedByUser->name,
                'rejection_reason' => $reason,
            ]
        );
    }

    /**
     * Send ticket creation notification.
     */
    public function sendTicketCreationNotification(int $ticketId, string $ticketTitle, int $createdByUserId): Notification
    {
        $ticket = Ticket::find($ticketId);
        $createdByUser = User::find($createdByUserId);

        return $this->sendToUser(
            $createdByUserId,
            'App\Notifications\TicketCreatedNotification',
            'Ticket Created',
            "Your ticket '{$ticketTitle}' has been successfully created",
            [
                'ticket_id' => $ticketId,
                'ticket_title' => $ticketTitle,
                'created_by_id' => $createdByUserId,
                'created_by_name' => $createdByUser->name ?? 'System',
            ]
        );
    }

    /**
     * Send ticket status change notification.
     */
    public function sendTicketStatusChangeNotification(int $ticketId, string $ticketTitle, string $newStatus, int $changedByUserId): Notification
    {
        $ticket = Ticket::find($ticketId);
        $changedByUser = User::find($changedByUserId);

        return $this->sendToUser(
            $ticket->created_by,
            'App\Notifications\TicketStatusChangedNotification',
            'Ticket Status Updated',
            "Your ticket '{$ticketTitle}' status changed to: {$newStatus}",
            [
                'ticket_id' => $ticketId,
                'ticket_title' => $ticketTitle,
                'new_status' => $newStatus,
                'changed_by_id' => $changedByUserId,
                'changed_by_name' => $changedByUser->name ?? 'System',
            ]
        );
    }

    /**
     * Send department assignment notification.
     */
    public function sendDepartmentAssignmentNotification(int $departmentId, int $assignedUserId, int $assignedByUserId): Notification
    {
        $department = Department::find($departmentId);
        $assignedUser = User::find($assignedUserId);
        $assignedByUser = User::find($assignedByUserId);

        return $this->sendToUser(
            $assignedUserId,
            'App\Notifications\DepartmentAssignedNotification',
            'Assigned to Department',
            "You have been assigned to the {$department->name} department",
            [
                'department_id' => $departmentId,
                'department_name' => $department->name,
                'assigned_by_id' => $assignedByUserId,
                'assigned_by_name' => $assignedByUser->name ?? 'System',
            ]
        );
    }

    /**
     * Send overdue task notification.
     */
    public function sendOverdueTaskNotification(int $taskId, string $taskTitle, int $assignedUserId): Notification
    {
        $task = Task::find($taskId);

        return $this->sendToUser(
            $assignedUserId,
            'App\Notifications\TaskOverdueNotification',
            'Task Overdue',
            "Your task '{$taskTitle}' is overdue. Due date: {$task->due_date}",
            [
                'task_id' => $taskId,
                'task_title' => $taskTitle,
                'due_date' => $task->due_date,
            ]
        );
    }

    /**
     * Send due today task notification.
     */
    public function sendDueTodayTaskNotification(int $taskId, string $taskTitle, int $assignedUserId): Notification
    {
        $task = Task::find($taskId);

        return $this->sendToUser(
            $assignedUserId,
            'App\Notifications\TaskDueTodayNotification',
            'Task Due Today',
            "Your task '{$taskTitle}' is due today",
            [
                'task_id' => $taskId,
                'task_title' => $taskTitle,
                'due_date' => $task->due_date,
            ]
        );
    }

    /**
     * Send comment notification.
     */
    public function sendCommentNotification(int $commentId, int $commentedUserId): Notification
    {
        $comment = TaskComment::find($commentId);
        $task = $comment->task;

        return $this->sendToUser(
            $commentedUserId,
            'App\Notifications\CommentNotification',
            'New Comment',
            "New comment on task '{$task->title}': {$comment->comment_text}",
            [
                'comment_id' => $commentId,
                'task_id' => $task->id,
                'task_title' => $task->title,
                'comment_text' => $comment->comment_text,
            ]
        );
    }

    /**
     * Mark notification as read.
     */
    public function markAsRead(Notification $notification): void
    {
        $notification->markAsRead();
    }

    /**
     * Mark all notifications as read for a user.
     */
    public function markAllAsRead(int $userId): void
    {
        Notification::whereHas('users', function ($query) use ($userId) {
            $query->where('user_id', $userId)
                ->where('read', false);
        })
            ->get()
            ->each(function ($notification) use ($userId) {
                $notification->markAsReadForUser($userId);
            });
    }

    /**
     * Get unread count for a user.
     */
    public function getUnreadCount(int $userId): int
    {
        return Notification::getUnreadCountForUser($userId);
    }

    /**
     * Get recent notifications for a user.
     */
    public function getRecentNotifications(int $userId, int $limit = 10)
    {
        return Notification::getRecentNotificationsForUser($userId, $limit);
    }

    /**
     * Get all notifications for a user.
     */
    public function getUserNotifications(int $userId, int $perPage = 15)
    {
        return Notification::getUserNotifications($userId, $perPage);
    }

    /**
     * Send WhatsApp message to a phone number.
     *
     * @param  string  $phone  Phone number to send WhatsApp message to
     * @param  string  $message  Message content
     * @return bool True if WhatsApp message was sent successfully, false otherwise
     */
    public function sendWhatsApp(string $phone, string $message, bool $isGroup = false): bool
    {
        $normalizedPhone = $phone;
        if (strlen($phone) > 15) {
            $isGroup = true;
        }else{
            $normalizedPhone = $this->normalizeWhatsAppPhoneNumber($phone);
        }

        if ($normalizedPhone === null) {
            Log::warning('Invalid phone number format for WhatsApp notification', [
                'phone' => $phone,
            ]);

            return false;
        }

        $apiToken = config('services.whatsapp.api_token');
        $url = config('services.whatsapp.url', 'https://social.ednect.com/api/UWAPGet/send');
        if (!$isGroup) {
            $isGroup = config('services.whatsapp.is_group', 'false');
        }

        if (! $apiToken) {
            Log::warning('WhatsApp API token not configured', [
                'phone' => $normalizedPhone,
            ]);

            return false;
        }

        // Build the URL with query parameters
        
        $fullUrl = $url.'?apitoken='.$apiToken.'&phoneno='.urlencode($normalizedPhone).'&sms='.urlencode($message).'&isgroup='.$this->formatWhatsAppIsGroup($isGroup);

        $ch = curl_init($fullUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json',
        ]);

        $result = curl_exec($ch);

        if ($result === false) {
            Log::error('WhatsApp cURL error', [
                'phone' => $normalizedPhone,
                'error' => curl_error($ch),
            ]);
            curl_close($ch);

            return false;
        }

        curl_close($ch);

        $response = json_decode($result, true);

        if (is_array($response) && isset($response[0])) {
            $firstResponse = $response[0];
            if (isset($firstResponse['status']) && $firstResponse['status'] === 'Success') {
                Log::info('WhatsApp message sent successfully', $firstResponse);

                return true;
            } else {
                Log::warning('WhatsApp message failed', [
                    'phone' => $normalizedPhone,
                    'response' => $firstResponse,
                    'full_url' => $fullUrl,
                ]);
            }
        } else {
            Log::warning('Unexpected WhatsApp response format', [
                'phone' => $normalizedPhone,
                'response' => $result,
            ]);
        }

        return false;
    }

    /**
     * Convert a WhatsApp group flag into the explicit query string value.
     */
    protected function formatWhatsAppIsGroup(bool|string $isGroup): string
    {
        if (is_bool($isGroup)) {
            return $isGroup ? 'true' : 'false';
        }

        $normalized = trim((string) $isGroup);

        if ($normalized === '') {
            return 'false';
        }

        $booleanValue = filter_var($normalized, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);

        return $booleanValue ? 'true' : 'false';
    }

    /**
     * Normalize a phone number for WhatsApp delivery.
     */
    protected function normalizeWhatsAppPhoneNumber(string $phone): ?string
    {
        
        
        // Allow for group id (e.g. 918811047292-1550922196@g.us)
        if (strlen($phone) > 15) {
            return $phone;
        }
        
        $phone = trim($phone);
        $digitsOnly = preg_replace('/\D+/', '', $phone);

        if (! is_string($digitsOnly) || $digitsOnly === '') {
            return null;
        }

        if (strlen($digitsOnly) === 10) {
            $digitsOnly = '91'.$digitsOnly;
        }

        if (! preg_match('/^\d{10,15}$/', $digitsOnly)) {
            return null;
        }

        return $digitsOnly;
    }

    /**
     * Send notification to employee via WhatsApp.
     *
     * @param  int  $userId  The user to notify
     * @param  string  $subject  The notification subject/title
     * @param  string  $message  The notification message
     * @param  int  $assignedByUserId  The user who triggered the notification (to check if it's not self-action)
     */
    public function notifyEmployee(int $userId, string $subject, string $message, int $assignedByUserId): void
    {
        // Don't notify if user is doing action on their own task
        if ($userId === $assignedByUserId) {
            return;
        }

        $user = User::find($userId);
        if (! $user) {
            return;
        }

        $phone = $this->resolveWhatsAppPhoneNumber($user);

        if (! $phone) {
            $this->logNotificationFailure($userId, $subject, $message, null);

            return;
        }

        if ($this->sendWhatsApp($phone, $message)) {
            // a copy shall be sent to the user(who has manager role) if the user is not a manager
            if (! $user->hasRole('manager')) {
                $this->sendNotificationToManager($userId, $subject, $message);
            }

            return;
        }

        $this->logNotificationFailure($userId, $subject, $message, $phone);
    }

    protected function sendNotificationToManager(int $userId, string $subject, string $message): void
    {
        $user = User::find($userId);
        $managers = $this->getManagerUsers();

        foreach ($managers as $manager) {
            $managerPhone = $this->resolveWhatsAppPhoneNumber($manager);
            $header = "Copy - This message has been sent to {$user->name}\n\n";
            if ($managerPhone) {
                $this->sendWhatsApp($managerPhone, "{$header}\n{$subject}: {$message}");
            }
        }

    }

    /**
     * Get the users who should receive manager notifications.
     *
     * @return Collection<int, User>
     */
    protected function getSupportUsers(): Collection
    {
        return User::whereHas('roles', function ($query) {
            $query->where('slug', 'support')
                ->orWhere('slug', 'support-agent')
                ->orWhere('name', 'support')
                ->orWhere('name', 'support agent');
        })->get();
    }

    /**
     * Get the users who should receive manager notifications.
     *
     * @return Collection<int, User>
     */
    protected function getManagerUsers(): Collection
    {
        return User::whereHas('roles', function ($query) {
            $query->where('slug', 'manager')
                ->orWhere('name', 'manager');
        })->get();
    }

    /**
     * Send a report submission message to manager users only.
     */
    public function sendReportSubmissionNotificationToManagers(Report $report): void
    {
        $report->loadMissing('user');

        $title = 'Daily Report Submitted';
        $reportUrl = config('app.url').'/admin/reports/'.$report->id;
        $submittedByName = $report->user?->name ?? 'System';
        $message = "Daily report '{$report->title}' was submitted by {$submittedByName} for {$report->report_date->toDateString()}. View: {$reportUrl}";

        foreach ($this->getManagerUsers() as $manager) {
            $managerPhone = $this->resolveWhatsAppPhoneNumber($manager);

            if (! $managerPhone) {
                $this->logNotificationFailure($manager->id, $title, $message, null);

                continue;
            }

            $this->sendWhatsApp($managerPhone, "{$title}\n\n{$message}");
        }
    }

    /**
     * Convert a terminal task state into the text used in notifications.
     */
    protected function formatTerminalTaskState(string $state): string
    {
        return match ($state) {
            'Done' => 'Completed',
            'Cancelled' => 'Cancelled',
            'Rejected' => 'Rejected',
            default => $state,
        };
    }

    /**
     * Log notification failure for further investigation.
     */
    protected function logNotificationFailure(int $userId, string $subject, string $message, ?string $phone): void
    {
        Log::error('Notification delivery failed', [
            'user_id' => $userId,
            'subject' => $subject,
            'message' => $message,
            'phone' => $phone,
            'reason' => $phone ? 'WhatsApp failed' : 'No phone number available',
        ]);
    }

    /**
     * Send task assignment notification via Pusher and WhatsApp.
     *
     * @param  int  $taskId  The task ID
     * @param  string  $taskTitle  The task title
     * @param  int  $assignedUserId  The user being assigned
     * @param  int  $assignedByUserId  The user who assigned the task
     */
    public function sendTaskAssignmentExternalNotification(int $taskId, string $taskTitle, int $assignedUserId, int $assignedByUserId): void
    {
        if ($assignedUserId === $assignedByUserId) {
            return;
        }

        $assignedByUser = User::find($assignedByUserId);
        $assignedByName = $assignedByUser->name ?? 'System';

        $title = 'New Task Assigned';
        $taskUrl = config('app.url').'/admin/tasks/'.$taskId;
        $message = "You have been assigned to task: {$taskTitle}. Assigned by: {$assignedByName}. View: {$taskUrl}";

        $notifications = $this->sendUnifiedNotification(
            $assignedUserId,
            'App\Notifications\TaskAssignedNotification',
            $title,
            $message,
            [
                'task_id' => $taskId,
                'task_title' => $taskTitle,
                'assigned_by_id' => $assignedByUserId,
                'assigned_by_name' => $assignedByName,
            ]
        );

        if (! (bool) ($notifications['whatsapp']['success'] ?? false)) {
            Log::warning('Task assignment WhatsApp notification failed', [
                'task_id' => $taskId,
                'assigned_user_id' => $assignedUserId,
            ]);
        }
    }

    /**
     * Send terminal task state notification to managers.
     */
    public function sendTaskCompletionExternalNotification(int $taskId, string $taskTitle, string $newStatus, int $changedByUserId): void
    {
        $changedByUser = User::with('employee')->find($changedByUserId);

        if (! $changedByUser) {
            return;
        }

        $stateLabel = $this->formatTerminalTaskState($newStatus);
        $title = 'Task '.$stateLabel;
        $taskUrl = config('app.url').'/admin/tasks/'.$taskId;
        $actorName = $changedByUser->employee?->name ?? $changedByUser->name ?? 'System';
        $message = "Task '{$taskTitle}' has been {$stateLabel} by {$actorName}. View: {$taskUrl}";

        foreach ($this->getManagerUsers() as $manager) {
            $managerPhone = $this->resolveWhatsAppPhoneNumber($manager);

            if (! $managerPhone) {
                $this->logNotificationFailure($manager->id, $title, $message, null);

                continue;
            }

            $this->sendWhatsApp($managerPhone, "{$title}\n\n{$message}");
        }

        foreach ($this->getSupportUsers() as $support) {
            $supportPhone = $this->resolveWhatsAppPhoneNumber($support);
            if (! $supportPhone) {
                $this->logNotificationFailure($support->id, $title, $message, null);

                continue;
            }
            $this->sendWhatsApp($supportPhone, "{$title}\n\n{$message}");
        }
    }

    /**
     * Send ticket status change notification to support users.
     */
    public function sendTicketStatusChangeExternalNotification(int $ticketId, string $ticketTitle, string $newStatus, int $changedByUserId): void
    {
        $changedByUser = User::with('employee')->find($changedByUserId);

        if (! $changedByUser) {
            return;
        }

        $title = 'Ticket Status Updated';
        $ticketUrl = config('app.url').'/admin/tickets/'.$ticketId;
        $actorName = $changedByUser->employee?->name ?? $changedByUser->name ?? 'System';
        $message = "Ticket '{$ticketTitle}' status changed to: {$newStatus}. Changed by: {$actorName}. View: {$ticketUrl}";

        foreach ($this->getSupportUsers() as $support) {
            $supportPhone = $this->resolveWhatsAppPhoneNumber($support);

            if (! $supportPhone) {
                $this->logNotificationFailure($support->id, $title, $message, null);

                continue;
            }

            $this->sendWhatsApp($supportPhone, "{$title}\n\n{$message}");
        }
    }

    /**
     * Send task status change notification via Pusher and external channels.
     *
     * @param  int  $taskId  The task ID
     * @param  string  $taskTitle  The task title
     * @param  string  $newStatus  The new status
     * @param  int  $changedByUserId  The user who changed the status
     * @param  int  $notifyUserId  The user to notify
     */
    public function sendTaskStatusChangeExternalNotification(int $taskId, string $taskTitle, string $newStatus, int $changedByUserId, int $notifyUserId): void
    {
        // Don't notify if user is doing action on their own task
        if ($notifyUserId === $changedByUserId) {
            return;
        }

        $changedByUser = User::find($changedByUserId);
        $changedByName = $changedByUser->name ?? 'System';

        $title = 'Task Status Updated';
        $taskUrl = config('app.url').'/admin/tasks/'.$taskId;
        $message = "Task '{$taskTitle}' status changed to: {$newStatus}. Changed by: {$changedByName}. View: {$taskUrl}";

        $this->sendUnifiedNotification(
            $notifyUserId,
            'App\Notifications\TaskStatusChangedNotification',
            $title,
            $message,
            [
                'task_id' => $taskId,
                'task_title' => $taskTitle,
                'new_status' => $newStatus,
                'changed_by_id' => $changedByUserId,
                'changed_by_name' => $changedByName,
            ]
        );
    }

    /**
     * Send task forwarding notification via Pusher and external channels.
     *
     * @param  int  $taskId  The task ID
     * @param  string  $taskTitle  The task title
     * @param  string  $fromDepartmentName  Source department
     * @param  string  $toDepartmentName  Target department
     * @param  int  $forwardedByUserId  The user who forwarded the task
     * @param  int  $notifyUserId  The user to notify
     */
    public function sendTaskForwardExternalNotification(int $taskId, string $taskTitle, string $fromDepartmentName, string $toDepartmentName, int $forwardedByUserId, int $notifyUserId): void
    {
        // Don't notify if user is doing action on their own task
        if ($notifyUserId === $forwardedByUserId) {
            return;
        }

        $forwardedByUser = User::find($forwardedByUserId);
        $forwardedByName = $forwardedByUser->name ?? 'System';

        $title = 'Task Forwarded to Your Department';
        $taskUrl = config('app.url').'/admin/tasks/'.$taskId;
        $message = "Task '{$taskTitle}' has been forwarded from {$fromDepartmentName} to {$toDepartmentName}. Forwarded by: {$forwardedByName}. View: {$taskUrl}";

        $this->sendUnifiedNotification(
            $notifyUserId,
            'App\Notifications\TaskForwardedNotification',
            $title,
            $message,
            [
                'task_id' => $taskId,
                'task_title' => $taskTitle,
                'from_department_name' => $fromDepartmentName,
                'to_department_name' => $toDepartmentName,
                'forwarded_by_id' => $forwardedByUserId,
                'forwarded_by_name' => $forwardedByName,
            ]
        );
    }

    /**
     * Send ticket assignment notification via Pusher and external channels.
     *
     * @param  int  $ticketId  The ticket ID
     * @param  string  $ticketTitle  The ticket title
     * @param  int  $assignedUserId  The user being assigned
     * @param  int  $assignedByUserId  The user who assigned the ticket
     */
    public function sendTicketAssignmentExternalNotification(int $ticketId, string $ticketTitle, int $assignedUserId, int $assignedByUserId): void
    {
        // Don't notify if user is doing action on their own ticket
        if ($assignedUserId === $assignedByUserId) {
            return;
        }

        $assignedByUser = User::find($assignedByUserId);
        $assignedByName = $assignedByUser->name ?? 'System';

        $title = 'New Ticket Assigned';
        $ticketUrl = config('app.url').'/admin/tickets/'.$ticketId;
        $message = "You have been assigned to ticket: {$ticketTitle}. Assigned by: {$assignedByName}. View: {$ticketUrl}";

        $notifications = $this->sendUnifiedNotification(
            $assignedUserId,
            'App\Notifications\TicketAssignedNotification',
            $title,
            $message,
            [
                'ticket_id' => $ticketId,
                'ticket_title' => $ticketTitle,
                'assigned_by_id' => $assignedByUserId,
                'assigned_by_name' => $assignedByName,
            ]
        );

        if (! (bool) ($notifications['whatsapp']['success'] ?? false)) {
            Log::warning('Ticket assignment WhatsApp notification failed', [
                'ticket_id' => $ticketId,
                'assigned_user_id' => $assignedUserId,
            ]);
        }
    }

    /**
     * Send unified notification through Pusher and WhatsApp.
     *
     * @param  int  $userId  The user ID to notify
     * @param  string  $type  Notification type/class
     * @param  string  $title  Notification title
     * @param  string  $message  Notification message
     * @param  array  $data  Additional data for the notification
     * @return array Results of each delivery channel
     */
    public function sendUnifiedNotification(
        int $userId,
        string $type,
        string $title,
        string $message,
        array $data = []
    ): array {
        $results = [];
        $user = User::find($userId);

        if (! $user) {
            Log::warning('User not found for unified notification', ['user_id' => $userId]);

            return $results;
        }

        // 1. ALWAYS send Pusher/in-app notification (mandatory)
        try {
            $notification = Notification::createWorkflowNotification($userId, $type, $title, $message, $data);
            $notification->update([
                'delivery_channel' => 'pusher',
                'delivered' => true,
                'delivered_at' => now(),
            ]);
            $broadcasted = $this->broadcastNotification($notification, $userId);
            $results['pusher'] = ['success' => $broadcasted, 'notification_id' => $notification->id];

            if (! $broadcasted) {
                Log::warning('Pusher notification was stored but not broadcast', [
                    'user_id' => $userId,
                    'notification_id' => $notification->id,
                ]);
            }
        } catch (\Throwable $e) {
            Log::error('Failed to send Pusher notification', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $results['pusher'] = ['success' => false, 'error' => $e->getMessage()];
        }

        // Always attempt WhatsApp delivery.
        $phone = $this->resolveWhatsAppPhoneNumber($user);

        if (! $phone) {
            $results['whatsapp'] = ['success' => false, 'reason' => 'No phone number'];

            Log::warning('WhatsApp notification skipped because no phone number was available', [
                'user_id' => $userId,
                'notification_type' => $type,
            ]);
        } else {
            try {
                $whatsappSent = $this->sendWhatsApp($phone, "{$title}\n\n{$message}");
                // a copy shall be sent to the user(who has manager role) if the user is not a manager
                if (! $user->hasRole('manager')) {
                    $this->sendNotificationToManager($userId, $title, $message);
                }

                $results['whatsapp'] = ['success' => $whatsappSent, 'message' => $whatsappSent ? 'Sent' : 'Failed'];

                if (! $whatsappSent) {
                    Log::warning('WhatsApp notification failed', [
                        'user_id' => $userId,
                        'notification_type' => $type,
                        'phone' => $phone,
                    ]);
                }
            } catch (\Throwable $e) {
                $results['whatsapp'] = ['success' => false, 'error' => $e->getMessage()];

                Log::error('Failed to send WhatsApp notification', [
                    'user_id' => $userId,
                    'notification_type' => $type,
                    'phone' => $phone,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return $results;
    }

    /**
     * Resolve the phone number that should receive WhatsApp notifications.
     */
    protected function resolveWhatsAppPhoneNumber(User $user): ?string
    {
        $employeePhone = $user->employee?->phone;

        if (is_string($employeePhone) && trim($employeePhone) !== '') {
            return $employeePhone;
        }

        $userPhone = $user->phone;

        if (is_string($userPhone) && trim($userPhone) !== '') {
            return $userPhone;
        }

        return null;
    }
}
