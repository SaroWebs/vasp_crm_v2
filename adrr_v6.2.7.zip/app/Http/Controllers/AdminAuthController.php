<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;

class AdminAuthController extends Controller
{
    public function showLoginForm()
    {
        // Redirect if already authenticated as admin
        if (Auth::guard('web')->check()) {
            return redirect('/admin/dashboard');
        }

        return Inertia::render('auth/login', [
            'isAdmin' => true,
            'canResetPassword' => true,
            'forgotPasswordHref' => '/admin/forgot-password',
            'status' => session('status'),
        ]);
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => ['required', 'string', 'email'],
            'password' => ['required', 'string'],
        ]);

        $credentials = $request->only('email', 'password');

        $user = User::where('email', $credentials['email'])->first();

        if ($user && $user->session_id && $user->session_id !== $request->session()->getId()) {
            // User has an active session on a different device - invalidate it
            // The previous session will be logged out automatically when it tries to access protected routes
        }

        if (Auth::guard('web')->attempt($credentials, $request->boolean('remember'))) {
            $request->session()->regenerate();

            $user = Auth::guard('web')->user();
            $user->setCurrentSessionId($request->session()->getId());

            return redirect('/admin/dashboard');
        }

        throw ValidationException::withMessages([
            'email' => __('auth.failed'),
        ]);
    }

    public function logout(Request $request)
    {
        $user = Auth::guard('web')->user();
        if ($user) {
            $user->clearSessionId();
        }

        Auth::guard('web')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/admin/login');
    }
}
