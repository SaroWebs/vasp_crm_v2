import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\EmployeeOfficeController::updateActiveOffice
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
export const updateActiveOffice = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateActiveOffice.url(options),
    method: 'patch',
})

updateActiveOffice.definition = {
    methods: ["patch"],
    url: '/settings/active-office',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\EmployeeOfficeController::updateActiveOffice
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
updateActiveOffice.url = (options?: RouteQueryOptions) => {
    return updateActiveOffice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeOfficeController::updateActiveOffice
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
updateActiveOffice.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateActiveOffice.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\EmployeeOfficeController::updateActiveOffice
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
    const updateActiveOfficeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateActiveOffice.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\EmployeeOfficeController::updateActiveOffice
 * @see app/Http/Controllers/EmployeeOfficeController.php:13
 * @route '/settings/active-office'
 */
        updateActiveOfficeForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateActiveOffice.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateActiveOffice.form = updateActiveOfficeForm
const EmployeeOfficeController = { updateActiveOffice }

export default EmployeeOfficeController