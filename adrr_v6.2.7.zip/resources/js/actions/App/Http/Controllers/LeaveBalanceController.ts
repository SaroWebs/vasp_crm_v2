import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LeaveBalanceController::index
 * @see app/Http/Controllers/LeaveBalanceController.php:21
 * @route '/api/leave-balances'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/leave-balances',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaveBalanceController::index
 * @see app/Http/Controllers/LeaveBalanceController.php:21
 * @route '/api/leave-balances'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveBalanceController::index
 * @see app/Http/Controllers/LeaveBalanceController.php:21
 * @route '/api/leave-balances'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LeaveBalanceController::index
 * @see app/Http/Controllers/LeaveBalanceController.php:21
 * @route '/api/leave-balances'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LeaveBalanceController::index
 * @see app/Http/Controllers/LeaveBalanceController.php:21
 * @route '/api/leave-balances'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LeaveBalanceController::index
 * @see app/Http/Controllers/LeaveBalanceController.php:21
 * @route '/api/leave-balances'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LeaveBalanceController::index
 * @see app/Http/Controllers/LeaveBalanceController.php:21
 * @route '/api/leave-balances'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\LeaveBalanceController::store
 * @see app/Http/Controllers/LeaveBalanceController.php:153
 * @route '/api/leave-balances'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/leave-balances',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LeaveBalanceController::store
 * @see app/Http/Controllers/LeaveBalanceController.php:153
 * @route '/api/leave-balances'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveBalanceController::store
 * @see app/Http/Controllers/LeaveBalanceController.php:153
 * @route '/api/leave-balances'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LeaveBalanceController::store
 * @see app/Http/Controllers/LeaveBalanceController.php:153
 * @route '/api/leave-balances'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LeaveBalanceController::store
 * @see app/Http/Controllers/LeaveBalanceController.php:153
 * @route '/api/leave-balances'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\LeaveBalanceController::bulkAssign
 * @see app/Http/Controllers/LeaveBalanceController.php:64
 * @route '/api/leave-balances/bulk-assign'
 */
export const bulkAssign = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAssign.url(options),
    method: 'post',
})

bulkAssign.definition = {
    methods: ["post"],
    url: '/api/leave-balances/bulk-assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LeaveBalanceController::bulkAssign
 * @see app/Http/Controllers/LeaveBalanceController.php:64
 * @route '/api/leave-balances/bulk-assign'
 */
bulkAssign.url = (options?: RouteQueryOptions) => {
    return bulkAssign.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveBalanceController::bulkAssign
 * @see app/Http/Controllers/LeaveBalanceController.php:64
 * @route '/api/leave-balances/bulk-assign'
 */
bulkAssign.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAssign.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LeaveBalanceController::bulkAssign
 * @see app/Http/Controllers/LeaveBalanceController.php:64
 * @route '/api/leave-balances/bulk-assign'
 */
    const bulkAssignForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkAssign.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LeaveBalanceController::bulkAssign
 * @see app/Http/Controllers/LeaveBalanceController.php:64
 * @route '/api/leave-balances/bulk-assign'
 */
        bulkAssignForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkAssign.url(options),
            method: 'post',
        })
    
    bulkAssign.form = bulkAssignForm
/**
* @see \App\Http\Controllers\LeaveBalanceController::show
 * @see app/Http/Controllers/LeaveBalanceController.php:144
 * @route '/api/leave-balances/{leaveBalance}'
 */
export const show = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/leave-balances/{leaveBalance}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaveBalanceController::show
 * @see app/Http/Controllers/LeaveBalanceController.php:144
 * @route '/api/leave-balances/{leaveBalance}'
 */
show.url = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leaveBalance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { leaveBalance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    leaveBalance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        leaveBalance: typeof args.leaveBalance === 'object'
                ? args.leaveBalance.id
                : args.leaveBalance,
                }

    return show.definition.url
            .replace('{leaveBalance}', parsedArgs.leaveBalance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveBalanceController::show
 * @see app/Http/Controllers/LeaveBalanceController.php:144
 * @route '/api/leave-balances/{leaveBalance}'
 */
show.get = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LeaveBalanceController::show
 * @see app/Http/Controllers/LeaveBalanceController.php:144
 * @route '/api/leave-balances/{leaveBalance}'
 */
show.head = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LeaveBalanceController::show
 * @see app/Http/Controllers/LeaveBalanceController.php:144
 * @route '/api/leave-balances/{leaveBalance}'
 */
    const showForm = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LeaveBalanceController::show
 * @see app/Http/Controllers/LeaveBalanceController.php:144
 * @route '/api/leave-balances/{leaveBalance}'
 */
        showForm.get = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LeaveBalanceController::show
 * @see app/Http/Controllers/LeaveBalanceController.php:144
 * @route '/api/leave-balances/{leaveBalance}'
 */
        showForm.head = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\LeaveBalanceController::update
 * @see app/Http/Controllers/LeaveBalanceController.php:200
 * @route '/api/leave-balances/{leaveBalance}'
 */
export const update = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/leave-balances/{leaveBalance}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LeaveBalanceController::update
 * @see app/Http/Controllers/LeaveBalanceController.php:200
 * @route '/api/leave-balances/{leaveBalance}'
 */
update.url = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leaveBalance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { leaveBalance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    leaveBalance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        leaveBalance: typeof args.leaveBalance === 'object'
                ? args.leaveBalance.id
                : args.leaveBalance,
                }

    return update.definition.url
            .replace('{leaveBalance}', parsedArgs.leaveBalance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveBalanceController::update
 * @see app/Http/Controllers/LeaveBalanceController.php:200
 * @route '/api/leave-balances/{leaveBalance}'
 */
update.put = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\LeaveBalanceController::update
 * @see app/Http/Controllers/LeaveBalanceController.php:200
 * @route '/api/leave-balances/{leaveBalance}'
 */
    const updateForm = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LeaveBalanceController::update
 * @see app/Http/Controllers/LeaveBalanceController.php:200
 * @route '/api/leave-balances/{leaveBalance}'
 */
        updateForm.put = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\LeaveBalanceController::destroy
 * @see app/Http/Controllers/LeaveBalanceController.php:286
 * @route '/api/leave-balances/{leaveBalance}'
 */
export const destroy = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/leave-balances/{leaveBalance}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\LeaveBalanceController::destroy
 * @see app/Http/Controllers/LeaveBalanceController.php:286
 * @route '/api/leave-balances/{leaveBalance}'
 */
destroy.url = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leaveBalance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { leaveBalance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    leaveBalance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        leaveBalance: typeof args.leaveBalance === 'object'
                ? args.leaveBalance.id
                : args.leaveBalance,
                }

    return destroy.definition.url
            .replace('{leaveBalance}', parsedArgs.leaveBalance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveBalanceController::destroy
 * @see app/Http/Controllers/LeaveBalanceController.php:286
 * @route '/api/leave-balances/{leaveBalance}'
 */
destroy.delete = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\LeaveBalanceController::destroy
 * @see app/Http/Controllers/LeaveBalanceController.php:286
 * @route '/api/leave-balances/{leaveBalance}'
 */
    const destroyForm = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LeaveBalanceController::destroy
 * @see app/Http/Controllers/LeaveBalanceController.php:286
 * @route '/api/leave-balances/{leaveBalance}'
 */
        destroyForm.delete = (args: { leaveBalance: number | { id: number } } | [leaveBalance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const LeaveBalanceController = { index, store, bulkAssign, show, update, destroy }

export default LeaveBalanceController