import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:24
 * @route '/admin/sales-leads'
 */
export const adminIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})

adminIndex.definition = {
    methods: ["get","head"],
    url: '/admin/sales-leads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:24
 * @route '/admin/sales-leads'
 */
adminIndex.url = (options?: RouteQueryOptions) => {
    return adminIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:24
 * @route '/admin/sales-leads'
 */
adminIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:24
 * @route '/admin/sales-leads'
 */
adminIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:24
 * @route '/admin/sales-leads'
 */
    const adminIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:24
 * @route '/admin/sales-leads'
 */
        adminIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::adminIndex
 * @see app/Http/Controllers/SalesLeadController.php:24
 * @route '/admin/sales-leads'
 */
        adminIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminIndex.form = adminIndexForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminData
 * @see app/Http/Controllers/SalesLeadController.php:34
 * @route '/admin/data/sales-leads'
 */
export const adminData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminData.url(options),
    method: 'get',
})

adminData.definition = {
    methods: ["get","head"],
    url: '/admin/data/sales-leads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminData
 * @see app/Http/Controllers/SalesLeadController.php:34
 * @route '/admin/data/sales-leads'
 */
adminData.url = (options?: RouteQueryOptions) => {
    return adminData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminData
 * @see app/Http/Controllers/SalesLeadController.php:34
 * @route '/admin/data/sales-leads'
 */
adminData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminData.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::adminData
 * @see app/Http/Controllers/SalesLeadController.php:34
 * @route '/admin/data/sales-leads'
 */
adminData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminData.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminData
 * @see app/Http/Controllers/SalesLeadController.php:34
 * @route '/admin/data/sales-leads'
 */
    const adminDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminData.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminData
 * @see app/Http/Controllers/SalesLeadController.php:34
 * @route '/admin/data/sales-leads'
 */
        adminDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminData.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::adminData
 * @see app/Http/Controllers/SalesLeadController.php:34
 * @route '/admin/data/sales-leads'
 */
        adminDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminData.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminData.form = adminDataForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminReport
 * @see app/Http/Controllers/SalesLeadController.php:42
 * @route '/admin/data/sales-leads/report'
 */
export const adminReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminReport.url(options),
    method: 'get',
})

adminReport.definition = {
    methods: ["get","head"],
    url: '/admin/data/sales-leads/report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminReport
 * @see app/Http/Controllers/SalesLeadController.php:42
 * @route '/admin/data/sales-leads/report'
 */
adminReport.url = (options?: RouteQueryOptions) => {
    return adminReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminReport
 * @see app/Http/Controllers/SalesLeadController.php:42
 * @route '/admin/data/sales-leads/report'
 */
adminReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::adminReport
 * @see app/Http/Controllers/SalesLeadController.php:42
 * @route '/admin/data/sales-leads/report'
 */
adminReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminReport
 * @see app/Http/Controllers/SalesLeadController.php:42
 * @route '/admin/data/sales-leads/report'
 */
    const adminReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminReport
 * @see app/Http/Controllers/SalesLeadController.php:42
 * @route '/admin/data/sales-leads/report'
 */
        adminReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::adminReport
 * @see app/Http/Controllers/SalesLeadController.php:42
 * @route '/admin/data/sales-leads/report'
 */
        adminReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminReport.form = adminReportForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminExport
 * @see app/Http/Controllers/SalesLeadController.php:50
 * @route '/admin/sales-leads/export'
 */
export const adminExport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminExport.url(options),
    method: 'get',
})

adminExport.definition = {
    methods: ["get","head"],
    url: '/admin/sales-leads/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminExport
 * @see app/Http/Controllers/SalesLeadController.php:50
 * @route '/admin/sales-leads/export'
 */
adminExport.url = (options?: RouteQueryOptions) => {
    return adminExport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminExport
 * @see app/Http/Controllers/SalesLeadController.php:50
 * @route '/admin/sales-leads/export'
 */
adminExport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminExport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::adminExport
 * @see app/Http/Controllers/SalesLeadController.php:50
 * @route '/admin/sales-leads/export'
 */
adminExport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminExport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminExport
 * @see app/Http/Controllers/SalesLeadController.php:50
 * @route '/admin/sales-leads/export'
 */
    const adminExportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminExport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminExport
 * @see app/Http/Controllers/SalesLeadController.php:50
 * @route '/admin/sales-leads/export'
 */
        adminExportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminExport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::adminExport
 * @see app/Http/Controllers/SalesLeadController.php:50
 * @route '/admin/sales-leads/export'
 */
        adminExportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminExport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminExport.form = adminExportForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminStore
 * @see app/Http/Controllers/SalesLeadController.php:133
 * @route '/admin/sales-leads'
 */
export const adminStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminStore.url(options),
    method: 'post',
})

adminStore.definition = {
    methods: ["post"],
    url: '/admin/sales-leads',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminStore
 * @see app/Http/Controllers/SalesLeadController.php:133
 * @route '/admin/sales-leads'
 */
adminStore.url = (options?: RouteQueryOptions) => {
    return adminStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminStore
 * @see app/Http/Controllers/SalesLeadController.php:133
 * @route '/admin/sales-leads'
 */
adminStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminStore.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminStore
 * @see app/Http/Controllers/SalesLeadController.php:133
 * @route '/admin/sales-leads'
 */
    const adminStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminStore.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminStore
 * @see app/Http/Controllers/SalesLeadController.php:133
 * @route '/admin/sales-leads'
 */
        adminStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminStore.url(options),
            method: 'post',
        })
    
    adminStore.form = adminStoreForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminShow
 * @see app/Http/Controllers/SalesLeadController.php:103
 * @route '/admin/sales-leads/{salesLead}'
 */
export const adminShow = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminShow.url(args, options),
    method: 'get',
})

adminShow.definition = {
    methods: ["get","head"],
    url: '/admin/sales-leads/{salesLead}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminShow
 * @see app/Http/Controllers/SalesLeadController.php:103
 * @route '/admin/sales-leads/{salesLead}'
 */
adminShow.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return adminShow.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminShow
 * @see app/Http/Controllers/SalesLeadController.php:103
 * @route '/admin/sales-leads/{salesLead}'
 */
adminShow.get = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminShow.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::adminShow
 * @see app/Http/Controllers/SalesLeadController.php:103
 * @route '/admin/sales-leads/{salesLead}'
 */
adminShow.head = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminShow.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminShow
 * @see app/Http/Controllers/SalesLeadController.php:103
 * @route '/admin/sales-leads/{salesLead}'
 */
    const adminShowForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminShow.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminShow
 * @see app/Http/Controllers/SalesLeadController.php:103
 * @route '/admin/sales-leads/{salesLead}'
 */
        adminShowForm.get = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminShow.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::adminShow
 * @see app/Http/Controllers/SalesLeadController.php:103
 * @route '/admin/sales-leads/{salesLead}'
 */
        adminShowForm.head = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminShow.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminShow.form = adminShowForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminUpdate
 * @see app/Http/Controllers/SalesLeadController.php:161
 * @route '/admin/sales-leads/{salesLead}'
 */
export const adminUpdate = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: adminUpdate.url(args, options),
    method: 'patch',
})

adminUpdate.definition = {
    methods: ["patch"],
    url: '/admin/sales-leads/{salesLead}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminUpdate
 * @see app/Http/Controllers/SalesLeadController.php:161
 * @route '/admin/sales-leads/{salesLead}'
 */
adminUpdate.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return adminUpdate.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminUpdate
 * @see app/Http/Controllers/SalesLeadController.php:161
 * @route '/admin/sales-leads/{salesLead}'
 */
adminUpdate.patch = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: adminUpdate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminUpdate
 * @see app/Http/Controllers/SalesLeadController.php:161
 * @route '/admin/sales-leads/{salesLead}'
 */
    const adminUpdateForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminUpdate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminUpdate
 * @see app/Http/Controllers/SalesLeadController.php:161
 * @route '/admin/sales-leads/{salesLead}'
 */
        adminUpdateForm.patch = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminUpdate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    adminUpdate.form = adminUpdateForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminDestroy
 * @see app/Http/Controllers/SalesLeadController.php:191
 * @route '/admin/sales-leads/{salesLead}'
 */
export const adminDestroy = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: adminDestroy.url(args, options),
    method: 'delete',
})

adminDestroy.definition = {
    methods: ["delete"],
    url: '/admin/sales-leads/{salesLead}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminDestroy
 * @see app/Http/Controllers/SalesLeadController.php:191
 * @route '/admin/sales-leads/{salesLead}'
 */
adminDestroy.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return adminDestroy.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminDestroy
 * @see app/Http/Controllers/SalesLeadController.php:191
 * @route '/admin/sales-leads/{salesLead}'
 */
adminDestroy.delete = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: adminDestroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminDestroy
 * @see app/Http/Controllers/SalesLeadController.php:191
 * @route '/admin/sales-leads/{salesLead}'
 */
    const adminDestroyForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminDestroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminDestroy
 * @see app/Http/Controllers/SalesLeadController.php:191
 * @route '/admin/sales-leads/{salesLead}'
 */
        adminDestroyForm.delete = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminDestroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    adminDestroy.form = adminDestroyForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminConvert
 * @see app/Http/Controllers/SalesLeadController.php:200
 * @route '/admin/sales-leads/{salesLead}/convert'
 */
export const adminConvert = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminConvert.url(args, options),
    method: 'post',
})

adminConvert.definition = {
    methods: ["post"],
    url: '/admin/sales-leads/{salesLead}/convert',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminConvert
 * @see app/Http/Controllers/SalesLeadController.php:200
 * @route '/admin/sales-leads/{salesLead}/convert'
 */
adminConvert.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return adminConvert.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminConvert
 * @see app/Http/Controllers/SalesLeadController.php:200
 * @route '/admin/sales-leads/{salesLead}/convert'
 */
adminConvert.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminConvert.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminConvert
 * @see app/Http/Controllers/SalesLeadController.php:200
 * @route '/admin/sales-leads/{salesLead}/convert'
 */
    const adminConvertForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminConvert.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminConvert
 * @see app/Http/Controllers/SalesLeadController.php:200
 * @route '/admin/sales-leads/{salesLead}/convert'
 */
        adminConvertForm.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminConvert.url(args, options),
            method: 'post',
        })
    
    adminConvert.form = adminConvertForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:274
 * @route '/admin/sales-leads/{salesLead}/activities'
 */
export const adminStoreActivity = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminStoreActivity.url(args, options),
    method: 'post',
})

adminStoreActivity.definition = {
    methods: ["post"],
    url: '/admin/sales-leads/{salesLead}/activities',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:274
 * @route '/admin/sales-leads/{salesLead}/activities'
 */
adminStoreActivity.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return adminStoreActivity.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:274
 * @route '/admin/sales-leads/{salesLead}/activities'
 */
adminStoreActivity.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminStoreActivity.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:274
 * @route '/admin/sales-leads/{salesLead}/activities'
 */
    const adminStoreActivityForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminStoreActivity.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:274
 * @route '/admin/sales-leads/{salesLead}/activities'
 */
        adminStoreActivityForm.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminStoreActivity.url(args, options),
            method: 'post',
        })
    
    adminStoreActivity.form = adminStoreActivityForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:279
 * @route '/admin/sales-leads/{salesLead}/complete-follow-up'
 */
export const adminCompleteFollowUp = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminCompleteFollowUp.url(args, options),
    method: 'post',
})

adminCompleteFollowUp.definition = {
    methods: ["post"],
    url: '/admin/sales-leads/{salesLead}/complete-follow-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:279
 * @route '/admin/sales-leads/{salesLead}/complete-follow-up'
 */
adminCompleteFollowUp.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return adminCompleteFollowUp.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:279
 * @route '/admin/sales-leads/{salesLead}/complete-follow-up'
 */
adminCompleteFollowUp.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminCompleteFollowUp.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:279
 * @route '/admin/sales-leads/{salesLead}/complete-follow-up'
 */
    const adminCompleteFollowUpForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminCompleteFollowUp.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:279
 * @route '/admin/sales-leads/{salesLead}/complete-follow-up'
 */
        adminCompleteFollowUpForm.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminCompleteFollowUp.url(args, options),
            method: 'post',
        })
    
    adminCompleteFollowUp.form = adminCompleteFollowUpForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:284
 * @route '/admin/sales-leads/{salesLead}/close-deal'
 */
export const adminCloseDeal = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminCloseDeal.url(args, options),
    method: 'post',
})

adminCloseDeal.definition = {
    methods: ["post"],
    url: '/admin/sales-leads/{salesLead}/close-deal',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:284
 * @route '/admin/sales-leads/{salesLead}/close-deal'
 */
adminCloseDeal.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return adminCloseDeal.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:284
 * @route '/admin/sales-leads/{salesLead}/close-deal'
 */
adminCloseDeal.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminCloseDeal.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:284
 * @route '/admin/sales-leads/{salesLead}/close-deal'
 */
    const adminCloseDealForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminCloseDeal.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:284
 * @route '/admin/sales-leads/{salesLead}/close-deal'
 */
        adminCloseDealForm.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminCloseDeal.url(args, options),
            method: 'post',
        })
    
    adminCloseDeal.form = adminCloseDealForm
/**
* @see \App\Http\Controllers\SalesLeadController::adminSendReminders
 * @see app/Http/Controllers/SalesLeadController.php:238
 * @route '/admin/sales-leads/reminders/send'
 */
export const adminSendReminders = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminSendReminders.url(options),
    method: 'post',
})

adminSendReminders.definition = {
    methods: ["post"],
    url: '/admin/sales-leads/reminders/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::adminSendReminders
 * @see app/Http/Controllers/SalesLeadController.php:238
 * @route '/admin/sales-leads/reminders/send'
 */
adminSendReminders.url = (options?: RouteQueryOptions) => {
    return adminSendReminders.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::adminSendReminders
 * @see app/Http/Controllers/SalesLeadController.php:238
 * @route '/admin/sales-leads/reminders/send'
 */
adminSendReminders.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adminSendReminders.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::adminSendReminders
 * @see app/Http/Controllers/SalesLeadController.php:238
 * @route '/admin/sales-leads/reminders/send'
 */
    const adminSendRemindersForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adminSendReminders.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::adminSendReminders
 * @see app/Http/Controllers/SalesLeadController.php:238
 * @route '/admin/sales-leads/reminders/send'
 */
        adminSendRemindersForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adminSendReminders.url(options),
            method: 'post',
        })
    
    adminSendReminders.form = adminSendRemindersForm
/**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:29
 * @route '/my/sales-leads'
 */
export const myIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myIndex.url(options),
    method: 'get',
})

myIndex.definition = {
    methods: ["get","head"],
    url: '/my/sales-leads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:29
 * @route '/my/sales-leads'
 */
myIndex.url = (options?: RouteQueryOptions) => {
    return myIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:29
 * @route '/my/sales-leads'
 */
myIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:29
 * @route '/my/sales-leads'
 */
myIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:29
 * @route '/my/sales-leads'
 */
    const myIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: myIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:29
 * @route '/my/sales-leads'
 */
        myIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::myIndex
 * @see app/Http/Controllers/SalesLeadController.php:29
 * @route '/my/sales-leads'
 */
        myIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    myIndex.form = myIndexForm
/**
* @see \App\Http\Controllers\SalesLeadController::myData
 * @see app/Http/Controllers/SalesLeadController.php:113
 * @route '/data/my/sales-leads'
 */
export const myData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myData.url(options),
    method: 'get',
})

myData.definition = {
    methods: ["get","head"],
    url: '/data/my/sales-leads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::myData
 * @see app/Http/Controllers/SalesLeadController.php:113
 * @route '/data/my/sales-leads'
 */
myData.url = (options?: RouteQueryOptions) => {
    return myData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::myData
 * @see app/Http/Controllers/SalesLeadController.php:113
 * @route '/data/my/sales-leads'
 */
myData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myData.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::myData
 * @see app/Http/Controllers/SalesLeadController.php:113
 * @route '/data/my/sales-leads'
 */
myData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myData.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::myData
 * @see app/Http/Controllers/SalesLeadController.php:113
 * @route '/data/my/sales-leads'
 */
    const myDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: myData.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::myData
 * @see app/Http/Controllers/SalesLeadController.php:113
 * @route '/data/my/sales-leads'
 */
        myDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myData.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::myData
 * @see app/Http/Controllers/SalesLeadController.php:113
 * @route '/data/my/sales-leads'
 */
        myDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myData.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    myData.form = myDataForm
/**
* @see \App\Http\Controllers\SalesLeadController::myStore
 * @see app/Http/Controllers/SalesLeadController.php:147
 * @route '/my/sales-leads'
 */
export const myStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: myStore.url(options),
    method: 'post',
})

myStore.definition = {
    methods: ["post"],
    url: '/my/sales-leads',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::myStore
 * @see app/Http/Controllers/SalesLeadController.php:147
 * @route '/my/sales-leads'
 */
myStore.url = (options?: RouteQueryOptions) => {
    return myStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::myStore
 * @see app/Http/Controllers/SalesLeadController.php:147
 * @route '/my/sales-leads'
 */
myStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: myStore.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::myStore
 * @see app/Http/Controllers/SalesLeadController.php:147
 * @route '/my/sales-leads'
 */
    const myStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: myStore.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::myStore
 * @see app/Http/Controllers/SalesLeadController.php:147
 * @route '/my/sales-leads'
 */
        myStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: myStore.url(options),
            method: 'post',
        })
    
    myStore.form = myStoreForm
/**
* @see \App\Http\Controllers\SalesLeadController::myShow
 * @see app/Http/Controllers/SalesLeadController.php:121
 * @route '/my/sales-leads/{salesLead}'
 */
export const myShow = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myShow.url(args, options),
    method: 'get',
})

myShow.definition = {
    methods: ["get","head"],
    url: '/my/sales-leads/{salesLead}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesLeadController::myShow
 * @see app/Http/Controllers/SalesLeadController.php:121
 * @route '/my/sales-leads/{salesLead}'
 */
myShow.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return myShow.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::myShow
 * @see app/Http/Controllers/SalesLeadController.php:121
 * @route '/my/sales-leads/{salesLead}'
 */
myShow.get = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myShow.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SalesLeadController::myShow
 * @see app/Http/Controllers/SalesLeadController.php:121
 * @route '/my/sales-leads/{salesLead}'
 */
myShow.head = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myShow.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::myShow
 * @see app/Http/Controllers/SalesLeadController.php:121
 * @route '/my/sales-leads/{salesLead}'
 */
    const myShowForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: myShow.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::myShow
 * @see app/Http/Controllers/SalesLeadController.php:121
 * @route '/my/sales-leads/{salesLead}'
 */
        myShowForm.get = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myShow.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SalesLeadController::myShow
 * @see app/Http/Controllers/SalesLeadController.php:121
 * @route '/my/sales-leads/{salesLead}'
 */
        myShowForm.head = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myShow.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    myShow.form = myShowForm
/**
* @see \App\Http\Controllers\SalesLeadController::myUpdate
 * @see app/Http/Controllers/SalesLeadController.php:175
 * @route '/my/sales-leads/{salesLead}'
 */
export const myUpdate = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: myUpdate.url(args, options),
    method: 'patch',
})

myUpdate.definition = {
    methods: ["patch"],
    url: '/my/sales-leads/{salesLead}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\SalesLeadController::myUpdate
 * @see app/Http/Controllers/SalesLeadController.php:175
 * @route '/my/sales-leads/{salesLead}'
 */
myUpdate.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return myUpdate.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::myUpdate
 * @see app/Http/Controllers/SalesLeadController.php:175
 * @route '/my/sales-leads/{salesLead}'
 */
myUpdate.patch = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: myUpdate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::myUpdate
 * @see app/Http/Controllers/SalesLeadController.php:175
 * @route '/my/sales-leads/{salesLead}'
 */
    const myUpdateForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: myUpdate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::myUpdate
 * @see app/Http/Controllers/SalesLeadController.php:175
 * @route '/my/sales-leads/{salesLead}'
 */
        myUpdateForm.patch = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: myUpdate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    myUpdate.form = myUpdateForm
/**
* @see \App\Http\Controllers\SalesLeadController::myStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:289
 * @route '/my/sales-leads/{salesLead}/activities'
 */
export const myStoreActivity = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: myStoreActivity.url(args, options),
    method: 'post',
})

myStoreActivity.definition = {
    methods: ["post"],
    url: '/my/sales-leads/{salesLead}/activities',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::myStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:289
 * @route '/my/sales-leads/{salesLead}/activities'
 */
myStoreActivity.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return myStoreActivity.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::myStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:289
 * @route '/my/sales-leads/{salesLead}/activities'
 */
myStoreActivity.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: myStoreActivity.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::myStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:289
 * @route '/my/sales-leads/{salesLead}/activities'
 */
    const myStoreActivityForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: myStoreActivity.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::myStoreActivity
 * @see app/Http/Controllers/SalesLeadController.php:289
 * @route '/my/sales-leads/{salesLead}/activities'
 */
        myStoreActivityForm.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: myStoreActivity.url(args, options),
            method: 'post',
        })
    
    myStoreActivity.form = myStoreActivityForm
/**
* @see \App\Http\Controllers\SalesLeadController::myCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:296
 * @route '/my/sales-leads/{salesLead}/complete-follow-up'
 */
export const myCompleteFollowUp = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: myCompleteFollowUp.url(args, options),
    method: 'post',
})

myCompleteFollowUp.definition = {
    methods: ["post"],
    url: '/my/sales-leads/{salesLead}/complete-follow-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::myCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:296
 * @route '/my/sales-leads/{salesLead}/complete-follow-up'
 */
myCompleteFollowUp.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return myCompleteFollowUp.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::myCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:296
 * @route '/my/sales-leads/{salesLead}/complete-follow-up'
 */
myCompleteFollowUp.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: myCompleteFollowUp.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::myCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:296
 * @route '/my/sales-leads/{salesLead}/complete-follow-up'
 */
    const myCompleteFollowUpForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: myCompleteFollowUp.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::myCompleteFollowUp
 * @see app/Http/Controllers/SalesLeadController.php:296
 * @route '/my/sales-leads/{salesLead}/complete-follow-up'
 */
        myCompleteFollowUpForm.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: myCompleteFollowUp.url(args, options),
            method: 'post',
        })
    
    myCompleteFollowUp.form = myCompleteFollowUpForm
/**
* @see \App\Http\Controllers\SalesLeadController::myCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:303
 * @route '/my/sales-leads/{salesLead}/close-deal'
 */
export const myCloseDeal = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: myCloseDeal.url(args, options),
    method: 'post',
})

myCloseDeal.definition = {
    methods: ["post"],
    url: '/my/sales-leads/{salesLead}/close-deal',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesLeadController::myCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:303
 * @route '/my/sales-leads/{salesLead}/close-deal'
 */
myCloseDeal.url = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salesLead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salesLead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salesLead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salesLead: typeof args.salesLead === 'object'
                ? args.salesLead.id
                : args.salesLead,
                }

    return myCloseDeal.definition.url
            .replace('{salesLead}', parsedArgs.salesLead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesLeadController::myCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:303
 * @route '/my/sales-leads/{salesLead}/close-deal'
 */
myCloseDeal.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: myCloseDeal.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesLeadController::myCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:303
 * @route '/my/sales-leads/{salesLead}/close-deal'
 */
    const myCloseDealForm = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: myCloseDeal.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesLeadController::myCloseDeal
 * @see app/Http/Controllers/SalesLeadController.php:303
 * @route '/my/sales-leads/{salesLead}/close-deal'
 */
        myCloseDealForm.post = (args: { salesLead: number | { id: number } } | [salesLead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: myCloseDeal.url(args, options),
            method: 'post',
        })
    
    myCloseDeal.form = myCloseDealForm
const SalesLeadController = { adminIndex, adminData, adminReport, adminExport, adminStore, adminShow, adminUpdate, adminDestroy, adminConvert, adminStoreActivity, adminCompleteFollowUp, adminCloseDeal, adminSendReminders, myIndex, myData, myStore, myShow, myUpdate, myStoreActivity, myCompleteFollowUp, myCloseDeal }

export default SalesLeadController