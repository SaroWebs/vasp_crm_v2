import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\HolidayWorkController::index
 * @see app/Http/Controllers/HolidayWorkController.php:13
 * @route '/api/holiday-work-records'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/holiday-work-records',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HolidayWorkController::index
 * @see app/Http/Controllers/HolidayWorkController.php:13
 * @route '/api/holiday-work-records'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HolidayWorkController::index
 * @see app/Http/Controllers/HolidayWorkController.php:13
 * @route '/api/holiday-work-records'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HolidayWorkController::index
 * @see app/Http/Controllers/HolidayWorkController.php:13
 * @route '/api/holiday-work-records'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HolidayWorkController::index
 * @see app/Http/Controllers/HolidayWorkController.php:13
 * @route '/api/holiday-work-records'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HolidayWorkController::index
 * @see app/Http/Controllers/HolidayWorkController.php:13
 * @route '/api/holiday-work-records'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HolidayWorkController::index
 * @see app/Http/Controllers/HolidayWorkController.php:13
 * @route '/api/holiday-work-records'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\HolidayWorkController::store
 * @see app/Http/Controllers/HolidayWorkController.php:35
 * @route '/api/holiday-work-records'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/holiday-work-records',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HolidayWorkController::store
 * @see app/Http/Controllers/HolidayWorkController.php:35
 * @route '/api/holiday-work-records'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HolidayWorkController::store
 * @see app/Http/Controllers/HolidayWorkController.php:35
 * @route '/api/holiday-work-records'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HolidayWorkController::store
 * @see app/Http/Controllers/HolidayWorkController.php:35
 * @route '/api/holiday-work-records'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HolidayWorkController::store
 * @see app/Http/Controllers/HolidayWorkController.php:35
 * @route '/api/holiday-work-records'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\HolidayWorkController::show
 * @see app/Http/Controllers/HolidayWorkController.php:57
 * @route '/api/holiday-work-records/{holidayWorkRecord}'
 */
export const show = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/holiday-work-records/{holidayWorkRecord}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HolidayWorkController::show
 * @see app/Http/Controllers/HolidayWorkController.php:57
 * @route '/api/holiday-work-records/{holidayWorkRecord}'
 */
show.url = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { holidayWorkRecord: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { holidayWorkRecord: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    holidayWorkRecord: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        holidayWorkRecord: typeof args.holidayWorkRecord === 'object'
                ? args.holidayWorkRecord.id
                : args.holidayWorkRecord,
                }

    return show.definition.url
            .replace('{holidayWorkRecord}', parsedArgs.holidayWorkRecord.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HolidayWorkController::show
 * @see app/Http/Controllers/HolidayWorkController.php:57
 * @route '/api/holiday-work-records/{holidayWorkRecord}'
 */
show.get = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HolidayWorkController::show
 * @see app/Http/Controllers/HolidayWorkController.php:57
 * @route '/api/holiday-work-records/{holidayWorkRecord}'
 */
show.head = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HolidayWorkController::show
 * @see app/Http/Controllers/HolidayWorkController.php:57
 * @route '/api/holiday-work-records/{holidayWorkRecord}'
 */
    const showForm = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HolidayWorkController::show
 * @see app/Http/Controllers/HolidayWorkController.php:57
 * @route '/api/holiday-work-records/{holidayWorkRecord}'
 */
        showForm.get = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HolidayWorkController::show
 * @see app/Http/Controllers/HolidayWorkController.php:57
 * @route '/api/holiday-work-records/{holidayWorkRecord}'
 */
        showForm.head = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\HolidayWorkController::approve
 * @see app/Http/Controllers/HolidayWorkController.php:64
 * @route '/api/holiday-work-records/{holidayWorkRecord}/approve'
 */
export const approve = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/holiday-work-records/{holidayWorkRecord}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HolidayWorkController::approve
 * @see app/Http/Controllers/HolidayWorkController.php:64
 * @route '/api/holiday-work-records/{holidayWorkRecord}/approve'
 */
approve.url = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { holidayWorkRecord: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { holidayWorkRecord: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    holidayWorkRecord: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        holidayWorkRecord: typeof args.holidayWorkRecord === 'object'
                ? args.holidayWorkRecord.id
                : args.holidayWorkRecord,
                }

    return approve.definition.url
            .replace('{holidayWorkRecord}', parsedArgs.holidayWorkRecord.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HolidayWorkController::approve
 * @see app/Http/Controllers/HolidayWorkController.php:64
 * @route '/api/holiday-work-records/{holidayWorkRecord}/approve'
 */
approve.post = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HolidayWorkController::approve
 * @see app/Http/Controllers/HolidayWorkController.php:64
 * @route '/api/holiday-work-records/{holidayWorkRecord}/approve'
 */
    const approveForm = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HolidayWorkController::approve
 * @see app/Http/Controllers/HolidayWorkController.php:64
 * @route '/api/holiday-work-records/{holidayWorkRecord}/approve'
 */
        approveForm.post = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\HolidayWorkController::reject
 * @see app/Http/Controllers/HolidayWorkController.php:87
 * @route '/api/holiday-work-records/{holidayWorkRecord}/reject'
 */
export const reject = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/api/holiday-work-records/{holidayWorkRecord}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HolidayWorkController::reject
 * @see app/Http/Controllers/HolidayWorkController.php:87
 * @route '/api/holiday-work-records/{holidayWorkRecord}/reject'
 */
reject.url = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { holidayWorkRecord: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { holidayWorkRecord: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    holidayWorkRecord: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        holidayWorkRecord: typeof args.holidayWorkRecord === 'object'
                ? args.holidayWorkRecord.id
                : args.holidayWorkRecord,
                }

    return reject.definition.url
            .replace('{holidayWorkRecord}', parsedArgs.holidayWorkRecord.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HolidayWorkController::reject
 * @see app/Http/Controllers/HolidayWorkController.php:87
 * @route '/api/holiday-work-records/{holidayWorkRecord}/reject'
 */
reject.post = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HolidayWorkController::reject
 * @see app/Http/Controllers/HolidayWorkController.php:87
 * @route '/api/holiday-work-records/{holidayWorkRecord}/reject'
 */
    const rejectForm = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HolidayWorkController::reject
 * @see app/Http/Controllers/HolidayWorkController.php:87
 * @route '/api/holiday-work-records/{holidayWorkRecord}/reject'
 */
        rejectForm.post = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\HolidayWorkController::createCompensatoryOff
 * @see app/Http/Controllers/HolidayWorkController.php:131
 * @route '/api/holiday-work-records/{holidayWorkRecord}/compensatory-off'
 */
export const createCompensatoryOff = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createCompensatoryOff.url(args, options),
    method: 'post',
})

createCompensatoryOff.definition = {
    methods: ["post"],
    url: '/api/holiday-work-records/{holidayWorkRecord}/compensatory-off',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HolidayWorkController::createCompensatoryOff
 * @see app/Http/Controllers/HolidayWorkController.php:131
 * @route '/api/holiday-work-records/{holidayWorkRecord}/compensatory-off'
 */
createCompensatoryOff.url = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { holidayWorkRecord: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { holidayWorkRecord: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    holidayWorkRecord: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        holidayWorkRecord: typeof args.holidayWorkRecord === 'object'
                ? args.holidayWorkRecord.id
                : args.holidayWorkRecord,
                }

    return createCompensatoryOff.definition.url
            .replace('{holidayWorkRecord}', parsedArgs.holidayWorkRecord.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HolidayWorkController::createCompensatoryOff
 * @see app/Http/Controllers/HolidayWorkController.php:131
 * @route '/api/holiday-work-records/{holidayWorkRecord}/compensatory-off'
 */
createCompensatoryOff.post = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createCompensatoryOff.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HolidayWorkController::createCompensatoryOff
 * @see app/Http/Controllers/HolidayWorkController.php:131
 * @route '/api/holiday-work-records/{holidayWorkRecord}/compensatory-off'
 */
    const createCompensatoryOffForm = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: createCompensatoryOff.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HolidayWorkController::createCompensatoryOff
 * @see app/Http/Controllers/HolidayWorkController.php:131
 * @route '/api/holiday-work-records/{holidayWorkRecord}/compensatory-off'
 */
        createCompensatoryOffForm.post = (args: { holidayWorkRecord: number | { id: number } } | [holidayWorkRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: createCompensatoryOff.url(args, options),
            method: 'post',
        })
    
    createCompensatoryOff.form = createCompensatoryOffForm
/**
* @see \App\Http\Controllers\HolidayWorkController::getEmployeeHolidayWork
 * @see app/Http/Controllers/HolidayWorkController.php:110
 * @route '/api/employees/{employee}/holiday-work-records'
 */
export const getEmployeeHolidayWork = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeHolidayWork.url(args, options),
    method: 'get',
})

getEmployeeHolidayWork.definition = {
    methods: ["get","head"],
    url: '/api/employees/{employee}/holiday-work-records',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HolidayWorkController::getEmployeeHolidayWork
 * @see app/Http/Controllers/HolidayWorkController.php:110
 * @route '/api/employees/{employee}/holiday-work-records'
 */
getEmployeeHolidayWork.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return getEmployeeHolidayWork.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HolidayWorkController::getEmployeeHolidayWork
 * @see app/Http/Controllers/HolidayWorkController.php:110
 * @route '/api/employees/{employee}/holiday-work-records'
 */
getEmployeeHolidayWork.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeHolidayWork.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HolidayWorkController::getEmployeeHolidayWork
 * @see app/Http/Controllers/HolidayWorkController.php:110
 * @route '/api/employees/{employee}/holiday-work-records'
 */
getEmployeeHolidayWork.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeHolidayWork.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HolidayWorkController::getEmployeeHolidayWork
 * @see app/Http/Controllers/HolidayWorkController.php:110
 * @route '/api/employees/{employee}/holiday-work-records'
 */
    const getEmployeeHolidayWorkForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeHolidayWork.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HolidayWorkController::getEmployeeHolidayWork
 * @see app/Http/Controllers/HolidayWorkController.php:110
 * @route '/api/employees/{employee}/holiday-work-records'
 */
        getEmployeeHolidayWorkForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeHolidayWork.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HolidayWorkController::getEmployeeHolidayWork
 * @see app/Http/Controllers/HolidayWorkController.php:110
 * @route '/api/employees/{employee}/holiday-work-records'
 */
        getEmployeeHolidayWorkForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeHolidayWork.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeHolidayWork.form = getEmployeeHolidayWorkForm
/**
* @see \App\Http\Controllers\HolidayWorkController::getCompensatoryOffs
 * @see app/Http/Controllers/HolidayWorkController.php:151
 * @route '/api/employees/{employee}/compensatory-offs'
 */
export const getCompensatoryOffs = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCompensatoryOffs.url(args, options),
    method: 'get',
})

getCompensatoryOffs.definition = {
    methods: ["get","head"],
    url: '/api/employees/{employee}/compensatory-offs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HolidayWorkController::getCompensatoryOffs
 * @see app/Http/Controllers/HolidayWorkController.php:151
 * @route '/api/employees/{employee}/compensatory-offs'
 */
getCompensatoryOffs.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return getCompensatoryOffs.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HolidayWorkController::getCompensatoryOffs
 * @see app/Http/Controllers/HolidayWorkController.php:151
 * @route '/api/employees/{employee}/compensatory-offs'
 */
getCompensatoryOffs.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getCompensatoryOffs.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HolidayWorkController::getCompensatoryOffs
 * @see app/Http/Controllers/HolidayWorkController.php:151
 * @route '/api/employees/{employee}/compensatory-offs'
 */
getCompensatoryOffs.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getCompensatoryOffs.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HolidayWorkController::getCompensatoryOffs
 * @see app/Http/Controllers/HolidayWorkController.php:151
 * @route '/api/employees/{employee}/compensatory-offs'
 */
    const getCompensatoryOffsForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getCompensatoryOffs.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HolidayWorkController::getCompensatoryOffs
 * @see app/Http/Controllers/HolidayWorkController.php:151
 * @route '/api/employees/{employee}/compensatory-offs'
 */
        getCompensatoryOffsForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getCompensatoryOffs.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HolidayWorkController::getCompensatoryOffs
 * @see app/Http/Controllers/HolidayWorkController.php:151
 * @route '/api/employees/{employee}/compensatory-offs'
 */
        getCompensatoryOffsForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getCompensatoryOffs.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getCompensatoryOffs.form = getCompensatoryOffsForm
const HolidayWorkController = { index, store, show, approve, reject, createCompensatoryOff, getEmployeeHolidayWork, getCompensatoryOffs }

export default HolidayWorkController