import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MenuManagementController::index
 * @see app/Http/Controllers/MenuManagementController.php:61
 * @route '/admin/menu'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/menu',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MenuManagementController::index
 * @see app/Http/Controllers/MenuManagementController.php:61
 * @route '/admin/menu'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MenuManagementController::index
 * @see app/Http/Controllers/MenuManagementController.php:61
 * @route '/admin/menu'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MenuManagementController::index
 * @see app/Http/Controllers/MenuManagementController.php:61
 * @route '/admin/menu'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MenuManagementController::index
 * @see app/Http/Controllers/MenuManagementController.php:61
 * @route '/admin/menu'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MenuManagementController::index
 * @see app/Http/Controllers/MenuManagementController.php:61
 * @route '/admin/menu'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MenuManagementController::index
 * @see app/Http/Controllers/MenuManagementController.php:61
 * @route '/admin/menu'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MenuManagementController::update
 * @see app/Http/Controllers/MenuManagementController.php:123
 * @route '/admin/menu'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/menu',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\MenuManagementController::update
 * @see app/Http/Controllers/MenuManagementController.php:123
 * @route '/admin/menu'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MenuManagementController::update
 * @see app/Http/Controllers/MenuManagementController.php:123
 * @route '/admin/menu'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\MenuManagementController::update
 * @see app/Http/Controllers/MenuManagementController.php:123
 * @route '/admin/menu'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MenuManagementController::update
 * @see app/Http/Controllers/MenuManagementController.php:123
 * @route '/admin/menu'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const MenuManagementController = { index, update }

export default MenuManagementController