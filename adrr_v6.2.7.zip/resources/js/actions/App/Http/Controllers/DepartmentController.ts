import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/departments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::index
 * @see app/Http/Controllers/DepartmentController.php:52
 * @route '/admin/departments'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/departments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::store
 * @see app/Http/Controllers/DepartmentController.php:81
 * @route '/admin/departments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/departments/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::create
 * @see app/Http/Controllers/DepartmentController.php:68
 * @route '/admin/departments/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\DepartmentController::getData
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
export const getData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getData.url(options),
    method: 'get',
})

getData.definition = {
    methods: ["get","head"],
    url: '/admin/departments/data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::getData
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
getData.url = (options?: RouteQueryOptions) => {
    return getData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::getData
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
getData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getData.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::getData
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
getData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getData.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::getData
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
    const getDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getData.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::getData
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
        getDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getData.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::getData
 * @see app/Http/Controllers/DepartmentController.php:27
 * @route '/admin/departments/data'
 */
        getDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getData.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getData.form = getDataForm
/**
* @see \App\Http\Controllers\DepartmentController::getAvailableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
export const getAvailableUsers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableUsers.url(options),
    method: 'get',
})

getAvailableUsers.definition = {
    methods: ["get","head"],
    url: '/admin/departments/available-users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::getAvailableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
getAvailableUsers.url = (options?: RouteQueryOptions) => {
    return getAvailableUsers.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::getAvailableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
getAvailableUsers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableUsers.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::getAvailableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
getAvailableUsers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAvailableUsers.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::getAvailableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
    const getAvailableUsersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getAvailableUsers.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::getAvailableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
        getAvailableUsersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAvailableUsers.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::getAvailableUsers
 * @see app/Http/Controllers/DepartmentController.php:457
 * @route '/admin/departments/available-users'
 */
        getAvailableUsersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAvailableUsers.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getAvailableUsers.form = getAvailableUsersForm
/**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
export const assignUser = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignUser.url(args, options),
    method: 'post',
})

assignUser.definition = {
    methods: ["post"],
    url: '/admin/departments/{department}/assign-user',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
assignUser.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return assignUser.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
assignUser.post = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignUser.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
    const assignUserForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assignUser.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::assignUser
 * @see app/Http/Controllers/DepartmentController.php:260
 * @route '/admin/departments/{department}/assign-user'
 */
        assignUserForm.post = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assignUser.url(args, options),
            method: 'post',
        })
    
    assignUser.form = assignUserForm
/**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
export const removeUser = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeUser.url(args, options),
    method: 'delete',
})

removeUser.definition = {
    methods: ["delete"],
    url: '/admin/departments/{department}/remove-user/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
removeUser.url = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return removeUser.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
removeUser.delete = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeUser.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
    const removeUserForm = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: removeUser.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::removeUser
 * @see app/Http/Controllers/DepartmentController.php:343
 * @route '/admin/departments/{department}/remove-user/{user}'
 */
        removeUserForm.delete = (args: { department: number | { id: number }, user: number | { id: number } } | [department: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: removeUser.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    removeUser.form = removeUserForm
/**
* @see \App\Http\Controllers\DepartmentController::getStatistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
export const getStatistics = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStatistics.url(args, options),
    method: 'get',
})

getStatistics.definition = {
    methods: ["get","head"],
    url: '/admin/departments/{department}/statistics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::getStatistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
getStatistics.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return getStatistics.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::getStatistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
getStatistics.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStatistics.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::getStatistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
getStatistics.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStatistics.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::getStatistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
    const getStatisticsForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getStatistics.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::getStatistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
        getStatisticsForm.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStatistics.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::getStatistics
 * @see app/Http/Controllers/DepartmentController.php:406
 * @route '/admin/departments/{department}/statistics'
 */
        getStatisticsForm.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStatistics.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getStatistics.form = getStatisticsForm
/**
* @see \App\Http\Controllers\DepartmentController::bulkAssignUsers
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
export const bulkAssignUsers = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAssignUsers.url(args, options),
    method: 'post',
})

bulkAssignUsers.definition = {
    methods: ["post"],
    url: '/admin/departments/{department}/bulk-assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DepartmentController::bulkAssignUsers
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
bulkAssignUsers.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return bulkAssignUsers.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::bulkAssignUsers
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
bulkAssignUsers.post = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAssignUsers.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DepartmentController::bulkAssignUsers
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
    const bulkAssignUsersForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkAssignUsers.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::bulkAssignUsers
 * @see app/Http/Controllers/DepartmentController.php:472
 * @route '/admin/departments/{department}/bulk-assign'
 */
        bulkAssignUsersForm.post = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkAssignUsers.url(args, options),
            method: 'post',
        })
    
    bulkAssignUsers.form = bulkAssignUsersForm
/**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
export const show = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/departments/{department}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
show.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return show.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
show.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
show.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
    const showForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
        showForm.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::show
 * @see app/Http/Controllers/DepartmentController.php:117
 * @route '/admin/departments/{department}'
 */
        showForm.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
export const edit = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/departments/{department}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
edit.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return edit.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
edit.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
edit.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
    const editForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
        editForm.get = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DepartmentController::edit
 * @see app/Http/Controllers/DepartmentController.php:137
 * @route '/admin/departments/{department}/edit'
 */
        editForm.head = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
export const update = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/departments/{department}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
update.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return update.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
update.patch = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
    const updateForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::update
 * @see app/Http/Controllers/DepartmentController.php:154
 * @route '/admin/departments/{department}'
 */
        updateForm.patch = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
export const destroy = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/departments/{department}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
destroy.url = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { department: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { department: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    department: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        department: typeof args.department === 'object'
                ? args.department.id
                : args.department,
                }

    return destroy.definition.url
            .replace('{department}', parsedArgs.department.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
destroy.delete = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
    const destroyForm = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DepartmentController::destroy
 * @see app/Http/Controllers/DepartmentController.php:204
 * @route '/admin/departments/{department}'
 */
        destroyForm.delete = (args: { department: number | { id: number } } | [department: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DepartmentController = { index, store, create, getData, getAvailableUsers, assignUser, removeUser, getStatistics, bulkAssignUsers, show, edit, update, destroy }

export default DepartmentController