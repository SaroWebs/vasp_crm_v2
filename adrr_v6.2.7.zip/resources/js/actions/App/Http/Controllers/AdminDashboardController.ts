import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminDashboardController::index
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::index
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::index
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::index
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::index
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::index
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::index
 * @see app/Http/Controllers/AdminDashboardController.php:23
 * @route '/admin/dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminDashboardController::getStats
 * @see app/Http/Controllers/AdminDashboardController.php:39
 * @route '/admin/api/dashboard/stats'
 */
export const getStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStats.url(options),
    method: 'get',
})

getStats.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::getStats
 * @see app/Http/Controllers/AdminDashboardController.php:39
 * @route '/admin/api/dashboard/stats'
 */
getStats.url = (options?: RouteQueryOptions) => {
    return getStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::getStats
 * @see app/Http/Controllers/AdminDashboardController.php:39
 * @route '/admin/api/dashboard/stats'
 */
getStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::getStats
 * @see app/Http/Controllers/AdminDashboardController.php:39
 * @route '/admin/api/dashboard/stats'
 */
getStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::getStats
 * @see app/Http/Controllers/AdminDashboardController.php:39
 * @route '/admin/api/dashboard/stats'
 */
    const getStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getStats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::getStats
 * @see app/Http/Controllers/AdminDashboardController.php:39
 * @route '/admin/api/dashboard/stats'
 */
        getStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::getStats
 * @see app/Http/Controllers/AdminDashboardController.php:39
 * @route '/admin/api/dashboard/stats'
 */
        getStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getStats.form = getStatsForm
/**
* @see \App\Http\Controllers\AdminDashboardController::getTickets
 * @see app/Http/Controllers/AdminDashboardController.php:54
 * @route '/admin/api/dashboard/tickets'
 */
export const getTickets = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTickets.url(options),
    method: 'get',
})

getTickets.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/tickets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::getTickets
 * @see app/Http/Controllers/AdminDashboardController.php:54
 * @route '/admin/api/dashboard/tickets'
 */
getTickets.url = (options?: RouteQueryOptions) => {
    return getTickets.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::getTickets
 * @see app/Http/Controllers/AdminDashboardController.php:54
 * @route '/admin/api/dashboard/tickets'
 */
getTickets.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTickets.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::getTickets
 * @see app/Http/Controllers/AdminDashboardController.php:54
 * @route '/admin/api/dashboard/tickets'
 */
getTickets.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTickets.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::getTickets
 * @see app/Http/Controllers/AdminDashboardController.php:54
 * @route '/admin/api/dashboard/tickets'
 */
    const getTicketsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTickets.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::getTickets
 * @see app/Http/Controllers/AdminDashboardController.php:54
 * @route '/admin/api/dashboard/tickets'
 */
        getTicketsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTickets.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::getTickets
 * @see app/Http/Controllers/AdminDashboardController.php:54
 * @route '/admin/api/dashboard/tickets'
 */
        getTicketsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTickets.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTickets.form = getTicketsForm
/**
* @see \App\Http\Controllers\AdminDashboardController::getTasks
 * @see app/Http/Controllers/AdminDashboardController.php:59
 * @route '/admin/api/dashboard/tasks'
 */
export const getTasks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTasks.url(options),
    method: 'get',
})

getTasks.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::getTasks
 * @see app/Http/Controllers/AdminDashboardController.php:59
 * @route '/admin/api/dashboard/tasks'
 */
getTasks.url = (options?: RouteQueryOptions) => {
    return getTasks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::getTasks
 * @see app/Http/Controllers/AdminDashboardController.php:59
 * @route '/admin/api/dashboard/tasks'
 */
getTasks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTasks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::getTasks
 * @see app/Http/Controllers/AdminDashboardController.php:59
 * @route '/admin/api/dashboard/tasks'
 */
getTasks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTasks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::getTasks
 * @see app/Http/Controllers/AdminDashboardController.php:59
 * @route '/admin/api/dashboard/tasks'
 */
    const getTasksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTasks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::getTasks
 * @see app/Http/Controllers/AdminDashboardController.php:59
 * @route '/admin/api/dashboard/tasks'
 */
        getTasksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTasks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::getTasks
 * @see app/Http/Controllers/AdminDashboardController.php:59
 * @route '/admin/api/dashboard/tasks'
 */
        getTasksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTasks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTasks.form = getTasksForm
/**
* @see \App\Http\Controllers\AdminDashboardController::getActivities
 * @see app/Http/Controllers/AdminDashboardController.php:74
 * @route '/admin/api/dashboard/activities'
 */
export const getActivities = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getActivities.url(options),
    method: 'get',
})

getActivities.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/activities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::getActivities
 * @see app/Http/Controllers/AdminDashboardController.php:74
 * @route '/admin/api/dashboard/activities'
 */
getActivities.url = (options?: RouteQueryOptions) => {
    return getActivities.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::getActivities
 * @see app/Http/Controllers/AdminDashboardController.php:74
 * @route '/admin/api/dashboard/activities'
 */
getActivities.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getActivities.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::getActivities
 * @see app/Http/Controllers/AdminDashboardController.php:74
 * @route '/admin/api/dashboard/activities'
 */
getActivities.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getActivities.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::getActivities
 * @see app/Http/Controllers/AdminDashboardController.php:74
 * @route '/admin/api/dashboard/activities'
 */
    const getActivitiesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getActivities.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::getActivities
 * @see app/Http/Controllers/AdminDashboardController.php:74
 * @route '/admin/api/dashboard/activities'
 */
        getActivitiesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getActivities.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::getActivities
 * @see app/Http/Controllers/AdminDashboardController.php:74
 * @route '/admin/api/dashboard/activities'
 */
        getActivitiesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getActivities.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getActivities.form = getActivitiesForm
/**
* @see \App\Http\Controllers\AdminDashboardController::getChartData
 * @see app/Http/Controllers/AdminDashboardController.php:83
 * @route '/admin/api/dashboard/chart-data'
 */
export const getChartData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getChartData.url(options),
    method: 'get',
})

getChartData.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/chart-data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::getChartData
 * @see app/Http/Controllers/AdminDashboardController.php:83
 * @route '/admin/api/dashboard/chart-data'
 */
getChartData.url = (options?: RouteQueryOptions) => {
    return getChartData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::getChartData
 * @see app/Http/Controllers/AdminDashboardController.php:83
 * @route '/admin/api/dashboard/chart-data'
 */
getChartData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getChartData.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::getChartData
 * @see app/Http/Controllers/AdminDashboardController.php:83
 * @route '/admin/api/dashboard/chart-data'
 */
getChartData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getChartData.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::getChartData
 * @see app/Http/Controllers/AdminDashboardController.php:83
 * @route '/admin/api/dashboard/chart-data'
 */
    const getChartDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getChartData.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::getChartData
 * @see app/Http/Controllers/AdminDashboardController.php:83
 * @route '/admin/api/dashboard/chart-data'
 */
        getChartDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getChartData.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::getChartData
 * @see app/Http/Controllers/AdminDashboardController.php:83
 * @route '/admin/api/dashboard/chart-data'
 */
        getChartDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getChartData.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getChartData.form = getChartDataForm
/**
* @see \App\Http\Controllers\AdminDashboardController::getRecentReports
 * @see app/Http/Controllers/AdminDashboardController.php:94
 * @route '/admin/api/dashboard/recent-reports'
 */
export const getRecentReports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getRecentReports.url(options),
    method: 'get',
})

getRecentReports.definition = {
    methods: ["get","head"],
    url: '/admin/api/dashboard/recent-reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminDashboardController::getRecentReports
 * @see app/Http/Controllers/AdminDashboardController.php:94
 * @route '/admin/api/dashboard/recent-reports'
 */
getRecentReports.url = (options?: RouteQueryOptions) => {
    return getRecentReports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminDashboardController::getRecentReports
 * @see app/Http/Controllers/AdminDashboardController.php:94
 * @route '/admin/api/dashboard/recent-reports'
 */
getRecentReports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getRecentReports.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminDashboardController::getRecentReports
 * @see app/Http/Controllers/AdminDashboardController.php:94
 * @route '/admin/api/dashboard/recent-reports'
 */
getRecentReports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getRecentReports.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminDashboardController::getRecentReports
 * @see app/Http/Controllers/AdminDashboardController.php:94
 * @route '/admin/api/dashboard/recent-reports'
 */
    const getRecentReportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getRecentReports.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminDashboardController::getRecentReports
 * @see app/Http/Controllers/AdminDashboardController.php:94
 * @route '/admin/api/dashboard/recent-reports'
 */
        getRecentReportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getRecentReports.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminDashboardController::getRecentReports
 * @see app/Http/Controllers/AdminDashboardController.php:94
 * @route '/admin/api/dashboard/recent-reports'
 */
        getRecentReportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getRecentReports.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getRecentReports.form = getRecentReportsForm
const AdminDashboardController = { index, getStats, getTickets, getTasks, getActivities, getChartData, getRecentReports }

export default AdminDashboardController