import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LeaveController::index
 * @see app/Http/Controllers/LeaveController.php:22
 * @route '/api/leave-requests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/leave-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaveController::index
 * @see app/Http/Controllers/LeaveController.php:22
 * @route '/api/leave-requests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveController::index
 * @see app/Http/Controllers/LeaveController.php:22
 * @route '/api/leave-requests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LeaveController::index
 * @see app/Http/Controllers/LeaveController.php:22
 * @route '/api/leave-requests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LeaveController::index
 * @see app/Http/Controllers/LeaveController.php:22
 * @route '/api/leave-requests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LeaveController::index
 * @see app/Http/Controllers/LeaveController.php:22
 * @route '/api/leave-requests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LeaveController::index
 * @see app/Http/Controllers/LeaveController.php:22
 * @route '/api/leave-requests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\LeaveController::store
 * @see app/Http/Controllers/LeaveController.php:54
 * @route '/api/leave-requests'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/leave-requests',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LeaveController::store
 * @see app/Http/Controllers/LeaveController.php:54
 * @route '/api/leave-requests'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveController::store
 * @see app/Http/Controllers/LeaveController.php:54
 * @route '/api/leave-requests'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LeaveController::store
 * @see app/Http/Controllers/LeaveController.php:54
 * @route '/api/leave-requests'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LeaveController::store
 * @see app/Http/Controllers/LeaveController.php:54
 * @route '/api/leave-requests'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\LeaveController::show
 * @see app/Http/Controllers/LeaveController.php:109
 * @route '/api/leave-requests/{leaveRequest}'
 */
export const show = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/leave-requests/{leaveRequest}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaveController::show
 * @see app/Http/Controllers/LeaveController.php:109
 * @route '/api/leave-requests/{leaveRequest}'
 */
show.url = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leaveRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { leaveRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    leaveRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        leaveRequest: typeof args.leaveRequest === 'object'
                ? args.leaveRequest.id
                : args.leaveRequest,
                }

    return show.definition.url
            .replace('{leaveRequest}', parsedArgs.leaveRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveController::show
 * @see app/Http/Controllers/LeaveController.php:109
 * @route '/api/leave-requests/{leaveRequest}'
 */
show.get = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LeaveController::show
 * @see app/Http/Controllers/LeaveController.php:109
 * @route '/api/leave-requests/{leaveRequest}'
 */
show.head = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LeaveController::show
 * @see app/Http/Controllers/LeaveController.php:109
 * @route '/api/leave-requests/{leaveRequest}'
 */
    const showForm = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LeaveController::show
 * @see app/Http/Controllers/LeaveController.php:109
 * @route '/api/leave-requests/{leaveRequest}'
 */
        showForm.get = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LeaveController::show
 * @see app/Http/Controllers/LeaveController.php:109
 * @route '/api/leave-requests/{leaveRequest}'
 */
        showForm.head = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\LeaveController::update
 * @see app/Http/Controllers/LeaveController.php:120
 * @route '/api/leave-requests/{leaveRequest}'
 */
export const update = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/leave-requests/{leaveRequest}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LeaveController::update
 * @see app/Http/Controllers/LeaveController.php:120
 * @route '/api/leave-requests/{leaveRequest}'
 */
update.url = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leaveRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { leaveRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    leaveRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        leaveRequest: typeof args.leaveRequest === 'object'
                ? args.leaveRequest.id
                : args.leaveRequest,
                }

    return update.definition.url
            .replace('{leaveRequest}', parsedArgs.leaveRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveController::update
 * @see app/Http/Controllers/LeaveController.php:120
 * @route '/api/leave-requests/{leaveRequest}'
 */
update.put = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\LeaveController::update
 * @see app/Http/Controllers/LeaveController.php:120
 * @route '/api/leave-requests/{leaveRequest}'
 */
    const updateForm = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LeaveController::update
 * @see app/Http/Controllers/LeaveController.php:120
 * @route '/api/leave-requests/{leaveRequest}'
 */
        updateForm.put = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\LeaveController::destroy
 * @see app/Http/Controllers/LeaveController.php:140
 * @route '/api/leave-requests/{leaveRequest}'
 */
export const destroy = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/leave-requests/{leaveRequest}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\LeaveController::destroy
 * @see app/Http/Controllers/LeaveController.php:140
 * @route '/api/leave-requests/{leaveRequest}'
 */
destroy.url = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leaveRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { leaveRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    leaveRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        leaveRequest: typeof args.leaveRequest === 'object'
                ? args.leaveRequest.id
                : args.leaveRequest,
                }

    return destroy.definition.url
            .replace('{leaveRequest}', parsedArgs.leaveRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveController::destroy
 * @see app/Http/Controllers/LeaveController.php:140
 * @route '/api/leave-requests/{leaveRequest}'
 */
destroy.delete = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\LeaveController::destroy
 * @see app/Http/Controllers/LeaveController.php:140
 * @route '/api/leave-requests/{leaveRequest}'
 */
    const destroyForm = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LeaveController::destroy
 * @see app/Http/Controllers/LeaveController.php:140
 * @route '/api/leave-requests/{leaveRequest}'
 */
        destroyForm.delete = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\LeaveController::approve
 * @see app/Http/Controllers/LeaveController.php:157
 * @route '/api/leave-requests/{leaveRequest}/approve'
 */
export const approve = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/leave-requests/{leaveRequest}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LeaveController::approve
 * @see app/Http/Controllers/LeaveController.php:157
 * @route '/api/leave-requests/{leaveRequest}/approve'
 */
approve.url = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leaveRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { leaveRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    leaveRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        leaveRequest: typeof args.leaveRequest === 'object'
                ? args.leaveRequest.id
                : args.leaveRequest,
                }

    return approve.definition.url
            .replace('{leaveRequest}', parsedArgs.leaveRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveController::approve
 * @see app/Http/Controllers/LeaveController.php:157
 * @route '/api/leave-requests/{leaveRequest}/approve'
 */
approve.post = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LeaveController::approve
 * @see app/Http/Controllers/LeaveController.php:157
 * @route '/api/leave-requests/{leaveRequest}/approve'
 */
    const approveForm = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LeaveController::approve
 * @see app/Http/Controllers/LeaveController.php:157
 * @route '/api/leave-requests/{leaveRequest}/approve'
 */
        approveForm.post = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\LeaveController::reject
 * @see app/Http/Controllers/LeaveController.php:200
 * @route '/api/leave-requests/{leaveRequest}/reject'
 */
export const reject = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/api/leave-requests/{leaveRequest}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LeaveController::reject
 * @see app/Http/Controllers/LeaveController.php:200
 * @route '/api/leave-requests/{leaveRequest}/reject'
 */
reject.url = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leaveRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { leaveRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    leaveRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        leaveRequest: typeof args.leaveRequest === 'object'
                ? args.leaveRequest.id
                : args.leaveRequest,
                }

    return reject.definition.url
            .replace('{leaveRequest}', parsedArgs.leaveRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveController::reject
 * @see app/Http/Controllers/LeaveController.php:200
 * @route '/api/leave-requests/{leaveRequest}/reject'
 */
reject.post = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LeaveController::reject
 * @see app/Http/Controllers/LeaveController.php:200
 * @route '/api/leave-requests/{leaveRequest}/reject'
 */
    const rejectForm = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LeaveController::reject
 * @see app/Http/Controllers/LeaveController.php:200
 * @route '/api/leave-requests/{leaveRequest}/reject'
 */
        rejectForm.post = (args: { leaveRequest: number | { id: number } } | [leaveRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\LeaveController::getLeaveBalance
 * @see app/Http/Controllers/LeaveController.php:278
 * @route '/api/employees/{employee}/leave-balance'
 */
export const getLeaveBalance = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLeaveBalance.url(args, options),
    method: 'get',
})

getLeaveBalance.definition = {
    methods: ["get","head"],
    url: '/api/employees/{employee}/leave-balance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaveController::getLeaveBalance
 * @see app/Http/Controllers/LeaveController.php:278
 * @route '/api/employees/{employee}/leave-balance'
 */
getLeaveBalance.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return getLeaveBalance.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveController::getLeaveBalance
 * @see app/Http/Controllers/LeaveController.php:278
 * @route '/api/employees/{employee}/leave-balance'
 */
getLeaveBalance.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLeaveBalance.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LeaveController::getLeaveBalance
 * @see app/Http/Controllers/LeaveController.php:278
 * @route '/api/employees/{employee}/leave-balance'
 */
getLeaveBalance.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getLeaveBalance.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LeaveController::getLeaveBalance
 * @see app/Http/Controllers/LeaveController.php:278
 * @route '/api/employees/{employee}/leave-balance'
 */
    const getLeaveBalanceForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getLeaveBalance.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LeaveController::getLeaveBalance
 * @see app/Http/Controllers/LeaveController.php:278
 * @route '/api/employees/{employee}/leave-balance'
 */
        getLeaveBalanceForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getLeaveBalance.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LeaveController::getLeaveBalance
 * @see app/Http/Controllers/LeaveController.php:278
 * @route '/api/employees/{employee}/leave-balance'
 */
        getLeaveBalanceForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getLeaveBalance.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getLeaveBalance.form = getLeaveBalanceForm
/**
* @see \App\Http\Controllers\LeaveController::getEmployeeLeaveRequests
 * @see app/Http/Controllers/LeaveController.php:305
 * @route '/api/employees/{employee}/leave-requests'
 */
export const getEmployeeLeaveRequests = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeLeaveRequests.url(args, options),
    method: 'get',
})

getEmployeeLeaveRequests.definition = {
    methods: ["get","head"],
    url: '/api/employees/{employee}/leave-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaveController::getEmployeeLeaveRequests
 * @see app/Http/Controllers/LeaveController.php:305
 * @route '/api/employees/{employee}/leave-requests'
 */
getEmployeeLeaveRequests.url = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { employee: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { employee: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    employee: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        employee: typeof args.employee === 'object'
                ? args.employee.id
                : args.employee,
                }

    return getEmployeeLeaveRequests.definition.url
            .replace('{employee}', parsedArgs.employee.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaveController::getEmployeeLeaveRequests
 * @see app/Http/Controllers/LeaveController.php:305
 * @route '/api/employees/{employee}/leave-requests'
 */
getEmployeeLeaveRequests.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeLeaveRequests.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LeaveController::getEmployeeLeaveRequests
 * @see app/Http/Controllers/LeaveController.php:305
 * @route '/api/employees/{employee}/leave-requests'
 */
getEmployeeLeaveRequests.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeLeaveRequests.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LeaveController::getEmployeeLeaveRequests
 * @see app/Http/Controllers/LeaveController.php:305
 * @route '/api/employees/{employee}/leave-requests'
 */
    const getEmployeeLeaveRequestsForm = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeLeaveRequests.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LeaveController::getEmployeeLeaveRequests
 * @see app/Http/Controllers/LeaveController.php:305
 * @route '/api/employees/{employee}/leave-requests'
 */
        getEmployeeLeaveRequestsForm.get = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeLeaveRequests.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LeaveController::getEmployeeLeaveRequests
 * @see app/Http/Controllers/LeaveController.php:305
 * @route '/api/employees/{employee}/leave-requests'
 */
        getEmployeeLeaveRequestsForm.head = (args: { employee: number | { id: number } } | [employee: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeLeaveRequests.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeLeaveRequests.form = getEmployeeLeaveRequestsForm
const LeaveController = { index, store, show, update, destroy, approve, reject, getLeaveBalance, getEmployeeLeaveRequests }

export default LeaveController