import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects'
 */
const index59d517f81ae1df73361264b1776d06b2 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index59d517f81ae1df73361264b1776d06b2.url(options),
    method: 'get',
})

index59d517f81ae1df73361264b1776d06b2.definition = {
    methods: ["get","head"],
    url: '/admin/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects'
 */
index59d517f81ae1df73361264b1776d06b2.url = (options?: RouteQueryOptions) => {
    return index59d517f81ae1df73361264b1776d06b2.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects'
 */
index59d517f81ae1df73361264b1776d06b2.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index59d517f81ae1df73361264b1776d06b2.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects'
 */
index59d517f81ae1df73361264b1776d06b2.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index59d517f81ae1df73361264b1776d06b2.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects'
 */
    const index59d517f81ae1df73361264b1776d06b2Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index59d517f81ae1df73361264b1776d06b2.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects'
 */
        index59d517f81ae1df73361264b1776d06b2Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index59d517f81ae1df73361264b1776d06b2.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects'
 */
        index59d517f81ae1df73361264b1776d06b2Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index59d517f81ae1df73361264b1776d06b2.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index59d517f81ae1df73361264b1776d06b2.form = index59d517f81ae1df73361264b1776d06b2Form
    /**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects/list'
 */
const indexf97232b8d8665b82a64c6f9baf4d2800 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexf97232b8d8665b82a64c6f9baf4d2800.url(options),
    method: 'get',
})

indexf97232b8d8665b82a64c6f9baf4d2800.definition = {
    methods: ["get","head"],
    url: '/admin/projects/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects/list'
 */
indexf97232b8d8665b82a64c6f9baf4d2800.url = (options?: RouteQueryOptions) => {
    return indexf97232b8d8665b82a64c6f9baf4d2800.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects/list'
 */
indexf97232b8d8665b82a64c6f9baf4d2800.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexf97232b8d8665b82a64c6f9baf4d2800.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects/list'
 */
indexf97232b8d8665b82a64c6f9baf4d2800.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexf97232b8d8665b82a64c6f9baf4d2800.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects/list'
 */
    const indexf97232b8d8665b82a64c6f9baf4d2800Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: indexf97232b8d8665b82a64c6f9baf4d2800.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects/list'
 */
        indexf97232b8d8665b82a64c6f9baf4d2800Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexf97232b8d8665b82a64c6f9baf4d2800.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectController::index
 * @see app/Http/Controllers/ProjectController.php:34
 * @route '/admin/projects/list'
 */
        indexf97232b8d8665b82a64c6f9baf4d2800Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexf97232b8d8665b82a64c6f9baf4d2800.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    indexf97232b8d8665b82a64c6f9baf4d2800.form = indexf97232b8d8665b82a64c6f9baf4d2800Form

export const index = {
    '/admin/projects': index59d517f81ae1df73361264b1776d06b2,
    '/admin/projects/list': indexf97232b8d8665b82a64c6f9baf4d2800,
}

/**
* @see \App\Http\Controllers\ProjectController::create
 * @see app/Http/Controllers/ProjectController.php:97
 * @route '/admin/projects/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/projects/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectController::create
 * @see app/Http/Controllers/ProjectController.php:97
 * @route '/admin/projects/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::create
 * @see app/Http/Controllers/ProjectController.php:97
 * @route '/admin/projects/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectController::create
 * @see app/Http/Controllers/ProjectController.php:97
 * @route '/admin/projects/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectController::create
 * @see app/Http/Controllers/ProjectController.php:97
 * @route '/admin/projects/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectController::create
 * @see app/Http/Controllers/ProjectController.php:97
 * @route '/admin/projects/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectController::create
 * @see app/Http/Controllers/ProjectController.php:97
 * @route '/admin/projects/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\ProjectController::store
 * @see app/Http/Controllers/ProjectController.php:117
 * @route '/admin/projects'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/projects',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectController::store
 * @see app/Http/Controllers/ProjectController.php:117
 * @route '/admin/projects'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::store
 * @see app/Http/Controllers/ProjectController.php:117
 * @route '/admin/projects'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectController::store
 * @see app/Http/Controllers/ProjectController.php:117
 * @route '/admin/projects'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::store
 * @see app/Http/Controllers/ProjectController.php:117
 * @route '/admin/projects'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ProjectController::show
 * @see app/Http/Controllers/ProjectController.php:177
 * @route '/admin/projects/{project}'
 */
export const show = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectController::show
 * @see app/Http/Controllers/ProjectController.php:177
 * @route '/admin/projects/{project}'
 */
show.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return show.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::show
 * @see app/Http/Controllers/ProjectController.php:177
 * @route '/admin/projects/{project}'
 */
show.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectController::show
 * @see app/Http/Controllers/ProjectController.php:177
 * @route '/admin/projects/{project}'
 */
show.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectController::show
 * @see app/Http/Controllers/ProjectController.php:177
 * @route '/admin/projects/{project}'
 */
    const showForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectController::show
 * @see app/Http/Controllers/ProjectController.php:177
 * @route '/admin/projects/{project}'
 */
        showForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectController::show
 * @see app/Http/Controllers/ProjectController.php:177
 * @route '/admin/projects/{project}'
 */
        showForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ProjectController::edit
 * @see app/Http/Controllers/ProjectController.php:219
 * @route '/admin/projects/{project}/edit'
 */
export const edit = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectController::edit
 * @see app/Http/Controllers/ProjectController.php:219
 * @route '/admin/projects/{project}/edit'
 */
edit.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return edit.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::edit
 * @see app/Http/Controllers/ProjectController.php:219
 * @route '/admin/projects/{project}/edit'
 */
edit.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectController::edit
 * @see app/Http/Controllers/ProjectController.php:219
 * @route '/admin/projects/{project}/edit'
 */
edit.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectController::edit
 * @see app/Http/Controllers/ProjectController.php:219
 * @route '/admin/projects/{project}/edit'
 */
    const editForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectController::edit
 * @see app/Http/Controllers/ProjectController.php:219
 * @route '/admin/projects/{project}/edit'
 */
        editForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectController::edit
 * @see app/Http/Controllers/ProjectController.php:219
 * @route '/admin/projects/{project}/edit'
 */
        editForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\ProjectController::update
 * @see app/Http/Controllers/ProjectController.php:242
 * @route '/admin/projects/{project}'
 */
export const update = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/projects/{project}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ProjectController::update
 * @see app/Http/Controllers/ProjectController.php:242
 * @route '/admin/projects/{project}'
 */
update.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return update.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::update
 * @see app/Http/Controllers/ProjectController.php:242
 * @route '/admin/projects/{project}'
 */
update.patch = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProjectController::update
 * @see app/Http/Controllers/ProjectController.php:242
 * @route '/admin/projects/{project}'
 */
    const updateForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::update
 * @see app/Http/Controllers/ProjectController.php:242
 * @route '/admin/projects/{project}'
 */
        updateForm.patch = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ProjectController::destroy
 * @see app/Http/Controllers/ProjectController.php:296
 * @route '/admin/projects/{project}'
 */
export const destroy = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/projects/{project}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProjectController::destroy
 * @see app/Http/Controllers/ProjectController.php:296
 * @route '/admin/projects/{project}'
 */
destroy.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return destroy.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::destroy
 * @see app/Http/Controllers/ProjectController.php:296
 * @route '/admin/projects/{project}'
 */
destroy.delete = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ProjectController::destroy
 * @see app/Http/Controllers/ProjectController.php:296
 * @route '/admin/projects/{project}'
 */
    const destroyForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::destroy
 * @see app/Http/Controllers/ProjectController.php:296
 * @route '/admin/projects/{project}'
 */
        destroyForm.delete = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\ProjectController::restore
 * @see app/Http/Controllers/ProjectController.php:311
 * @route '/admin/projects/{project}/restore'
 */
export const restore = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectController::restore
 * @see app/Http/Controllers/ProjectController.php:311
 * @route '/admin/projects/{project}/restore'
 */
restore.url = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: args.project,
                }

    return restore.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::restore
 * @see app/Http/Controllers/ProjectController.php:311
 * @route '/admin/projects/{project}/restore'
 */
restore.post = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectController::restore
 * @see app/Http/Controllers/ProjectController.php:311
 * @route '/admin/projects/{project}/restore'
 */
    const restoreForm = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::restore
 * @see app/Http/Controllers/ProjectController.php:311
 * @route '/admin/projects/{project}/restore'
 */
        restoreForm.post = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\ProjectController::getStatistics
 * @see app/Http/Controllers/ProjectController.php:327
 * @route '/admin/projects/{project}/statistics'
 */
export const getStatistics = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStatistics.url(args, options),
    method: 'get',
})

getStatistics.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/statistics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectController::getStatistics
 * @see app/Http/Controllers/ProjectController.php:327
 * @route '/admin/projects/{project}/statistics'
 */
getStatistics.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return getStatistics.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::getStatistics
 * @see app/Http/Controllers/ProjectController.php:327
 * @route '/admin/projects/{project}/statistics'
 */
getStatistics.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStatistics.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectController::getStatistics
 * @see app/Http/Controllers/ProjectController.php:327
 * @route '/admin/projects/{project}/statistics'
 */
getStatistics.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStatistics.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectController::getStatistics
 * @see app/Http/Controllers/ProjectController.php:327
 * @route '/admin/projects/{project}/statistics'
 */
    const getStatisticsForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getStatistics.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectController::getStatistics
 * @see app/Http/Controllers/ProjectController.php:327
 * @route '/admin/projects/{project}/statistics'
 */
        getStatisticsForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStatistics.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectController::getStatistics
 * @see app/Http/Controllers/ProjectController.php:327
 * @route '/admin/projects/{project}/statistics'
 */
        getStatisticsForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStatistics.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getStatistics.form = getStatisticsForm
/**
* @see \App\Http\Controllers\ProjectController::updateProgress
 * @see app/Http/Controllers/ProjectController.php:357
 * @route '/admin/projects/{project}/progress'
 */
export const updateProgress = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateProgress.url(args, options),
    method: 'post',
})

updateProgress.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/progress',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectController::updateProgress
 * @see app/Http/Controllers/ProjectController.php:357
 * @route '/admin/projects/{project}/progress'
 */
updateProgress.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return updateProgress.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::updateProgress
 * @see app/Http/Controllers/ProjectController.php:357
 * @route '/admin/projects/{project}/progress'
 */
updateProgress.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateProgress.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectController::updateProgress
 * @see app/Http/Controllers/ProjectController.php:357
 * @route '/admin/projects/{project}/progress'
 */
    const updateProgressForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateProgress.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::updateProgress
 * @see app/Http/Controllers/ProjectController.php:357
 * @route '/admin/projects/{project}/progress'
 */
        updateProgressForm.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateProgress.url(args, options),
            method: 'post',
        })
    
    updateProgress.form = updateProgressForm
/**
* @see \App\Http\Controllers\ProjectController::getGanttData
 * @see app/Http/Controllers/ProjectController.php:375
 * @route '/admin/projects/{project}/gantt'
 */
export const getGanttData = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getGanttData.url(args, options),
    method: 'get',
})

getGanttData.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/gantt',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectController::getGanttData
 * @see app/Http/Controllers/ProjectController.php:375
 * @route '/admin/projects/{project}/gantt'
 */
getGanttData.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return getGanttData.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::getGanttData
 * @see app/Http/Controllers/ProjectController.php:375
 * @route '/admin/projects/{project}/gantt'
 */
getGanttData.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getGanttData.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectController::getGanttData
 * @see app/Http/Controllers/ProjectController.php:375
 * @route '/admin/projects/{project}/gantt'
 */
getGanttData.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getGanttData.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectController::getGanttData
 * @see app/Http/Controllers/ProjectController.php:375
 * @route '/admin/projects/{project}/gantt'
 */
    const getGanttDataForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getGanttData.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectController::getGanttData
 * @see app/Http/Controllers/ProjectController.php:375
 * @route '/admin/projects/{project}/gantt'
 */
        getGanttDataForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getGanttData.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectController::getGanttData
 * @see app/Http/Controllers/ProjectController.php:375
 * @route '/admin/projects/{project}/gantt'
 */
        getGanttDataForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getGanttData.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getGanttData.form = getGanttDataForm
/**
* @see \App\Http\Controllers\ProjectController::getTeam
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
export const getTeam = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTeam.url(args, options),
    method: 'get',
})

getTeam.definition = {
    methods: ["get","head"],
    url: '/admin/projects/{project}/team',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProjectController::getTeam
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
getTeam.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return getTeam.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::getTeam
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
getTeam.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTeam.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProjectController::getTeam
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
getTeam.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTeam.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProjectController::getTeam
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
    const getTeamForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTeam.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProjectController::getTeam
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
        getTeamForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTeam.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProjectController::getTeam
 * @see app/Http/Controllers/ProjectController.php:402
 * @route '/admin/projects/{project}/team'
 */
        getTeamForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTeam.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTeam.form = getTeamForm
/**
* @see \App\Http\Controllers\ProjectController::addTeamMember
 * @see app/Http/Controllers/ProjectController.php:416
 * @route '/admin/projects/{project}/team'
 */
export const addTeamMember = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addTeamMember.url(args, options),
    method: 'post',
})

addTeamMember.definition = {
    methods: ["post"],
    url: '/admin/projects/{project}/team',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProjectController::addTeamMember
 * @see app/Http/Controllers/ProjectController.php:416
 * @route '/admin/projects/{project}/team'
 */
addTeamMember.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { project: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                }

    return addTeamMember.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::addTeamMember
 * @see app/Http/Controllers/ProjectController.php:416
 * @route '/admin/projects/{project}/team'
 */
addTeamMember.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addTeamMember.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProjectController::addTeamMember
 * @see app/Http/Controllers/ProjectController.php:416
 * @route '/admin/projects/{project}/team'
 */
    const addTeamMemberForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addTeamMember.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::addTeamMember
 * @see app/Http/Controllers/ProjectController.php:416
 * @route '/admin/projects/{project}/team'
 */
        addTeamMemberForm.post = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addTeamMember.url(args, options),
            method: 'post',
        })
    
    addTeamMember.form = addTeamMemberForm
/**
* @see \App\Http\Controllers\ProjectController::removeTeamMember
 * @see app/Http/Controllers/ProjectController.php:453
 * @route '/admin/projects/{project}/team/{user}'
 */
export const removeTeamMember = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeTeamMember.url(args, options),
    method: 'delete',
})

removeTeamMember.definition = {
    methods: ["delete"],
    url: '/admin/projects/{project}/team/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProjectController::removeTeamMember
 * @see app/Http/Controllers/ProjectController.php:453
 * @route '/admin/projects/{project}/team/{user}'
 */
removeTeamMember.url = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                user: args.user,
                }

    return removeTeamMember.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::removeTeamMember
 * @see app/Http/Controllers/ProjectController.php:453
 * @route '/admin/projects/{project}/team/{user}'
 */
removeTeamMember.delete = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeTeamMember.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ProjectController::removeTeamMember
 * @see app/Http/Controllers/ProjectController.php:453
 * @route '/admin/projects/{project}/team/{user}'
 */
    const removeTeamMemberForm = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: removeTeamMember.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::removeTeamMember
 * @see app/Http/Controllers/ProjectController.php:453
 * @route '/admin/projects/{project}/team/{user}'
 */
        removeTeamMemberForm.delete = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: removeTeamMember.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    removeTeamMember.form = removeTeamMemberForm
/**
* @see \App\Http\Controllers\ProjectController::updateTeamMemberRole
 * @see app/Http/Controllers/ProjectController.php:471
 * @route '/admin/projects/{project}/team/{user}'
 */
export const updateTeamMemberRole = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTeamMemberRole.url(args, options),
    method: 'patch',
})

updateTeamMemberRole.definition = {
    methods: ["patch"],
    url: '/admin/projects/{project}/team/{user}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ProjectController::updateTeamMemberRole
 * @see app/Http/Controllers/ProjectController.php:471
 * @route '/admin/projects/{project}/team/{user}'
 */
updateTeamMemberRole.url = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    project: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        project: typeof args.project === 'object'
                ? args.project.id
                : args.project,
                                user: args.user,
                }

    return updateTeamMemberRole.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProjectController::updateTeamMemberRole
 * @see app/Http/Controllers/ProjectController.php:471
 * @route '/admin/projects/{project}/team/{user}'
 */
updateTeamMemberRole.patch = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTeamMemberRole.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProjectController::updateTeamMemberRole
 * @see app/Http/Controllers/ProjectController.php:471
 * @route '/admin/projects/{project}/team/{user}'
 */
    const updateTeamMemberRoleForm = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateTeamMemberRole.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProjectController::updateTeamMemberRole
 * @see app/Http/Controllers/ProjectController.php:471
 * @route '/admin/projects/{project}/team/{user}'
 */
        updateTeamMemberRoleForm.patch = (args: { project: number | { id: number }, user: string | number } | [project: number | { id: number }, user: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateTeamMemberRole.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateTeamMemberRole.form = updateTeamMemberRoleForm
const ProjectController = { index, create, store, show, edit, update, destroy, restore, getStatistics, updateProgress, getGanttData, getTeam, addTeamMember, removeTeamMember, updateTeamMemberRole }

export default ProjectController