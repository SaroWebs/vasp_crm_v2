import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::store
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:18
 * @route '/admin/tasks/{task}/time-entries/manual'
 */
export const store = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/tasks/{task}/time-entries/manual',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::store
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:18
 * @route '/admin/tasks/{task}/time-entries/manual'
 */
store.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return store.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::store
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:18
 * @route '/admin/tasks/{task}/time-entries/manual'
 */
store.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::store
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:18
 * @route '/admin/tasks/{task}/time-entries/manual'
 */
    const storeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::store
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:18
 * @route '/admin/tasks/{task}/time-entries/manual'
 */
        storeForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::batchUpdate
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:51
 * @route '/admin/tasks/{task}/time-entries/batch'
 */
export const batchUpdate = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: batchUpdate.url(args, options),
    method: 'patch',
})

batchUpdate.definition = {
    methods: ["patch"],
    url: '/admin/tasks/{task}/time-entries/batch',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::batchUpdate
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:51
 * @route '/admin/tasks/{task}/time-entries/batch'
 */
batchUpdate.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return batchUpdate.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::batchUpdate
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:51
 * @route '/admin/tasks/{task}/time-entries/batch'
 */
batchUpdate.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: batchUpdate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::batchUpdate
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:51
 * @route '/admin/tasks/{task}/time-entries/batch'
 */
    const batchUpdateForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: batchUpdate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::batchUpdate
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:51
 * @route '/admin/tasks/{task}/time-entries/batch'
 */
        batchUpdateForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: batchUpdate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    batchUpdate.form = batchUpdateForm
/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
export const destroy = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/tasks/{task}/time-entries/{timeEntry}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
destroy.url = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                    timeEntry: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                                timeEntry: typeof args.timeEntry === 'object'
                ? args.timeEntry.id
                : args.timeEntry,
                }

    return destroy.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace('{timeEntry}', parsedArgs.timeEntry.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
destroy.delete = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
    const destroyForm = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminTaskTimeEntryController::destroy
 * @see app/Http/Controllers/AdminTaskTimeEntryController.php:137
 * @route '/admin/tasks/{task}/time-entries/{timeEntry}'
 */
        destroyForm.delete = (args: { task: number | { id: number }, timeEntry: number | { id: number } } | [task: number | { id: number }, timeEntry: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AdminTaskTimeEntryController = { store, batchUpdate, destroy }

export default AdminTaskTimeEntryController