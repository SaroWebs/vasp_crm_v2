import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:23
 * @route '/api/activity-logs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:23
 * @route '/api/activity-logs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:23
 * @route '/api/activity-logs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:23
 * @route '/api/activity-logs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:23
 * @route '/api/activity-logs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:23
 * @route '/api/activity-logs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::index
 * @see app/Http/Controllers/ActivityLogController.php:23
 * @route '/api/activity-logs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:77
 * @route '/api/activity-logs/{activityLog}'
 */
export const show = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/{activityLog}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:77
 * @route '/api/activity-logs/{activityLog}'
 */
show.url = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { activityLog: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { activityLog: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    activityLog: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        activityLog: typeof args.activityLog === 'object'
                ? args.activityLog.id
                : args.activityLog,
                }

    return show.definition.url
            .replace('{activityLog}', parsedArgs.activityLog.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:77
 * @route '/api/activity-logs/{activityLog}'
 */
show.get = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:77
 * @route '/api/activity-logs/{activityLog}'
 */
show.head = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:77
 * @route '/api/activity-logs/{activityLog}'
 */
    const showForm = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:77
 * @route '/api/activity-logs/{activityLog}'
 */
        showForm.get = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::show
 * @see app/Http/Controllers/ActivityLogController.php:77
 * @route '/api/activity-logs/{activityLog}'
 */
        showForm.head = (args: { activityLog: number | { id: number } } | [activityLog: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ActivityLogController::getModelActivity
 * @see app/Http/Controllers/ActivityLogController.php:101
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
export const getModelActivity = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getModelActivity.url(args, options),
    method: 'get',
})

getModelActivity.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/model/{modelType}/{modelId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::getModelActivity
 * @see app/Http/Controllers/ActivityLogController.php:101
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
getModelActivity.url = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    modelType: args[0],
                    modelId: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        modelType: args.modelType,
                                modelId: args.modelId,
                }

    return getModelActivity.definition.url
            .replace('{modelType}', parsedArgs.modelType.toString())
            .replace('{modelId}', parsedArgs.modelId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::getModelActivity
 * @see app/Http/Controllers/ActivityLogController.php:101
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
getModelActivity.get = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getModelActivity.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::getModelActivity
 * @see app/Http/Controllers/ActivityLogController.php:101
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
getModelActivity.head = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getModelActivity.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::getModelActivity
 * @see app/Http/Controllers/ActivityLogController.php:101
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
    const getModelActivityForm = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getModelActivity.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::getModelActivity
 * @see app/Http/Controllers/ActivityLogController.php:101
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
        getModelActivityForm.get = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getModelActivity.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::getModelActivity
 * @see app/Http/Controllers/ActivityLogController.php:101
 * @route '/api/activity-logs/model/{modelType}/{modelId}'
 */
        getModelActivityForm.head = (args: { modelType: string | number, modelId: string | number } | [modelType: string | number, modelId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getModelActivity.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getModelActivity.form = getModelActivityForm
/**
* @see \App\Http\Controllers\ActivityLogController::getUserActivity
 * @see app/Http/Controllers/ActivityLogController.php:132
 * @route '/api/activity-logs/user/{userId}'
 */
export const getUserActivity = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserActivity.url(args, options),
    method: 'get',
})

getUserActivity.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/user/{userId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::getUserActivity
 * @see app/Http/Controllers/ActivityLogController.php:132
 * @route '/api/activity-logs/user/{userId}'
 */
getUserActivity.url = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { userId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    userId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        userId: args.userId,
                }

    return getUserActivity.definition.url
            .replace('{userId}', parsedArgs.userId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::getUserActivity
 * @see app/Http/Controllers/ActivityLogController.php:132
 * @route '/api/activity-logs/user/{userId}'
 */
getUserActivity.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUserActivity.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::getUserActivity
 * @see app/Http/Controllers/ActivityLogController.php:132
 * @route '/api/activity-logs/user/{userId}'
 */
getUserActivity.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUserActivity.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::getUserActivity
 * @see app/Http/Controllers/ActivityLogController.php:132
 * @route '/api/activity-logs/user/{userId}'
 */
    const getUserActivityForm = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getUserActivity.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::getUserActivity
 * @see app/Http/Controllers/ActivityLogController.php:132
 * @route '/api/activity-logs/user/{userId}'
 */
        getUserActivityForm.get = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUserActivity.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::getUserActivity
 * @see app/Http/Controllers/ActivityLogController.php:132
 * @route '/api/activity-logs/user/{userId}'
 */
        getUserActivityForm.head = (args: { userId: string | number } | [userId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUserActivity.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getUserActivity.form = getUserActivityForm
/**
* @see \App\Http\Controllers\ActivityLogController::getStatistics
 * @see app/Http/Controllers/ActivityLogController.php:158
 * @route '/api/activity-logs/statistics'
 */
export const getStatistics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStatistics.url(options),
    method: 'get',
})

getStatistics.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/statistics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::getStatistics
 * @see app/Http/Controllers/ActivityLogController.php:158
 * @route '/api/activity-logs/statistics'
 */
getStatistics.url = (options?: RouteQueryOptions) => {
    return getStatistics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::getStatistics
 * @see app/Http/Controllers/ActivityLogController.php:158
 * @route '/api/activity-logs/statistics'
 */
getStatistics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getStatistics.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::getStatistics
 * @see app/Http/Controllers/ActivityLogController.php:158
 * @route '/api/activity-logs/statistics'
 */
getStatistics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getStatistics.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::getStatistics
 * @see app/Http/Controllers/ActivityLogController.php:158
 * @route '/api/activity-logs/statistics'
 */
    const getStatisticsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getStatistics.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::getStatistics
 * @see app/Http/Controllers/ActivityLogController.php:158
 * @route '/api/activity-logs/statistics'
 */
        getStatisticsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStatistics.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::getStatistics
 * @see app/Http/Controllers/ActivityLogController.php:158
 * @route '/api/activity-logs/statistics'
 */
        getStatisticsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getStatistics.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getStatistics.form = getStatisticsForm
/**
* @see \App\Http\Controllers\ActivityLogController::getRecentActivity
 * @see app/Http/Controllers/ActivityLogController.php:179
 * @route '/api/activity-logs/recent'
 */
export const getRecentActivity = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getRecentActivity.url(options),
    method: 'get',
})

getRecentActivity.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/recent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::getRecentActivity
 * @see app/Http/Controllers/ActivityLogController.php:179
 * @route '/api/activity-logs/recent'
 */
getRecentActivity.url = (options?: RouteQueryOptions) => {
    return getRecentActivity.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::getRecentActivity
 * @see app/Http/Controllers/ActivityLogController.php:179
 * @route '/api/activity-logs/recent'
 */
getRecentActivity.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getRecentActivity.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::getRecentActivity
 * @see app/Http/Controllers/ActivityLogController.php:179
 * @route '/api/activity-logs/recent'
 */
getRecentActivity.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getRecentActivity.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::getRecentActivity
 * @see app/Http/Controllers/ActivityLogController.php:179
 * @route '/api/activity-logs/recent'
 */
    const getRecentActivityForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getRecentActivity.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::getRecentActivity
 * @see app/Http/Controllers/ActivityLogController.php:179
 * @route '/api/activity-logs/recent'
 */
        getRecentActivityForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getRecentActivity.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::getRecentActivity
 * @see app/Http/Controllers/ActivityLogController.php:179
 * @route '/api/activity-logs/recent'
 */
        getRecentActivityForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getRecentActivity.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getRecentActivity.form = getRecentActivityForm
/**
* @see \App\Http\Controllers\ActivityLogController::clearOldLogs
 * @see app/Http/Controllers/ActivityLogController.php:200
 * @route '/api/activity-logs/clear-old'
 */
export const clearOldLogs = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearOldLogs.url(options),
    method: 'delete',
})

clearOldLogs.definition = {
    methods: ["delete"],
    url: '/api/activity-logs/clear-old',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ActivityLogController::clearOldLogs
 * @see app/Http/Controllers/ActivityLogController.php:200
 * @route '/api/activity-logs/clear-old'
 */
clearOldLogs.url = (options?: RouteQueryOptions) => {
    return clearOldLogs.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::clearOldLogs
 * @see app/Http/Controllers/ActivityLogController.php:200
 * @route '/api/activity-logs/clear-old'
 */
clearOldLogs.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearOldLogs.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::clearOldLogs
 * @see app/Http/Controllers/ActivityLogController.php:200
 * @route '/api/activity-logs/clear-old'
 */
    const clearOldLogsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clearOldLogs.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::clearOldLogs
 * @see app/Http/Controllers/ActivityLogController.php:200
 * @route '/api/activity-logs/clear-old'
 */
        clearOldLogsForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clearOldLogs.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    clearOldLogs.form = clearOldLogsForm
/**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:228
 * @route '/api/activity-logs/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/api/activity-logs/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:228
 * @route '/api/activity-logs/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:228
 * @route '/api/activity-logs/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:228
 * @route '/api/activity-logs/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:228
 * @route '/api/activity-logs/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:228
 * @route '/api/activity-logs/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ActivityLogController::exportMethod
 * @see app/Http/Controllers/ActivityLogController.php:228
 * @route '/api/activity-logs/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const ActivityLogController = { index, show, getModelActivity, getUserActivity, getStatistics, getRecentActivity, clearOldLogs, exportMethod, export: exportMethod }

export default ActivityLogController