import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\NotificationController::index
 * @see app/Http/Controllers/NotificationController.php:21
 * @route '/admin/notifications'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NotificationController::index
 * @see app/Http/Controllers/NotificationController.php:21
 * @route '/admin/notifications'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::index
 * @see app/Http/Controllers/NotificationController.php:21
 * @route '/admin/notifications'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NotificationController::index
 * @see app/Http/Controllers/NotificationController.php:21
 * @route '/admin/notifications'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NotificationController::index
 * @see app/Http/Controllers/NotificationController.php:21
 * @route '/admin/notifications'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NotificationController::index
 * @see app/Http/Controllers/NotificationController.php:21
 * @route '/admin/notifications'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NotificationController::index
 * @see app/Http/Controllers/NotificationController.php:21
 * @route '/admin/notifications'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/admin/notifications/data'
 */
const data78d452639eff3873ee7a4751bfa87d01 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data78d452639eff3873ee7a4751bfa87d01.url(options),
    method: 'get',
})

data78d452639eff3873ee7a4751bfa87d01.definition = {
    methods: ["get","head"],
    url: '/admin/notifications/data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/admin/notifications/data'
 */
data78d452639eff3873ee7a4751bfa87d01.url = (options?: RouteQueryOptions) => {
    return data78d452639eff3873ee7a4751bfa87d01.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/admin/notifications/data'
 */
data78d452639eff3873ee7a4751bfa87d01.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data78d452639eff3873ee7a4751bfa87d01.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/admin/notifications/data'
 */
data78d452639eff3873ee7a4751bfa87d01.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data78d452639eff3873ee7a4751bfa87d01.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/admin/notifications/data'
 */
    const data78d452639eff3873ee7a4751bfa87d01Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: data78d452639eff3873ee7a4751bfa87d01.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/admin/notifications/data'
 */
        data78d452639eff3873ee7a4751bfa87d01Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data78d452639eff3873ee7a4751bfa87d01.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/admin/notifications/data'
 */
        data78d452639eff3873ee7a4751bfa87d01Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data78d452639eff3873ee7a4751bfa87d01.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    data78d452639eff3873ee7a4751bfa87d01.form = data78d452639eff3873ee7a4751bfa87d01Form
    /**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/api/notifications'
 */
const data63ca617bad575304d9a46c7bd2661780 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data63ca617bad575304d9a46c7bd2661780.url(options),
    method: 'get',
})

data63ca617bad575304d9a46c7bd2661780.definition = {
    methods: ["get","head"],
    url: '/api/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/api/notifications'
 */
data63ca617bad575304d9a46c7bd2661780.url = (options?: RouteQueryOptions) => {
    return data63ca617bad575304d9a46c7bd2661780.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/api/notifications'
 */
data63ca617bad575304d9a46c7bd2661780.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data63ca617bad575304d9a46c7bd2661780.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/api/notifications'
 */
data63ca617bad575304d9a46c7bd2661780.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data63ca617bad575304d9a46c7bd2661780.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/api/notifications'
 */
    const data63ca617bad575304d9a46c7bd2661780Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: data63ca617bad575304d9a46c7bd2661780.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/api/notifications'
 */
        data63ca617bad575304d9a46c7bd2661780Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data63ca617bad575304d9a46c7bd2661780.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NotificationController::data
 * @see app/Http/Controllers/NotificationController.php:151
 * @route '/api/notifications'
 */
        data63ca617bad575304d9a46c7bd2661780Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data63ca617bad575304d9a46c7bd2661780.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    data63ca617bad575304d9a46c7bd2661780.form = data63ca617bad575304d9a46c7bd2661780Form

export const data = {
    '/admin/notifications/data': data78d452639eff3873ee7a4751bfa87d01,
    '/api/notifications': data63ca617bad575304d9a46c7bd2661780,
}

/**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/admin/notifications/{notification}/read'
 */
const markAsReadc4099d9b4c071427619e0394e4a32b1f = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markAsReadc4099d9b4c071427619e0394e4a32b1f.url(args, options),
    method: 'patch',
})

markAsReadc4099d9b4c071427619e0394e4a32b1f.definition = {
    methods: ["patch"],
    url: '/admin/notifications/{notification}/read',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/admin/notifications/{notification}/read'
 */
markAsReadc4099d9b4c071427619e0394e4a32b1f.url = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return markAsReadc4099d9b4c071427619e0394e4a32b1f.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/admin/notifications/{notification}/read'
 */
markAsReadc4099d9b4c071427619e0394e4a32b1f.patch = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markAsReadc4099d9b4c071427619e0394e4a32b1f.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/admin/notifications/{notification}/read'
 */
    const markAsReadc4099d9b4c071427619e0394e4a32b1fForm = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAsReadc4099d9b4c071427619e0394e4a32b1f.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/admin/notifications/{notification}/read'
 */
        markAsReadc4099d9b4c071427619e0394e4a32b1fForm.patch = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAsReadc4099d9b4c071427619e0394e4a32b1f.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    markAsReadc4099d9b4c071427619e0394e4a32b1f.form = markAsReadc4099d9b4c071427619e0394e4a32b1fForm
    /**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/api/notifications/{notification}/mark-read'
 */
const markAsRead5b2c9f0f920e08a7a78910871663fe80 = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAsRead5b2c9f0f920e08a7a78910871663fe80.url(args, options),
    method: 'post',
})

markAsRead5b2c9f0f920e08a7a78910871663fe80.definition = {
    methods: ["post"],
    url: '/api/notifications/{notification}/mark-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/api/notifications/{notification}/mark-read'
 */
markAsRead5b2c9f0f920e08a7a78910871663fe80.url = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return markAsRead5b2c9f0f920e08a7a78910871663fe80.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/api/notifications/{notification}/mark-read'
 */
markAsRead5b2c9f0f920e08a7a78910871663fe80.post = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAsRead5b2c9f0f920e08a7a78910871663fe80.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/api/notifications/{notification}/mark-read'
 */
    const markAsRead5b2c9f0f920e08a7a78910871663fe80Form = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAsRead5b2c9f0f920e08a7a78910871663fe80.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationController::markAsRead
 * @see app/Http/Controllers/NotificationController.php:79
 * @route '/api/notifications/{notification}/mark-read'
 */
        markAsRead5b2c9f0f920e08a7a78910871663fe80Form.post = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAsRead5b2c9f0f920e08a7a78910871663fe80.url(args, options),
            method: 'post',
        })
    
    markAsRead5b2c9f0f920e08a7a78910871663fe80.form = markAsRead5b2c9f0f920e08a7a78910871663fe80Form

export const markAsRead = {
    '/admin/notifications/{notification}/read': markAsReadc4099d9b4c071427619e0394e4a32b1f,
    '/api/notifications/{notification}/mark-read': markAsRead5b2c9f0f920e08a7a78910871663fe80,
}

/**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/admin/notifications/mark-all-read'
 */
const markAllAsRead7c28422dfa5df171ebf80366612a68fd = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllAsRead7c28422dfa5df171ebf80366612a68fd.url(options),
    method: 'post',
})

markAllAsRead7c28422dfa5df171ebf80366612a68fd.definition = {
    methods: ["post"],
    url: '/admin/notifications/mark-all-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/admin/notifications/mark-all-read'
 */
markAllAsRead7c28422dfa5df171ebf80366612a68fd.url = (options?: RouteQueryOptions) => {
    return markAllAsRead7c28422dfa5df171ebf80366612a68fd.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/admin/notifications/mark-all-read'
 */
markAllAsRead7c28422dfa5df171ebf80366612a68fd.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllAsRead7c28422dfa5df171ebf80366612a68fd.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/admin/notifications/mark-all-read'
 */
    const markAllAsRead7c28422dfa5df171ebf80366612a68fdForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAllAsRead7c28422dfa5df171ebf80366612a68fd.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/admin/notifications/mark-all-read'
 */
        markAllAsRead7c28422dfa5df171ebf80366612a68fdForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAllAsRead7c28422dfa5df171ebf80366612a68fd.url(options),
            method: 'post',
        })
    
    markAllAsRead7c28422dfa5df171ebf80366612a68fd.form = markAllAsRead7c28422dfa5df171ebf80366612a68fdForm
    /**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/api/notifications/mark-all-read'
 */
const markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3.url(options),
    method: 'post',
})

markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3.definition = {
    methods: ["post"],
    url: '/api/notifications/mark-all-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/api/notifications/mark-all-read'
 */
markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3.url = (options?: RouteQueryOptions) => {
    return markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/api/notifications/mark-all-read'
 */
markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/api/notifications/mark-all-read'
 */
    const markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationController::markAllAsRead
 * @see app/Http/Controllers/NotificationController.php:99
 * @route '/api/notifications/mark-all-read'
 */
        markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3.url(options),
            method: 'post',
        })
    
    markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3.form = markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3Form

export const markAllAsRead = {
    '/admin/notifications/mark-all-read': markAllAsRead7c28422dfa5df171ebf80366612a68fd,
    '/api/notifications/mark-all-read': markAllAsReadc9d6b1ec017004dda117fd16da9eb5d3,
}

/**
* @see \App\Http\Controllers\NotificationController::getUnreadCount
 * @see app/Http/Controllers/NotificationController.php:122
 * @route '/api/notifications/unread-count'
 */
export const getUnreadCount = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUnreadCount.url(options),
    method: 'get',
})

getUnreadCount.definition = {
    methods: ["get","head"],
    url: '/api/notifications/unread-count',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NotificationController::getUnreadCount
 * @see app/Http/Controllers/NotificationController.php:122
 * @route '/api/notifications/unread-count'
 */
getUnreadCount.url = (options?: RouteQueryOptions) => {
    return getUnreadCount.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::getUnreadCount
 * @see app/Http/Controllers/NotificationController.php:122
 * @route '/api/notifications/unread-count'
 */
getUnreadCount.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUnreadCount.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NotificationController::getUnreadCount
 * @see app/Http/Controllers/NotificationController.php:122
 * @route '/api/notifications/unread-count'
 */
getUnreadCount.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUnreadCount.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NotificationController::getUnreadCount
 * @see app/Http/Controllers/NotificationController.php:122
 * @route '/api/notifications/unread-count'
 */
    const getUnreadCountForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getUnreadCount.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NotificationController::getUnreadCount
 * @see app/Http/Controllers/NotificationController.php:122
 * @route '/api/notifications/unread-count'
 */
        getUnreadCountForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUnreadCount.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NotificationController::getUnreadCount
 * @see app/Http/Controllers/NotificationController.php:122
 * @route '/api/notifications/unread-count'
 */
        getUnreadCountForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUnreadCount.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getUnreadCount.form = getUnreadCountForm
/**
* @see \App\Http\Controllers\NotificationController::getRecent
 * @see app/Http/Controllers/NotificationController.php:134
 * @route '/api/notifications/recent'
 */
export const getRecent = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getRecent.url(options),
    method: 'get',
})

getRecent.definition = {
    methods: ["get","head"],
    url: '/api/notifications/recent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NotificationController::getRecent
 * @see app/Http/Controllers/NotificationController.php:134
 * @route '/api/notifications/recent'
 */
getRecent.url = (options?: RouteQueryOptions) => {
    return getRecent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::getRecent
 * @see app/Http/Controllers/NotificationController.php:134
 * @route '/api/notifications/recent'
 */
getRecent.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getRecent.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NotificationController::getRecent
 * @see app/Http/Controllers/NotificationController.php:134
 * @route '/api/notifications/recent'
 */
getRecent.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getRecent.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NotificationController::getRecent
 * @see app/Http/Controllers/NotificationController.php:134
 * @route '/api/notifications/recent'
 */
    const getRecentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getRecent.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NotificationController::getRecent
 * @see app/Http/Controllers/NotificationController.php:134
 * @route '/api/notifications/recent'
 */
        getRecentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getRecent.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NotificationController::getRecent
 * @see app/Http/Controllers/NotificationController.php:134
 * @route '/api/notifications/recent'
 */
        getRecentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getRecent.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getRecent.form = getRecentForm
/**
* @see \App\Http\Controllers\NotificationController::bulkMarkAsRead
 * @see app/Http/Controllers/NotificationController.php:232
 * @route '/api/notifications/bulk-mark-read'
 */
export const bulkMarkAsRead = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkMarkAsRead.url(options),
    method: 'post',
})

bulkMarkAsRead.definition = {
    methods: ["post"],
    url: '/api/notifications/bulk-mark-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationController::bulkMarkAsRead
 * @see app/Http/Controllers/NotificationController.php:232
 * @route '/api/notifications/bulk-mark-read'
 */
bulkMarkAsRead.url = (options?: RouteQueryOptions) => {
    return bulkMarkAsRead.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::bulkMarkAsRead
 * @see app/Http/Controllers/NotificationController.php:232
 * @route '/api/notifications/bulk-mark-read'
 */
bulkMarkAsRead.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkMarkAsRead.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationController::bulkMarkAsRead
 * @see app/Http/Controllers/NotificationController.php:232
 * @route '/api/notifications/bulk-mark-read'
 */
    const bulkMarkAsReadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkMarkAsRead.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationController::bulkMarkAsRead
 * @see app/Http/Controllers/NotificationController.php:232
 * @route '/api/notifications/bulk-mark-read'
 */
        bulkMarkAsReadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkMarkAsRead.url(options),
            method: 'post',
        })
    
    bulkMarkAsRead.form = bulkMarkAsReadForm
/**
* @see \App\Http\Controllers\NotificationController::destroy
 * @see app/Http/Controllers/NotificationController.php:180
 * @route '/api/notifications/{notification}'
 */
export const destroy = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/notifications/{notification}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\NotificationController::destroy
 * @see app/Http/Controllers/NotificationController.php:180
 * @route '/api/notifications/{notification}'
 */
destroy.url = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return destroy.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::destroy
 * @see app/Http/Controllers/NotificationController.php:180
 * @route '/api/notifications/{notification}'
 */
destroy.delete = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\NotificationController::destroy
 * @see app/Http/Controllers/NotificationController.php:180
 * @route '/api/notifications/{notification}'
 */
    const destroyForm = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationController::destroy
 * @see app/Http/Controllers/NotificationController.php:180
 * @route '/api/notifications/{notification}'
 */
        destroyForm.delete = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\NotificationController::bulkDelete
 * @see app/Http/Controllers/NotificationController.php:204
 * @route '/api/notifications/bulk-delete'
 */
export const bulkDelete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: bulkDelete.url(options),
    method: 'delete',
})

bulkDelete.definition = {
    methods: ["delete"],
    url: '/api/notifications/bulk-delete',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\NotificationController::bulkDelete
 * @see app/Http/Controllers/NotificationController.php:204
 * @route '/api/notifications/bulk-delete'
 */
bulkDelete.url = (options?: RouteQueryOptions) => {
    return bulkDelete.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationController::bulkDelete
 * @see app/Http/Controllers/NotificationController.php:204
 * @route '/api/notifications/bulk-delete'
 */
bulkDelete.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: bulkDelete.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\NotificationController::bulkDelete
 * @see app/Http/Controllers/NotificationController.php:204
 * @route '/api/notifications/bulk-delete'
 */
    const bulkDeleteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkDelete.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationController::bulkDelete
 * @see app/Http/Controllers/NotificationController.php:204
 * @route '/api/notifications/bulk-delete'
 */
        bulkDeleteForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkDelete.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    bulkDelete.form = bulkDeleteForm
const NotificationController = { index, data, markAsRead, markAllAsRead, getUnreadCount, getRecent, bulkMarkAsRead, destroy, bulkDelete }

export default NotificationController