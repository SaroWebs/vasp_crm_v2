import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::page
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:23
 * @route '/admin/attendance/cycle-rules'
 */
export const page = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: page.url(options),
    method: 'get',
})

page.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/cycle-rules',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::page
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:23
 * @route '/admin/attendance/cycle-rules'
 */
page.url = (options?: RouteQueryOptions) => {
    return page.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::page
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:23
 * @route '/admin/attendance/cycle-rules'
 */
page.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: page.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::page
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:23
 * @route '/admin/attendance/cycle-rules'
 */
page.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: page.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::page
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:23
 * @route '/admin/attendance/cycle-rules'
 */
    const pageForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: page.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::page
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:23
 * @route '/admin/attendance/cycle-rules'
 */
        pageForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: page.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::page
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:23
 * @route '/admin/attendance/cycle-rules'
 */
        pageForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: page.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    page.form = pageForm
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::index
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:31
 * @route '/admin/api/attendance/cycle-rules'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/api/attendance/cycle-rules',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::index
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:31
 * @route '/admin/api/attendance/cycle-rules'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::index
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:31
 * @route '/admin/api/attendance/cycle-rules'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::index
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:31
 * @route '/admin/api/attendance/cycle-rules'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::index
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:31
 * @route '/admin/api/attendance/cycle-rules'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::index
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:31
 * @route '/admin/api/attendance/cycle-rules'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::index
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:31
 * @route '/admin/api/attendance/cycle-rules'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::store
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:57
 * @route '/admin/api/attendance/cycle-rules'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/api/attendance/cycle-rules',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::store
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:57
 * @route '/admin/api/attendance/cycle-rules'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::store
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:57
 * @route '/admin/api/attendance/cycle-rules'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::store
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:57
 * @route '/admin/api/attendance/cycle-rules'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::store
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:57
 * @route '/admin/api/attendance/cycle-rules'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::update
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:92
 * @route '/admin/api/attendance/cycle-rules/{monthlyCycleRule}'
 */
export const update = (args: { monthlyCycleRule: number | { id: number } } | [monthlyCycleRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/api/attendance/cycle-rules/{monthlyCycleRule}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::update
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:92
 * @route '/admin/api/attendance/cycle-rules/{monthlyCycleRule}'
 */
update.url = (args: { monthlyCycleRule: number | { id: number } } | [monthlyCycleRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { monthlyCycleRule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { monthlyCycleRule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    monthlyCycleRule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        monthlyCycleRule: typeof args.monthlyCycleRule === 'object'
                ? args.monthlyCycleRule.id
                : args.monthlyCycleRule,
                }

    return update.definition.url
            .replace('{monthlyCycleRule}', parsedArgs.monthlyCycleRule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::update
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:92
 * @route '/admin/api/attendance/cycle-rules/{monthlyCycleRule}'
 */
update.put = (args: { monthlyCycleRule: number | { id: number } } | [monthlyCycleRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::update
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:92
 * @route '/admin/api/attendance/cycle-rules/{monthlyCycleRule}'
 */
    const updateForm = (args: { monthlyCycleRule: number | { id: number } } | [monthlyCycleRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::update
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:92
 * @route '/admin/api/attendance/cycle-rules/{monthlyCycleRule}'
 */
        updateForm.put = (args: { monthlyCycleRule: number | { id: number } } | [monthlyCycleRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::preview
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:118
 * @route '/admin/api/attendance/cycle-rules/preview'
 */
export const preview = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/admin/api/attendance/cycle-rules/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::preview
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:118
 * @route '/admin/api/attendance/cycle-rules/preview'
 */
preview.url = (options?: RouteQueryOptions) => {
    return preview.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::preview
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:118
 * @route '/admin/api/attendance/cycle-rules/preview'
 */
preview.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::preview
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:118
 * @route '/admin/api/attendance/cycle-rules/preview'
 */
preview.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::preview
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:118
 * @route '/admin/api/attendance/cycle-rules/preview'
 */
    const previewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preview.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::preview
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:118
 * @route '/admin/api/attendance/cycle-rules/preview'
 */
        previewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::preview
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:118
 * @route '/admin/api/attendance/cycle-rules/preview'
 */
        previewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preview.form = previewForm
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::currentOpMonth
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:210
 * @route '/admin/api/attendance/op-month/current'
 */
export const currentOpMonth = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: currentOpMonth.url(options),
    method: 'get',
})

currentOpMonth.definition = {
    methods: ["get","head"],
    url: '/admin/api/attendance/op-month/current',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::currentOpMonth
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:210
 * @route '/admin/api/attendance/op-month/current'
 */
currentOpMonth.url = (options?: RouteQueryOptions) => {
    return currentOpMonth.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::currentOpMonth
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:210
 * @route '/admin/api/attendance/op-month/current'
 */
currentOpMonth.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: currentOpMonth.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::currentOpMonth
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:210
 * @route '/admin/api/attendance/op-month/current'
 */
currentOpMonth.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: currentOpMonth.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::currentOpMonth
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:210
 * @route '/admin/api/attendance/op-month/current'
 */
    const currentOpMonthForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: currentOpMonth.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::currentOpMonth
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:210
 * @route '/admin/api/attendance/op-month/current'
 */
        currentOpMonthForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: currentOpMonth.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::currentOpMonth
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:210
 * @route '/admin/api/attendance/op-month/current'
 */
        currentOpMonthForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: currentOpMonth.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    currentOpMonth.form = currentOpMonthForm
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::resolveDate
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:225
 * @route '/admin/api/attendance/op-month/resolve'
 */
export const resolveDate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resolveDate.url(options),
    method: 'get',
})

resolveDate.definition = {
    methods: ["get","head"],
    url: '/admin/api/attendance/op-month/resolve',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::resolveDate
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:225
 * @route '/admin/api/attendance/op-month/resolve'
 */
resolveDate.url = (options?: RouteQueryOptions) => {
    return resolveDate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::resolveDate
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:225
 * @route '/admin/api/attendance/op-month/resolve'
 */
resolveDate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resolveDate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::resolveDate
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:225
 * @route '/admin/api/attendance/op-month/resolve'
 */
resolveDate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: resolveDate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::resolveDate
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:225
 * @route '/admin/api/attendance/op-month/resolve'
 */
    const resolveDateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: resolveDate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::resolveDate
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:225
 * @route '/admin/api/attendance/op-month/resolve'
 */
        resolveDateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resolveDate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::resolveDate
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:225
 * @route '/admin/api/attendance/op-month/resolve'
 */
        resolveDateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resolveDate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    resolveDate.form = resolveDateForm
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::listOpMonths
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:242
 * @route '/admin/api/attendance/op-months'
 */
export const listOpMonths = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listOpMonths.url(options),
    method: 'get',
})

listOpMonths.definition = {
    methods: ["get","head"],
    url: '/admin/api/attendance/op-months',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::listOpMonths
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:242
 * @route '/admin/api/attendance/op-months'
 */
listOpMonths.url = (options?: RouteQueryOptions) => {
    return listOpMonths.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::listOpMonths
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:242
 * @route '/admin/api/attendance/op-months'
 */
listOpMonths.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listOpMonths.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MonthlyCycleRuleController::listOpMonths
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:242
 * @route '/admin/api/attendance/op-months'
 */
listOpMonths.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: listOpMonths.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::listOpMonths
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:242
 * @route '/admin/api/attendance/op-months'
 */
    const listOpMonthsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: listOpMonths.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::listOpMonths
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:242
 * @route '/admin/api/attendance/op-months'
 */
        listOpMonthsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: listOpMonths.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MonthlyCycleRuleController::listOpMonths
 * @see app/Http/Controllers/MonthlyCycleRuleController.php:242
 * @route '/admin/api/attendance/op-months'
 */
        listOpMonthsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: listOpMonths.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    listOpMonths.form = listOpMonthsForm
const MonthlyCycleRuleController = { page, index, store, update, preview, currentOpMonth, resolveDate, listOpMonths }

export default MonthlyCycleRuleController