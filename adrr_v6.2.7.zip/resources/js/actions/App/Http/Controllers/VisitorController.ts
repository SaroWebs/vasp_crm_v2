import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\VisitorController::index
 * @see app/Http/Controllers/VisitorController.php:18
 * @route '/admin/visitors'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/visitors',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VisitorController::index
 * @see app/Http/Controllers/VisitorController.php:18
 * @route '/admin/visitors'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VisitorController::index
 * @see app/Http/Controllers/VisitorController.php:18
 * @route '/admin/visitors'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\VisitorController::index
 * @see app/Http/Controllers/VisitorController.php:18
 * @route '/admin/visitors'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\VisitorController::index
 * @see app/Http/Controllers/VisitorController.php:18
 * @route '/admin/visitors'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\VisitorController::index
 * @see app/Http/Controllers/VisitorController.php:18
 * @route '/admin/visitors'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\VisitorController::index
 * @see app/Http/Controllers/VisitorController.php:18
 * @route '/admin/visitors'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\VisitorController::store
 * @see app/Http/Controllers/VisitorController.php:48
 * @route '/admin/visitors'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/visitors',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\VisitorController::store
 * @see app/Http/Controllers/VisitorController.php:48
 * @route '/admin/visitors'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VisitorController::store
 * @see app/Http/Controllers/VisitorController.php:48
 * @route '/admin/visitors'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\VisitorController::store
 * @see app/Http/Controllers/VisitorController.php:48
 * @route '/admin/visitors'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\VisitorController::store
 * @see app/Http/Controllers/VisitorController.php:48
 * @route '/admin/visitors'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\VisitorController::show
 * @see app/Http/Controllers/VisitorController.php:62
 * @route '/admin/visitors/{visitor}'
 */
export const show = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/visitors/{visitor}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VisitorController::show
 * @see app/Http/Controllers/VisitorController.php:62
 * @route '/admin/visitors/{visitor}'
 */
show.url = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { visitor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { visitor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    visitor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        visitor: typeof args.visitor === 'object'
                ? args.visitor.id
                : args.visitor,
                }

    return show.definition.url
            .replace('{visitor}', parsedArgs.visitor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VisitorController::show
 * @see app/Http/Controllers/VisitorController.php:62
 * @route '/admin/visitors/{visitor}'
 */
show.get = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\VisitorController::show
 * @see app/Http/Controllers/VisitorController.php:62
 * @route '/admin/visitors/{visitor}'
 */
show.head = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\VisitorController::show
 * @see app/Http/Controllers/VisitorController.php:62
 * @route '/admin/visitors/{visitor}'
 */
    const showForm = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\VisitorController::show
 * @see app/Http/Controllers/VisitorController.php:62
 * @route '/admin/visitors/{visitor}'
 */
        showForm.get = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\VisitorController::show
 * @see app/Http/Controllers/VisitorController.php:62
 * @route '/admin/visitors/{visitor}'
 */
        showForm.head = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\VisitorController::update
 * @see app/Http/Controllers/VisitorController.php:72
 * @route '/admin/visitors/{visitor}'
 */
export const update = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/visitors/{visitor}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\VisitorController::update
 * @see app/Http/Controllers/VisitorController.php:72
 * @route '/admin/visitors/{visitor}'
 */
update.url = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { visitor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { visitor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    visitor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        visitor: typeof args.visitor === 'object'
                ? args.visitor.id
                : args.visitor,
                }

    return update.definition.url
            .replace('{visitor}', parsedArgs.visitor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VisitorController::update
 * @see app/Http/Controllers/VisitorController.php:72
 * @route '/admin/visitors/{visitor}'
 */
update.patch = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\VisitorController::update
 * @see app/Http/Controllers/VisitorController.php:72
 * @route '/admin/visitors/{visitor}'
 */
    const updateForm = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\VisitorController::update
 * @see app/Http/Controllers/VisitorController.php:72
 * @route '/admin/visitors/{visitor}'
 */
        updateForm.patch = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\VisitorController::destroy
 * @see app/Http/Controllers/VisitorController.php:86
 * @route '/admin/visitors/{visitor}'
 */
export const destroy = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/visitors/{visitor}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\VisitorController::destroy
 * @see app/Http/Controllers/VisitorController.php:86
 * @route '/admin/visitors/{visitor}'
 */
destroy.url = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { visitor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { visitor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    visitor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        visitor: typeof args.visitor === 'object'
                ? args.visitor.id
                : args.visitor,
                }

    return destroy.definition.url
            .replace('{visitor}', parsedArgs.visitor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VisitorController::destroy
 * @see app/Http/Controllers/VisitorController.php:86
 * @route '/admin/visitors/{visitor}'
 */
destroy.delete = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\VisitorController::destroy
 * @see app/Http/Controllers/VisitorController.php:86
 * @route '/admin/visitors/{visitor}'
 */
    const destroyForm = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\VisitorController::destroy
 * @see app/Http/Controllers/VisitorController.php:86
 * @route '/admin/visitors/{visitor}'
 */
        destroyForm.delete = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\VisitorController::getPunchHistory
 * @see app/Http/Controllers/VisitorController.php:99
 * @route '/admin/visitors/{visitor}/punches'
 */
export const getPunchHistory = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPunchHistory.url(args, options),
    method: 'get',
})

getPunchHistory.definition = {
    methods: ["get","head"],
    url: '/admin/visitors/{visitor}/punches',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VisitorController::getPunchHistory
 * @see app/Http/Controllers/VisitorController.php:99
 * @route '/admin/visitors/{visitor}/punches'
 */
getPunchHistory.url = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { visitor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { visitor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    visitor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        visitor: typeof args.visitor === 'object'
                ? args.visitor.id
                : args.visitor,
                }

    return getPunchHistory.definition.url
            .replace('{visitor}', parsedArgs.visitor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VisitorController::getPunchHistory
 * @see app/Http/Controllers/VisitorController.php:99
 * @route '/admin/visitors/{visitor}/punches'
 */
getPunchHistory.get = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPunchHistory.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\VisitorController::getPunchHistory
 * @see app/Http/Controllers/VisitorController.php:99
 * @route '/admin/visitors/{visitor}/punches'
 */
getPunchHistory.head = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getPunchHistory.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\VisitorController::getPunchHistory
 * @see app/Http/Controllers/VisitorController.php:99
 * @route '/admin/visitors/{visitor}/punches'
 */
    const getPunchHistoryForm = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getPunchHistory.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\VisitorController::getPunchHistory
 * @see app/Http/Controllers/VisitorController.php:99
 * @route '/admin/visitors/{visitor}/punches'
 */
        getPunchHistoryForm.get = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getPunchHistory.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\VisitorController::getPunchHistory
 * @see app/Http/Controllers/VisitorController.php:99
 * @route '/admin/visitors/{visitor}/punches'
 */
        getPunchHistoryForm.head = (args: { visitor: number | { id: number } } | [visitor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getPunchHistory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getPunchHistory.form = getPunchHistoryForm
/**
* @see \App\Http\Controllers\VisitorController::bulkDelete
 * @see app/Http/Controllers/VisitorController.php:116
 * @route '/admin/visitors/bulk-delete'
 */
export const bulkDelete = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkDelete.url(options),
    method: 'post',
})

bulkDelete.definition = {
    methods: ["post"],
    url: '/admin/visitors/bulk-delete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\VisitorController::bulkDelete
 * @see app/Http/Controllers/VisitorController.php:116
 * @route '/admin/visitors/bulk-delete'
 */
bulkDelete.url = (options?: RouteQueryOptions) => {
    return bulkDelete.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VisitorController::bulkDelete
 * @see app/Http/Controllers/VisitorController.php:116
 * @route '/admin/visitors/bulk-delete'
 */
bulkDelete.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkDelete.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\VisitorController::bulkDelete
 * @see app/Http/Controllers/VisitorController.php:116
 * @route '/admin/visitors/bulk-delete'
 */
    const bulkDeleteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkDelete.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\VisitorController::bulkDelete
 * @see app/Http/Controllers/VisitorController.php:116
 * @route '/admin/visitors/bulk-delete'
 */
        bulkDeleteForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkDelete.url(options),
            method: 'post',
        })
    
    bulkDelete.form = bulkDeleteForm
/**
* @see \App\Http\Controllers\VisitorController::bulkToggleActive
 * @see app/Http/Controllers/VisitorController.php:134
 * @route '/admin/visitors/bulk-toggle-active'
 */
export const bulkToggleActive = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkToggleActive.url(options),
    method: 'post',
})

bulkToggleActive.definition = {
    methods: ["post"],
    url: '/admin/visitors/bulk-toggle-active',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\VisitorController::bulkToggleActive
 * @see app/Http/Controllers/VisitorController.php:134
 * @route '/admin/visitors/bulk-toggle-active'
 */
bulkToggleActive.url = (options?: RouteQueryOptions) => {
    return bulkToggleActive.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VisitorController::bulkToggleActive
 * @see app/Http/Controllers/VisitorController.php:134
 * @route '/admin/visitors/bulk-toggle-active'
 */
bulkToggleActive.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkToggleActive.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\VisitorController::bulkToggleActive
 * @see app/Http/Controllers/VisitorController.php:134
 * @route '/admin/visitors/bulk-toggle-active'
 */
    const bulkToggleActiveForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkToggleActive.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\VisitorController::bulkToggleActive
 * @see app/Http/Controllers/VisitorController.php:134
 * @route '/admin/visitors/bulk-toggle-active'
 */
        bulkToggleActiveForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkToggleActive.url(options),
            method: 'post',
        })
    
    bulkToggleActive.form = bulkToggleActiveForm
const VisitorController = { index, store, show, update, destroy, getPunchHistory, bulkDelete, bulkToggleActive }

export default VisitorController