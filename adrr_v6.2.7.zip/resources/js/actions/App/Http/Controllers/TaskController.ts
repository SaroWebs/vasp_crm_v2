import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TaskController::storeSelfAssigned
 * @see app/Http/Controllers/TaskController.php:237
 * @route '/self/tasks'
 */
export const storeSelfAssigned = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSelfAssigned.url(options),
    method: 'post',
})

storeSelfAssigned.definition = {
    methods: ["post"],
    url: '/self/tasks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::storeSelfAssigned
 * @see app/Http/Controllers/TaskController.php:237
 * @route '/self/tasks'
 */
storeSelfAssigned.url = (options?: RouteQueryOptions) => {
    return storeSelfAssigned.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::storeSelfAssigned
 * @see app/Http/Controllers/TaskController.php:237
 * @route '/self/tasks'
 */
storeSelfAssigned.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSelfAssigned.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::storeSelfAssigned
 * @see app/Http/Controllers/TaskController.php:237
 * @route '/self/tasks'
 */
    const storeSelfAssignedForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSelfAssigned.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::storeSelfAssigned
 * @see app/Http/Controllers/TaskController.php:237
 * @route '/self/tasks'
 */
        storeSelfAssignedForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSelfAssigned.url(options),
            method: 'post',
        })
    
    storeSelfAssigned.form = storeSelfAssignedForm
/**
* @see \App\Http\Controllers\TaskController::getMyTasks
 * @see app/Http/Controllers/TaskController.php:511
 * @route '/data/my/tasks'
 */
export const getMyTasks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMyTasks.url(options),
    method: 'get',
})

getMyTasks.definition = {
    methods: ["get","head"],
    url: '/data/my/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::getMyTasks
 * @see app/Http/Controllers/TaskController.php:511
 * @route '/data/my/tasks'
 */
getMyTasks.url = (options?: RouteQueryOptions) => {
    return getMyTasks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::getMyTasks
 * @see app/Http/Controllers/TaskController.php:511
 * @route '/data/my/tasks'
 */
getMyTasks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMyTasks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::getMyTasks
 * @see app/Http/Controllers/TaskController.php:511
 * @route '/data/my/tasks'
 */
getMyTasks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getMyTasks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::getMyTasks
 * @see app/Http/Controllers/TaskController.php:511
 * @route '/data/my/tasks'
 */
    const getMyTasksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getMyTasks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::getMyTasks
 * @see app/Http/Controllers/TaskController.php:511
 * @route '/data/my/tasks'
 */
        getMyTasksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getMyTasks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::getMyTasks
 * @see app/Http/Controllers/TaskController.php:511
 * @route '/data/my/tasks'
 */
        getMyTasksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getMyTasks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getMyTasks.form = getMyTasksForm
/**
* @see \App\Http\Controllers\TaskController::getAllTasks
 * @see app/Http/Controllers/TaskController.php:409
 * @route '/data/all/tasks'
 */
export const getAllTasks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAllTasks.url(options),
    method: 'get',
})

getAllTasks.definition = {
    methods: ["get","head"],
    url: '/data/all/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::getAllTasks
 * @see app/Http/Controllers/TaskController.php:409
 * @route '/data/all/tasks'
 */
getAllTasks.url = (options?: RouteQueryOptions) => {
    return getAllTasks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::getAllTasks
 * @see app/Http/Controllers/TaskController.php:409
 * @route '/data/all/tasks'
 */
getAllTasks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAllTasks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::getAllTasks
 * @see app/Http/Controllers/TaskController.php:409
 * @route '/data/all/tasks'
 */
getAllTasks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAllTasks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::getAllTasks
 * @see app/Http/Controllers/TaskController.php:409
 * @route '/data/all/tasks'
 */
    const getAllTasksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getAllTasks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::getAllTasks
 * @see app/Http/Controllers/TaskController.php:409
 * @route '/data/all/tasks'
 */
        getAllTasksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAllTasks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::getAllTasks
 * @see app/Http/Controllers/TaskController.php:409
 * @route '/data/all/tasks'
 */
        getAllTasksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAllTasks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getAllTasks.form = getAllTasksForm
/**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1822
 * @route '/data/tasks/calculate-min-due-date'
 */
export const calculateMinDueDate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateMinDueDate.url(options),
    method: 'get',
})

calculateMinDueDate.definition = {
    methods: ["get","head"],
    url: '/data/tasks/calculate-min-due-date',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1822
 * @route '/data/tasks/calculate-min-due-date'
 */
calculateMinDueDate.url = (options?: RouteQueryOptions) => {
    return calculateMinDueDate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1822
 * @route '/data/tasks/calculate-min-due-date'
 */
calculateMinDueDate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateMinDueDate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1822
 * @route '/data/tasks/calculate-min-due-date'
 */
calculateMinDueDate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calculateMinDueDate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1822
 * @route '/data/tasks/calculate-min-due-date'
 */
    const calculateMinDueDateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calculateMinDueDate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1822
 * @route '/data/tasks/calculate-min-due-date'
 */
        calculateMinDueDateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateMinDueDate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::calculateMinDueDate
 * @see app/Http/Controllers/TaskController.php:1822
 * @route '/data/tasks/calculate-min-due-date'
 */
        calculateMinDueDateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateMinDueDate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calculateMinDueDate.form = calculateMinDueDateForm
/**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:148
 * @route '/data/tasks/{task}'
 */
export const show = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:148
 * @route '/data/tasks/{task}'
 */
show.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return show.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:148
 * @route '/data/tasks/{task}'
 */
show.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:148
 * @route '/data/tasks/{task}'
 */
show.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:148
 * @route '/data/tasks/{task}'
 */
    const showForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:148
 * @route '/data/tasks/{task}'
 */
        showForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::show
 * @see app/Http/Controllers/TaskController.php:148
 * @route '/data/tasks/{task}'
 */
        showForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:291
 * @route '/data/tasks/{task}'
 */
export const update = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/data/tasks/{task}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:291
 * @route '/data/tasks/{task}'
 */
update.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return update.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:291
 * @route '/data/tasks/{task}'
 */
update.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:291
 * @route '/data/tasks/{task}'
 */
    const updateForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::update
 * @see app/Http/Controllers/TaskController.php:291
 * @route '/data/tasks/{task}'
 */
        updateForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:347
 * @route '/data/tasks/{task}/extend-due-date'
 */
export const extendDueDate = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: extendDueDate.url(args, options),
    method: 'patch',
})

extendDueDate.definition = {
    methods: ["patch"],
    url: '/data/tasks/{task}/extend-due-date',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:347
 * @route '/data/tasks/{task}/extend-due-date'
 */
extendDueDate.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return extendDueDate.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:347
 * @route '/data/tasks/{task}/extend-due-date'
 */
extendDueDate.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: extendDueDate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:347
 * @route '/data/tasks/{task}/extend-due-date'
 */
    const extendDueDateForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: extendDueDate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::extendDueDate
 * @see app/Http/Controllers/TaskController.php:347
 * @route '/data/tasks/{task}/extend-due-date'
 */
        extendDueDateForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: extendDueDate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    extendDueDate.form = extendDueDateForm
/**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:375
 * @route '/data/tasks/{task}'
 */
export const destroy = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/data/tasks/{task}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:375
 * @route '/data/tasks/{task}'
 */
destroy.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return destroy.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:375
 * @route '/data/tasks/{task}'
 */
destroy.delete = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:375
 * @route '/data/tasks/{task}'
 */
    const destroyForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::destroy
 * @see app/Http/Controllers/TaskController.php:375
 * @route '/data/tasks/{task}'
 */
        destroyForm.delete = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:637
 * @route '/data/tasks/{task}/status'
 */
export const updateStatus = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/data/tasks/{task}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:637
 * @route '/data/tasks/{task}/status'
 */
updateStatus.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return updateStatus.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:637
 * @route '/data/tasks/{task}/status'
 */
updateStatus.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:637
 * @route '/data/tasks/{task}/status'
 */
    const updateStatusForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::updateStatus
 * @see app/Http/Controllers/TaskController.php:637
 * @route '/data/tasks/{task}/status'
 */
        updateStatusForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\TaskController::getTasksByStatus
 * @see app/Http/Controllers/TaskController.php:599
 * @route '/data/tasks/status/{status}'
 */
export const getTasksByStatus = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTasksByStatus.url(args, options),
    method: 'get',
})

getTasksByStatus.definition = {
    methods: ["get","head"],
    url: '/data/tasks/status/{status}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::getTasksByStatus
 * @see app/Http/Controllers/TaskController.php:599
 * @route '/data/tasks/status/{status}'
 */
getTasksByStatus.url = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { status: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    status: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        status: args.status,
                }

    return getTasksByStatus.definition.url
            .replace('{status}', parsedArgs.status.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::getTasksByStatus
 * @see app/Http/Controllers/TaskController.php:599
 * @route '/data/tasks/status/{status}'
 */
getTasksByStatus.get = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTasksByStatus.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::getTasksByStatus
 * @see app/Http/Controllers/TaskController.php:599
 * @route '/data/tasks/status/{status}'
 */
getTasksByStatus.head = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTasksByStatus.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::getTasksByStatus
 * @see app/Http/Controllers/TaskController.php:599
 * @route '/data/tasks/status/{status}'
 */
    const getTasksByStatusForm = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTasksByStatus.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::getTasksByStatus
 * @see app/Http/Controllers/TaskController.php:599
 * @route '/data/tasks/status/{status}'
 */
        getTasksByStatusForm.get = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTasksByStatus.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::getTasksByStatus
 * @see app/Http/Controllers/TaskController.php:599
 * @route '/data/tasks/status/{status}'
 */
        getTasksByStatusForm.head = (args: { status: string | number } | [status: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTasksByStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTasksByStatus.form = getTasksByStatusForm
/**
* @see \App\Http\Controllers\TaskController::getTaskTypes
 * @see app/Http/Controllers/TaskController.php:1442
 * @route '/data/task-types'
 */
export const getTaskTypes = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTaskTypes.url(options),
    method: 'get',
})

getTaskTypes.definition = {
    methods: ["get","head"],
    url: '/data/task-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::getTaskTypes
 * @see app/Http/Controllers/TaskController.php:1442
 * @route '/data/task-types'
 */
getTaskTypes.url = (options?: RouteQueryOptions) => {
    return getTaskTypes.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::getTaskTypes
 * @see app/Http/Controllers/TaskController.php:1442
 * @route '/data/task-types'
 */
getTaskTypes.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getTaskTypes.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::getTaskTypes
 * @see app/Http/Controllers/TaskController.php:1442
 * @route '/data/task-types'
 */
getTaskTypes.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getTaskTypes.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::getTaskTypes
 * @see app/Http/Controllers/TaskController.php:1442
 * @route '/data/task-types'
 */
    const getTaskTypesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getTaskTypes.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::getTaskTypes
 * @see app/Http/Controllers/TaskController.php:1442
 * @route '/data/task-types'
 */
        getTaskTypesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTaskTypes.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::getTaskTypes
 * @see app/Http/Controllers/TaskController.php:1442
 * @route '/data/task-types'
 */
        getTaskTypesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getTaskTypes.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getTaskTypes.form = getTaskTypesForm
/**
* @see \App\Http\Controllers\TaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/TaskController.php:1465
 * @route '/data/task-types/{taskType}/sla-policies'
 */
export const getSlaPoliciesByTaskType = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSlaPoliciesByTaskType.url(args, options),
    method: 'get',
})

getSlaPoliciesByTaskType.definition = {
    methods: ["get","head"],
    url: '/data/task-types/{taskType}/sla-policies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/TaskController.php:1465
 * @route '/data/task-types/{taskType}/sla-policies'
 */
getSlaPoliciesByTaskType.url = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskType: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    taskType: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        taskType: args.taskType,
                }

    return getSlaPoliciesByTaskType.definition.url
            .replace('{taskType}', parsedArgs.taskType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/TaskController.php:1465
 * @route '/data/task-types/{taskType}/sla-policies'
 */
getSlaPoliciesByTaskType.get = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getSlaPoliciesByTaskType.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/TaskController.php:1465
 * @route '/data/task-types/{taskType}/sla-policies'
 */
getSlaPoliciesByTaskType.head = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getSlaPoliciesByTaskType.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/TaskController.php:1465
 * @route '/data/task-types/{taskType}/sla-policies'
 */
    const getSlaPoliciesByTaskTypeForm = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getSlaPoliciesByTaskType.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/TaskController.php:1465
 * @route '/data/task-types/{taskType}/sla-policies'
 */
        getSlaPoliciesByTaskTypeForm.get = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getSlaPoliciesByTaskType.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::getSlaPoliciesByTaskType
 * @see app/Http/Controllers/TaskController.php:1465
 * @route '/data/task-types/{taskType}/sla-policies'
 */
        getSlaPoliciesByTaskTypeForm.head = (args: { taskType: string | number } | [taskType: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getSlaPoliciesByTaskType.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getSlaPoliciesByTaskType.form = getSlaPoliciesByTaskTypeForm
/**
* @see \App\Http\Controllers\TaskController::getHistory
 * @see app/Http/Controllers/TaskController.php:1419
 * @route '/data/tasks/{task}/history'
 */
export const getHistory = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getHistory.url(args, options),
    method: 'get',
})

getHistory.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::getHistory
 * @see app/Http/Controllers/TaskController.php:1419
 * @route '/data/tasks/{task}/history'
 */
getHistory.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return getHistory.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::getHistory
 * @see app/Http/Controllers/TaskController.php:1419
 * @route '/data/tasks/{task}/history'
 */
getHistory.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getHistory.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::getHistory
 * @see app/Http/Controllers/TaskController.php:1419
 * @route '/data/tasks/{task}/history'
 */
getHistory.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getHistory.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::getHistory
 * @see app/Http/Controllers/TaskController.php:1419
 * @route '/data/tasks/{task}/history'
 */
    const getHistoryForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getHistory.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::getHistory
 * @see app/Http/Controllers/TaskController.php:1419
 * @route '/data/tasks/{task}/history'
 */
        getHistoryForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getHistory.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::getHistory
 * @see app/Http/Controllers/TaskController.php:1419
 * @route '/data/tasks/{task}/history'
 */
        getHistoryForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getHistory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getHistory.form = getHistoryForm
/**
* @see \App\Http\Controllers\TaskController::getWorkloadMetrics
 * @see app/Http/Controllers/TaskController.php:1368
 * @route '/data/tasks/{task}/workload-metrics'
 */
export const getWorkloadMetrics = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getWorkloadMetrics.url(args, options),
    method: 'get',
})

getWorkloadMetrics.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/workload-metrics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::getWorkloadMetrics
 * @see app/Http/Controllers/TaskController.php:1368
 * @route '/data/tasks/{task}/workload-metrics'
 */
getWorkloadMetrics.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return getWorkloadMetrics.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::getWorkloadMetrics
 * @see app/Http/Controllers/TaskController.php:1368
 * @route '/data/tasks/{task}/workload-metrics'
 */
getWorkloadMetrics.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getWorkloadMetrics.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::getWorkloadMetrics
 * @see app/Http/Controllers/TaskController.php:1368
 * @route '/data/tasks/{task}/workload-metrics'
 */
getWorkloadMetrics.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getWorkloadMetrics.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::getWorkloadMetrics
 * @see app/Http/Controllers/TaskController.php:1368
 * @route '/data/tasks/{task}/workload-metrics'
 */
    const getWorkloadMetricsForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getWorkloadMetrics.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::getWorkloadMetrics
 * @see app/Http/Controllers/TaskController.php:1368
 * @route '/data/tasks/{task}/workload-metrics'
 */
        getWorkloadMetricsForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getWorkloadMetrics.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::getWorkloadMetrics
 * @see app/Http/Controllers/TaskController.php:1368
 * @route '/data/tasks/{task}/workload-metrics'
 */
        getWorkloadMetricsForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getWorkloadMetrics.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getWorkloadMetrics.form = getWorkloadMetricsForm
/**
* @see \App\Http\Controllers\TaskController::getAuditEvents
 * @see app/Http/Controllers/TaskController.php:1396
 * @route '/data/tasks/{task}/audit-events'
 */
export const getAuditEvents = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAuditEvents.url(args, options),
    method: 'get',
})

getAuditEvents.definition = {
    methods: ["get","head"],
    url: '/data/tasks/{task}/audit-events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::getAuditEvents
 * @see app/Http/Controllers/TaskController.php:1396
 * @route '/data/tasks/{task}/audit-events'
 */
getAuditEvents.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return getAuditEvents.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::getAuditEvents
 * @see app/Http/Controllers/TaskController.php:1396
 * @route '/data/tasks/{task}/audit-events'
 */
getAuditEvents.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAuditEvents.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::getAuditEvents
 * @see app/Http/Controllers/TaskController.php:1396
 * @route '/data/tasks/{task}/audit-events'
 */
getAuditEvents.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAuditEvents.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::getAuditEvents
 * @see app/Http/Controllers/TaskController.php:1396
 * @route '/data/tasks/{task}/audit-events'
 */
    const getAuditEventsForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getAuditEvents.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::getAuditEvents
 * @see app/Http/Controllers/TaskController.php:1396
 * @route '/data/tasks/{task}/audit-events'
 */
        getAuditEventsForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAuditEvents.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::getAuditEvents
 * @see app/Http/Controllers/TaskController.php:1396
 * @route '/data/tasks/{task}/audit-events'
 */
        getAuditEventsForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAuditEvents.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getAuditEvents.form = getAuditEventsForm
/**
* @see \App\Http\Controllers\TaskController::myTasks
 * @see app/Http/Controllers/TaskController.php:1312
 * @route '/my/tasks'
 */
export const myTasks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myTasks.url(options),
    method: 'get',
})

myTasks.definition = {
    methods: ["get","head"],
    url: '/my/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::myTasks
 * @see app/Http/Controllers/TaskController.php:1312
 * @route '/my/tasks'
 */
myTasks.url = (options?: RouteQueryOptions) => {
    return myTasks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::myTasks
 * @see app/Http/Controllers/TaskController.php:1312
 * @route '/my/tasks'
 */
myTasks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myTasks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::myTasks
 * @see app/Http/Controllers/TaskController.php:1312
 * @route '/my/tasks'
 */
myTasks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myTasks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::myTasks
 * @see app/Http/Controllers/TaskController.php:1312
 * @route '/my/tasks'
 */
    const myTasksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: myTasks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::myTasks
 * @see app/Http/Controllers/TaskController.php:1312
 * @route '/my/tasks'
 */
        myTasksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myTasks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::myTasks
 * @see app/Http/Controllers/TaskController.php:1312
 * @route '/my/tasks'
 */
        myTasksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: myTasks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    myTasks.form = myTasksForm
/**
* @see \App\Http\Controllers\TaskController::startTask
 * @see app/Http/Controllers/TaskController.php:704
 * @route '/tasks/{task}/start'
 */
export const startTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startTask.url(args, options),
    method: 'post',
})

startTask.definition = {
    methods: ["post"],
    url: '/tasks/{task}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::startTask
 * @see app/Http/Controllers/TaskController.php:704
 * @route '/tasks/{task}/start'
 */
startTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return startTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::startTask
 * @see app/Http/Controllers/TaskController.php:704
 * @route '/tasks/{task}/start'
 */
startTask.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::startTask
 * @see app/Http/Controllers/TaskController.php:704
 * @route '/tasks/{task}/start'
 */
    const startTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: startTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::startTask
 * @see app/Http/Controllers/TaskController.php:704
 * @route '/tasks/{task}/start'
 */
        startTaskForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: startTask.url(args, options),
            method: 'post',
        })
    
    startTask.form = startTaskForm
/**
* @see \App\Http\Controllers\TaskController::pauseTask
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
export const pauseTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pauseTask.url(args, options),
    method: 'post',
})

pauseTask.definition = {
    methods: ["post"],
    url: '/tasks/{task}/pause',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::pauseTask
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
pauseTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return pauseTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::pauseTask
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
pauseTask.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pauseTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::pauseTask
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
    const pauseTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pauseTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::pauseTask
 * @see app/Http/Controllers/TaskController.php:784
 * @route '/tasks/{task}/pause'
 */
        pauseTaskForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pauseTask.url(args, options),
            method: 'post',
        })
    
    pauseTask.form = pauseTaskForm
/**
* @see \App\Http\Controllers\TaskController::resumeTask
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
export const resumeTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resumeTask.url(args, options),
    method: 'post',
})

resumeTask.definition = {
    methods: ["post"],
    url: '/tasks/{task}/resume',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::resumeTask
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
resumeTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return resumeTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::resumeTask
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
resumeTask.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resumeTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::resumeTask
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
    const resumeTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resumeTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::resumeTask
 * @see app/Http/Controllers/TaskController.php:843
 * @route '/tasks/{task}/resume'
 */
        resumeTaskForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resumeTask.url(args, options),
            method: 'post',
        })
    
    resumeTask.form = resumeTaskForm
/**
* @see \App\Http\Controllers\TaskController::endTask
 * @see app/Http/Controllers/TaskController.php:923
 * @route '/tasks/{task}/end'
 */
export const endTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: endTask.url(args, options),
    method: 'post',
})

endTask.definition = {
    methods: ["post"],
    url: '/tasks/{task}/end',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TaskController::endTask
 * @see app/Http/Controllers/TaskController.php:923
 * @route '/tasks/{task}/end'
 */
endTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return endTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::endTask
 * @see app/Http/Controllers/TaskController.php:923
 * @route '/tasks/{task}/end'
 */
endTask.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: endTask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TaskController::endTask
 * @see app/Http/Controllers/TaskController.php:923
 * @route '/tasks/{task}/end'
 */
    const endTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: endTask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TaskController::endTask
 * @see app/Http/Controllers/TaskController.php:923
 * @route '/tasks/{task}/end'
 */
        endTaskForm.post = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: endTask.url(args, options),
            method: 'post',
        })
    
    endTask.form = endTaskForm
/**
* @see \App\Http\Controllers\TaskController::calculateTimeSpent
 * @see app/Http/Controllers/TaskController.php:994
 * @route '/tasks/{task}/time-spent'
 */
export const calculateTimeSpent = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateTimeSpent.url(args, options),
    method: 'get',
})

calculateTimeSpent.definition = {
    methods: ["get","head"],
    url: '/tasks/{task}/time-spent',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::calculateTimeSpent
 * @see app/Http/Controllers/TaskController.php:994
 * @route '/tasks/{task}/time-spent'
 */
calculateTimeSpent.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return calculateTimeSpent.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::calculateTimeSpent
 * @see app/Http/Controllers/TaskController.php:994
 * @route '/tasks/{task}/time-spent'
 */
calculateTimeSpent.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateTimeSpent.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::calculateTimeSpent
 * @see app/Http/Controllers/TaskController.php:994
 * @route '/tasks/{task}/time-spent'
 */
calculateTimeSpent.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calculateTimeSpent.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::calculateTimeSpent
 * @see app/Http/Controllers/TaskController.php:994
 * @route '/tasks/{task}/time-spent'
 */
    const calculateTimeSpentForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calculateTimeSpent.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::calculateTimeSpent
 * @see app/Http/Controllers/TaskController.php:994
 * @route '/tasks/{task}/time-spent'
 */
        calculateTimeSpentForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateTimeSpent.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::calculateTimeSpent
 * @see app/Http/Controllers/TaskController.php:994
 * @route '/tasks/{task}/time-spent'
 */
        calculateTimeSpentForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateTimeSpent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calculateTimeSpent.form = calculateTimeSpentForm
/**
* @see \App\Http\Controllers\TaskController::calculateRemainingTime
 * @see app/Http/Controllers/TaskController.php:1038
 * @route '/tasks/{task}/remaining-time'
 */
export const calculateRemainingTime = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateRemainingTime.url(args, options),
    method: 'get',
})

calculateRemainingTime.definition = {
    methods: ["get","head"],
    url: '/tasks/{task}/remaining-time',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TaskController::calculateRemainingTime
 * @see app/Http/Controllers/TaskController.php:1038
 * @route '/tasks/{task}/remaining-time'
 */
calculateRemainingTime.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { task: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    task: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return calculateRemainingTime.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TaskController::calculateRemainingTime
 * @see app/Http/Controllers/TaskController.php:1038
 * @route '/tasks/{task}/remaining-time'
 */
calculateRemainingTime.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calculateRemainingTime.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TaskController::calculateRemainingTime
 * @see app/Http/Controllers/TaskController.php:1038
 * @route '/tasks/{task}/remaining-time'
 */
calculateRemainingTime.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calculateRemainingTime.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TaskController::calculateRemainingTime
 * @see app/Http/Controllers/TaskController.php:1038
 * @route '/tasks/{task}/remaining-time'
 */
    const calculateRemainingTimeForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calculateRemainingTime.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TaskController::calculateRemainingTime
 * @see app/Http/Controllers/TaskController.php:1038
 * @route '/tasks/{task}/remaining-time'
 */
        calculateRemainingTimeForm.get = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateRemainingTime.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TaskController::calculateRemainingTime
 * @see app/Http/Controllers/TaskController.php:1038
 * @route '/tasks/{task}/remaining-time'
 */
        calculateRemainingTimeForm.head = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calculateRemainingTime.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calculateRemainingTime.form = calculateRemainingTimeForm
const TaskController = { storeSelfAssigned, getMyTasks, getAllTasks, calculateMinDueDate, show, update, extendDueDate, destroy, updateStatus, getTasksByStatus, getTaskTypes, getSlaPoliciesByTaskType, getHistory, getWorkloadMetrics, getAuditEvents, myTasks, startTask, pauseTask, resumeTask, endTask, calculateTimeSpent, calculateRemainingTime }

export default TaskController