import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\EmployeeCategoryController::getData
 * @see app/Http/Controllers/EmployeeCategoryController.php:16
 * @route '/api/get_categories'
 */
export const getData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getData.url(options),
    method: 'get',
})

getData.definition = {
    methods: ["get","head"],
    url: '/api/get_categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmployeeCategoryController::getData
 * @see app/Http/Controllers/EmployeeCategoryController.php:16
 * @route '/api/get_categories'
 */
getData.url = (options?: RouteQueryOptions) => {
    return getData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeCategoryController::getData
 * @see app/Http/Controllers/EmployeeCategoryController.php:16
 * @route '/api/get_categories'
 */
getData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getData.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmployeeCategoryController::getData
 * @see app/Http/Controllers/EmployeeCategoryController.php:16
 * @route '/api/get_categories'
 */
getData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getData.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmployeeCategoryController::getData
 * @see app/Http/Controllers/EmployeeCategoryController.php:16
 * @route '/api/get_categories'
 */
    const getDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getData.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmployeeCategoryController::getData
 * @see app/Http/Controllers/EmployeeCategoryController.php:16
 * @route '/api/get_categories'
 */
        getDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getData.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmployeeCategoryController::getData
 * @see app/Http/Controllers/EmployeeCategoryController.php:16
 * @route '/api/get_categories'
 */
        getDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getData.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getData.form = getDataForm
/**
* @see \App\Http\Controllers\EmployeeCategoryController::getEmployees
 * @see app/Http/Controllers/EmployeeCategoryController.php:25
 * @route '/api/get_employees'
 */
export const getEmployees = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: getEmployees.url(options),
    method: 'post',
})

getEmployees.definition = {
    methods: ["post"],
    url: '/api/get_employees',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\EmployeeCategoryController::getEmployees
 * @see app/Http/Controllers/EmployeeCategoryController.php:25
 * @route '/api/get_employees'
 */
getEmployees.url = (options?: RouteQueryOptions) => {
    return getEmployees.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeCategoryController::getEmployees
 * @see app/Http/Controllers/EmployeeCategoryController.php:25
 * @route '/api/get_employees'
 */
getEmployees.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: getEmployees.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\EmployeeCategoryController::getEmployees
 * @see app/Http/Controllers/EmployeeCategoryController.php:25
 * @route '/api/get_employees'
 */
    const getEmployeesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: getEmployees.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\EmployeeCategoryController::getEmployees
 * @see app/Http/Controllers/EmployeeCategoryController.php:25
 * @route '/api/get_employees'
 */
        getEmployeesForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: getEmployees.url(options),
            method: 'post',
        })
    
    getEmployees.form = getEmployeesForm
const EmployeeCategoryController = { getData, getEmployees }

export default EmployeeCategoryController