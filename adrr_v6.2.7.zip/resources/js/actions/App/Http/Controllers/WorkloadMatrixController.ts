import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/workload-matrix',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WorkloadMatrixController::index
 * @see app/Http/Controllers/WorkloadMatrixController.php:17
 * @route '/admin/workload-matrix'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\WorkloadMatrixController::data
 * @see app/Http/Controllers/WorkloadMatrixController.php:55
 * @route '/admin/api/workload-matrix'
 */
export const data = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})

data.definition = {
    methods: ["get","head"],
    url: '/admin/api/workload-matrix',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WorkloadMatrixController::data
 * @see app/Http/Controllers/WorkloadMatrixController.php:55
 * @route '/admin/api/workload-matrix'
 */
data.url = (options?: RouteQueryOptions) => {
    return data.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WorkloadMatrixController::data
 * @see app/Http/Controllers/WorkloadMatrixController.php:55
 * @route '/admin/api/workload-matrix'
 */
data.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WorkloadMatrixController::data
 * @see app/Http/Controllers/WorkloadMatrixController.php:55
 * @route '/admin/api/workload-matrix'
 */
data.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WorkloadMatrixController::data
 * @see app/Http/Controllers/WorkloadMatrixController.php:55
 * @route '/admin/api/workload-matrix'
 */
    const dataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: data.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WorkloadMatrixController::data
 * @see app/Http/Controllers/WorkloadMatrixController.php:55
 * @route '/admin/api/workload-matrix'
 */
        dataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WorkloadMatrixController::data
 * @see app/Http/Controllers/WorkloadMatrixController.php:55
 * @route '/admin/api/workload-matrix'
 */
        dataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    data.form = dataForm
/**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
export const tasks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tasks.url(options),
    method: 'get',
})

tasks.definition = {
    methods: ["get","head"],
    url: '/admin/api/workload-matrix/tasks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
tasks.url = (options?: RouteQueryOptions) => {
    return tasks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
tasks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tasks.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
tasks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tasks.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
    const tasksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: tasks.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
        tasksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tasks.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WorkloadMatrixController::tasks
 * @see app/Http/Controllers/WorkloadMatrixController.php:136
 * @route '/admin/api/workload-matrix/tasks'
 */
        tasksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tasks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    tasks.form = tasksForm
/**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/admin/api/workload-matrix/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WorkloadMatrixController::exportMethod
 * @see app/Http/Controllers/WorkloadMatrixController.php:66
 * @route '/admin/api/workload-matrix/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const WorkloadMatrixController = { index, data, tasks, exportMethod, export: exportMethod }

export default WorkloadMatrixController