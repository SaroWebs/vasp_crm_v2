import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\EmployeeProgressController::showEmployeeProgressPanel
 * @see app/Http/Controllers/EmployeeProgressController.php:195
 * @route '/admin/employee-progress'
 */
export const showEmployeeProgressPanel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showEmployeeProgressPanel.url(options),
    method: 'get',
})

showEmployeeProgressPanel.definition = {
    methods: ["get","head"],
    url: '/admin/employee-progress',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmployeeProgressController::showEmployeeProgressPanel
 * @see app/Http/Controllers/EmployeeProgressController.php:195
 * @route '/admin/employee-progress'
 */
showEmployeeProgressPanel.url = (options?: RouteQueryOptions) => {
    return showEmployeeProgressPanel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeProgressController::showEmployeeProgressPanel
 * @see app/Http/Controllers/EmployeeProgressController.php:195
 * @route '/admin/employee-progress'
 */
showEmployeeProgressPanel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showEmployeeProgressPanel.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmployeeProgressController::showEmployeeProgressPanel
 * @see app/Http/Controllers/EmployeeProgressController.php:195
 * @route '/admin/employee-progress'
 */
showEmployeeProgressPanel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showEmployeeProgressPanel.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmployeeProgressController::showEmployeeProgressPanel
 * @see app/Http/Controllers/EmployeeProgressController.php:195
 * @route '/admin/employee-progress'
 */
    const showEmployeeProgressPanelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showEmployeeProgressPanel.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmployeeProgressController::showEmployeeProgressPanel
 * @see app/Http/Controllers/EmployeeProgressController.php:195
 * @route '/admin/employee-progress'
 */
        showEmployeeProgressPanelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showEmployeeProgressPanel.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmployeeProgressController::showEmployeeProgressPanel
 * @see app/Http/Controllers/EmployeeProgressController.php:195
 * @route '/admin/employee-progress'
 */
        showEmployeeProgressPanelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showEmployeeProgressPanel.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showEmployeeProgressPanel.form = showEmployeeProgressPanelForm
/**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressData
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
export const getEmployeeProgressData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeProgressData.url(options),
    method: 'get',
})

getEmployeeProgressData.definition = {
    methods: ["get","head"],
    url: '/admin/api/employee-progress',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressData
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
getEmployeeProgressData.url = (options?: RouteQueryOptions) => {
    return getEmployeeProgressData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressData
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
getEmployeeProgressData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeProgressData.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressData
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
getEmployeeProgressData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeProgressData.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressData
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
    const getEmployeeProgressDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeProgressData.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressData
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
        getEmployeeProgressDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeProgressData.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressData
 * @see app/Http/Controllers/EmployeeProgressController.php:18
 * @route '/admin/api/employee-progress'
 */
        getEmployeeProgressDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeProgressData.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeProgressData.form = getEmployeeProgressDataForm
/**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressStats
 * @see app/Http/Controllers/EmployeeProgressController.php:213
 * @route '/admin/api/employee-progress/stats'
 */
export const getEmployeeProgressStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeProgressStats.url(options),
    method: 'get',
})

getEmployeeProgressStats.definition = {
    methods: ["get","head"],
    url: '/admin/api/employee-progress/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressStats
 * @see app/Http/Controllers/EmployeeProgressController.php:213
 * @route '/admin/api/employee-progress/stats'
 */
getEmployeeProgressStats.url = (options?: RouteQueryOptions) => {
    return getEmployeeProgressStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressStats
 * @see app/Http/Controllers/EmployeeProgressController.php:213
 * @route '/admin/api/employee-progress/stats'
 */
getEmployeeProgressStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getEmployeeProgressStats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressStats
 * @see app/Http/Controllers/EmployeeProgressController.php:213
 * @route '/admin/api/employee-progress/stats'
 */
getEmployeeProgressStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getEmployeeProgressStats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressStats
 * @see app/Http/Controllers/EmployeeProgressController.php:213
 * @route '/admin/api/employee-progress/stats'
 */
    const getEmployeeProgressStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getEmployeeProgressStats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressStats
 * @see app/Http/Controllers/EmployeeProgressController.php:213
 * @route '/admin/api/employee-progress/stats'
 */
        getEmployeeProgressStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeProgressStats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmployeeProgressController::getEmployeeProgressStats
 * @see app/Http/Controllers/EmployeeProgressController.php:213
 * @route '/admin/api/employee-progress/stats'
 */
        getEmployeeProgressStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getEmployeeProgressStats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getEmployeeProgressStats.form = getEmployeeProgressStatsForm
const EmployeeProgressController = { showEmployeeProgressPanel, getEmployeeProgressData, getEmployeeProgressStats }

export default EmployeeProgressController